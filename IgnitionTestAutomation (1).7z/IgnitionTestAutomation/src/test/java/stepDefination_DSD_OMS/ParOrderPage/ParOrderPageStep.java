package stepDefination_DSD_OMS.ParOrderPage;

import helper.HelpersMethod;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import pages_DSD_OMS.orderGuide.CreateOGPage;
import pages_DSD_OMS.orderGuide.OrderGuidePage;
import pages_DSD_OMS.parOrder.ParOrderPage;
import util.TestBase;

import java.awt.*;
import java.util.List;

/**
 * @Project OMS_DSD
 * @Author Divya.Ramadas@afsi.com
 */
public class ParOrderPageStep
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;

    static boolean exists = false;
    static String Prod_No=null;

    OrderGuidePage orderGuidePage;
    CreateOGPage createOGPage;
    ParOrderPage parOrderPage;

    @Before
    public void LaunchBrowser(Scenario scenario) throws Exception
    {
        this.scenario = scenario;
        TestBase driver1 = TestBase.getInstanceOfDriver();
        driver = driver1.getDriver();
    }

    @And("User should navigate to OG and select {string} from grid")
    public void UserShouldNavigateToOGAndSelectOGFromGrid(String OG) throws InterruptedException, AWTException
    {
        exists=false;
        if (HelpersMethod.EleDisplay(HelpersMethod.FindByElement(driver, "xpath", "//li[contains(@class,'k-item')]/span[@class='k-link' and contains(text(),'Order Guides')]")))
        {
            //Code to navigate to Order guide
           // HelpersMethod.Implicitwait(driver,20);

            HelpersMethod.navigate_Horizantal_Tab(driver, "Order Guides", "//li[contains(@class,'k-item')]/span[@class='k-link' and contains(text(),'Order Guides')]", "xpath", "//li[contains(@class,'k-item')]/span[@class='k-link']");
            HelpersMethod.Implicitwait(driver,20);
            orderGuidePage = new OrderGuidePage(driver, scenario);
            exists = orderGuidePage.ValidateOG();
            Assert.assertEquals(exists, true);

            //Code to select OG from grid
            exists=false;
            exists=orderGuidePage.OGSearchBox(OG);
            Assert.assertEquals(exists,true);
            orderGuidePage.SearchOGSelect();
        }
    }

    @Then("User clicks on ParList tab and Click on New Par list button")
    public void userClicksOnParListTabAndClickOnNewParListButton()
    {
        exists=false;
        parOrderPage=new ParOrderPage(driver,scenario);
        parOrderPage.ClickParTab();
        exists=parOrderPage.ValidateParlistTab();
        Assert.assertEquals(exists,true);
    }

    @And("User enters code and discription for Par list")
    public void userEntersCodeAndDiscriptionForParList(DataTable tabledata)
    {
        List<List<String>> ParDetails=tabledata.asLists(String.class);
        parOrderPage=new ParOrderPage(driver,scenario);
        parOrderPage.ClickNewPar();
        parOrderPage.EnterCode(ParDetails.get(0).get(0));
        parOrderPage.EnterDesc(ParDetails.get(0).get(1));
    }

    @Then("User clicks on save Par list")
    public void userClicksOnSaveParList()
    {
        parOrderPage=new ParOrderPage(driver,scenario);
        parOrderPage.SavePar();
    }

    @And("User enters code and discription to create multiple Par list")
    public void userEntersCodeAndDiscriptionToCreateMultipleParList(DataTable tabledata)
    {
        List<List<String>> ParDetails=tabledata.asLists(String.class);
        parOrderPage=new ParOrderPage(driver,scenario);
        for(int i=0;i<=ParDetails.size()-1;i++)
        {
            parOrderPage.ClickNewPar();
            parOrderPage.EnterCode(ParDetails.get(i).get(0));
            parOrderPage.EnterDesc(ParDetails.get(i).get(1));
        }
    }

    @Then("User clicks on ParList tab and Selects parlist {string} from drop down")
    public void userClicksOnParListTabAndSelectsParlistFromDropDown(String ParList)
    {
        parOrderPage=new ParOrderPage(driver,scenario);
        parOrderPage.ReadProductValueFromOG();
        parOrderPage.ClickParDropDown();
        parOrderPage.SelectParlistFromDropdown(ParList);
    }

    @And("User enters product# in search box and validates same product details displayed in Product grid")
    public void userEntersProductInSearchBoxAndValidatesSameProductDetailsDisplayedInProductGrid()
    {
        parOrderPage=new ParOrderPage(driver,scenario);
        parOrderPage.EnterProductNoInSearchBox();
    }

    @And("Display all product# in par list")
    public void displayAllProductInParList()
    {
        parOrderPage=new ParOrderPage(driver,scenario);
        parOrderPage.ReadProducts();
    }

    @And("User clicks on Delete par list button and handle popup")
    public void userClicksOnDeleteParListButtonAndHandlePopup()
    {

    }
}


