package stepDefination_DSD_OMS.OrderGuidePage;

import helper.HelpersMethod;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import pages_DSD_OMS.orderGuide.CreateOGPage;
import pages_DSD_OMS.orderGuide.OrderGuidePage;
import util.DataBaseConnection;
import util.TestBase;

import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class OrderGuidePageStep1
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;

    static boolean exists = false;
    static String Prod_No=null;
    static String OGDis=null;
    static String WDay=null;

    OrderGuidePage orderGuidePage;
    CreateOGPage createOGPage;

    @Before
    public void LaunchBrowser1(Scenario scenario) throws Exception
    {
        this.scenario = scenario;
        TestBase driver1 = TestBase.getInstanceOfDriver();
        driver = driver1.getDriver();
    }

    //Code for creating OG using Catalog
    @Then("User clicks on Add product button and select Catalog from drop down")
    public void user_clicks_on_add_product_button_and_select_catalog_from_drop_down(DataTable dataTable)
    {
        List<List<String>> option=dataTable.asLists(String.class);
        createOGPage=new CreateOGPage(driver,scenario);
        createOGPage.ClickOnAddProduct();
        createOGPage.SelectValueFromAddProduct(option.get(0).get(0));
        scenario.log("Selected option from drop down is "+option.get(0).get(0));
    }

    @And("User should select products from catalog popup")
    public void user_should_select_products_from_catalog_popup()
    {
        createOGPage=new CreateOGPage(driver,scenario);
        createOGPage.CatalogPopup();
    }

    //Code to delete OG from the OG grid
    @Then("User enters OG Description in search box and Delete the OG verify same in OG grid")
    public void user_enters_og_description_in_search_box_and_delete_the_og_verify_same_in_og_grid(DataTable tabledata) throws InterruptedException, AWTException
    {
        exists=false;
        List<List<String>> OGSearch=tabledata.asLists(String.class);
        orderGuidePage = new OrderGuidePage(driver, scenario);
        createOGPage=new CreateOGPage(driver,scenario);
        for(int i=0;i<OGSearch.size()-1;i++)
        {
            orderGuidePage.OGSearchBox(OGSearch.get(i).get(0));
            orderGuidePage.SearchOGSelect();
            createOGPage.Click_Delete();
            createOGPage.DeleteOk_Popup();
            //once OG is deleted, search for OG in OG grid
            orderGuidePage.OGSearchBox(OGSearch.get(i).get(0));
        }
    }

    @Then("User enters OG Description {string} in search box and Delete the OG verify same in OG grid")
    public void userEntersOGDescriptionInSearchBoxAndDeleteTheOGVerifySameInOGGrid(String arg0) throws InterruptedException, AWTException
    {
        exists = false;
        orderGuidePage = new OrderGuidePage(driver, scenario);
        createOGPage = new CreateOGPage(driver, scenario);
        exists= orderGuidePage.OGSearchBox(arg0);
        orderGuidePage.SearchOGSelect();

        Assert.assertEquals(exists,true);
        createOGPage.Click_Delete();
        createOGPage.DeleteOk_Popup();
        //once OG is deleted, search for OG in OG grid
        exists=orderGuidePage.OGSearchBox(arg0);
       // Assert.assertEquals(exists,false);

    }

    @Then("User click on AddFilter button and handle different popup")
    public void userClickOnAddFilterButtonAndHandleDifferentPopup(DataTable dataTable) throws InterruptedException, AWTException
    {
        List<List<String>> AddOption=dataTable.asLists(String.class);
        orderGuidePage = new OrderGuidePage(driver, scenario);
        orderGuidePage.AddFilterClick(AddOption.get(0).get(0),AddOption.get(0).get(1));
    }

    @Then("User enters OG Description {string} in search box")
    public void userEntersOGDescriptionInSearchBox(String arg0) throws InterruptedException, AWTException
    {
        exists=false;
        orderGuidePage = new OrderGuidePage(driver, scenario);
        exists=orderGuidePage.OGSearchBox(arg0);
        Assert.assertEquals(exists,false);
    }

    @And("User verifies New OG page and clicks on import button")
    public void userVerifiesNewOGPageAndClicksOnImportButton()
    {
        createOGPage = new CreateOGPage(driver, scenario);
        createOGPage.ValidateNewOG();
        createOGPage.ImportClick();
        createOGPage.FileOpen();
    }

    @Then("User selects type of OG from drop down")
    public void userSelectsTypeOfOGFromDropDown(DataTable dataTable)
    {
        List<List<String>> Type=dataTable.asLists(String.class);
        createOGPage = new CreateOGPage(driver, scenario);
        createOGPage.ValidateNewOG();
        createOGPage.Click_On_Type();
        createOGPage.SelectTypeFromDropDown(Type.get(0).get(0));
    }

    @Then("User should click on Customer Reference drop down and select type of OG")
    public void userShouldClickOnCustomerReferenceDropDownAndSelectTypeOfOG(DataTable dataTable) throws InterruptedException, AWTException
    {
        List<List<String>> CusRef=dataTable.asLists(String.class);
        orderGuidePage = new OrderGuidePage(driver, scenario);
        orderGuidePage.CustomerRef();
        orderGuidePage.CustRefDropDown(CusRef.get(0).get(0));
    }

    @And("Check for popup to appear to select sub customer reference")
    public void checkForPopupToAppearToSelectSubCustomerReference() throws InterruptedException, AWTException
    {
        orderGuidePage = new OrderGuidePage(driver, scenario);
        orderGuidePage.SubCustomerRef();
    }

    @And("User should navigate back to OG page and navigate back to local chain and verify OG {string}  existence")
    public void userShouldNavigateBackToOGPageAndNavigateBackToLocalChainAndVerifyOGExistence(DataTable dataTable,String Og) throws InterruptedException, AWTException
    {
        List<List<String>> CustRef=dataTable.asLists(String.class);
        orderGuidePage = new OrderGuidePage(driver, scenario);
        boolean result = orderGuidePage.ValidateOG();
        Assert.assertEquals(result, true);
        scenario.log("USER IS ON ORDER GUIDE PAGE");

        //code to change Customer reference to Local chain
        List<List<String>> CusRef=dataTable.asLists(String.class);
        orderGuidePage = new OrderGuidePage(driver, scenario);
        orderGuidePage.CustomerRef();
        orderGuidePage.CustRefDropDown(CusRef.get(0).get(0));
        orderGuidePage.SubCustomerRef();


        //Code to verify whether OG is existing in OG grid or not
        orderGuidePage = new OrderGuidePage(driver, scenario);
        exists=orderGuidePage.OGSearchBox(Og);
        Assert.assertEquals(exists,true);
    }

    @And("User should navigate back to OG page and navigate back to local chain {string} and verify OG {string}  existence")
    public void userShouldNavigateBackToOGPageAndNavigateBackToLocalChainAndVerifyOGExistence(String OGType, String Og) throws InterruptedException, AWTException
    {
        orderGuidePage = new OrderGuidePage(driver, scenario);
        boolean result = orderGuidePage.ValidateOG();
        Assert.assertEquals(result, true);
        scenario.log("USER IS ON ORDER GUIDE PAGE");

        //code to change Customer reference to Local chain
        orderGuidePage = new OrderGuidePage(driver, scenario);
        orderGuidePage.CustomerRef();
        orderGuidePage.CustRefDropDown(OGType);
        orderGuidePage.SubCustomerRef();

        //Code to verify whether OG is existing in OG grid or not
        orderGuidePage = new OrderGuidePage(driver, scenario);
        exists=orderGuidePage.OGSearchBox(Og);
        Assert.assertEquals(exists,true);
    }

    @And("User selects Day of week from drop down")
    public void userSelectsDayOfWeekFromDropDown()
    {
        createOGPage = new CreateOGPage(driver, scenario);
        createOGPage.ClickOnDayOfWeek();
        WDay=createOGPage.SelectDayOfWeek();
    }

    @And("User should navigate to OG and change the Customer Account#")
    public void userShouldNavigateToOGAndChangeTheCustomerAccount() throws InterruptedException, AWTException
    {
        if (HelpersMethod.EleDisplay(HelpersMethod.FindByElement(driver, "xpath", "//li[contains(@class,'k-item')]/span[@class='k-link' and contains(text(),'Order Guides')]")))
        {
            HelpersMethod.navigate_Horizantal_Tab(driver, "Order Guides", "//li[contains(@class,'k-item')]/span[@class='k-link' and contains(text(),'Order Guides')]", "xpath", "//li[contains(@class,'k-item')]/span[@class='k-link']");
            orderGuidePage = new OrderGuidePage(driver, scenario);
            boolean result = orderGuidePage.ValidateOG();
            Assert.assertEquals(result, true);
        }
        orderGuidePage = new OrderGuidePage(driver, scenario);
        orderGuidePage.CustomerAcc();
        orderGuidePage.AccountPopup();
    }

    @Then("User reads first OG from OG grid and navigates to new OG page")
    public void userReadsFirstOGFromOGGridAndNavigatesToNewOGPage() throws InterruptedException, AWTException
    {
        orderGuidePage = new OrderGuidePage(driver, scenario);
        OGDis=orderGuidePage.SelectOG();
    }

    @And("User selects end date as past date")
    public void userSelectsEndDateAsPastDate()
    {
        createOGPage = new CreateOGPage(driver, scenario);
        exists=createOGPage.OGDetailValidate();
        Assert.assertEquals(exists,true);
        createOGPage.CalenderEnd();
        createOGPage.ValidToDatePast();
        createOGPage.ClickOnSave();
    }

    @And("User should navigate back to OG page and verify OG by selecting status as expired")
    public void userShouldNavigateBackToOGPageAndVerifyOGBySelectingStatusAsExpired() throws InterruptedException, AWTException
    {
        orderGuidePage = new OrderGuidePage(driver, scenario);
        exists=orderGuidePage.ValidateOG();
        Assert.assertEquals(exists,true);
        exists=orderGuidePage.AddFilterClick("Status","Expired");
        Assert.assertEquals(exists,true);
        exists=orderGuidePage.OGSearchBox(OGDis);
        Assert.assertEquals(exists,true);
    }

    @And("User should navigate back to OG page change account# and verify OG {string}  existence")
    public void userShouldNavigateBackToOGPageChangeAccountAndVerifyOGExistence(String Og) throws InterruptedException, AWTException
    {
        orderGuidePage = new OrderGuidePage(driver, scenario);
        orderGuidePage.CustomerAcc();
        orderGuidePage.AccountPopup();
    }

    @And("User should navigate back to OG page, verify OG {string}  existence and verify that Week of day is selected")
    public void userShouldNavigateBackToOGPageVerifyOGExistenceAndVerifyThatWeekOfDayIsSelected(String Og) throws InterruptedException, AWTException
    {
        String DayWeek=null;
        orderGuidePage = new OrderGuidePage(driver, scenario);
        boolean result = orderGuidePage.ValidateOG();
        Assert.assertEquals(result, true);
        scenario.log("USER IS ON ORDER GUIDE PAGE");

        //Code to verify whether OG is existing in OG grid or not
        orderGuidePage = new OrderGuidePage(driver, scenario);
        exists=orderGuidePage.OGSearchBox(Og);
        Assert.assertEquals(exists,true);

        //Click on OG and navigate to OG details page
        orderGuidePage.SearchOGSelect();
        createOGPage = new CreateOGPage(driver, scenario);
        exists=createOGPage.OGDetailValidate();
        Assert.assertEquals(exists,true);
        DayWeek=createOGPage.ValidateWeekOfDay();
        Assert.assertEquals(DayWeek,WDay);
    }

    @And("User should navigate to CustomerAllocation tab")
    public void userShouldNavigateToCustomerAllocationTab()
    {
        exists=false;
        createOGPage = new CreateOGPage(driver, scenario);
        createOGPage.CustomerAllocation();
        exists=createOGPage.ValidateCustomerAllocation();
        Assert.assertEquals(exists,true);
    }

    @Then("Select CustomerAllocation check box and click on Delete button")
    public void selectCustomerAllocationCheckBoxAndClickOnDeleteButton()
    {
        exists=false;
        createOGPage = new CreateOGPage(driver, scenario);
        createOGPage.CheckBoxCustAllocation();
        createOGPage.ClickOnDelete();
        exists=createOGPage.ValidateDelete();
        Assert.assertEquals(exists,true);
        scenario.log("Customer Allocation has been removed sucessfully");
    }

    @Then("User Clicks on Plus button and select value from drop down")
    public void userClicksOnPlusButtonAndSelectValueFromDropDown(DataTable tableData)
    {
        List<List<String>> PlusDrop=tableData.asLists(String.class);
        exists=false;
        createOGPage = new CreateOGPage(driver, scenario);
        createOGPage.ClickPlus();
        createOGPage.DropDownAcc(PlusDrop.get(0).get(0));
    }

    @And("User verify popup appears and enter account# in search box")
    public void userVerifyPopupAppearsAndEnterAccountInSearchBox()
    {
        exists=false;
        createOGPage = new CreateOGPage(driver, scenario);
        exists=createOGPage.PopupHandle();
        Assert.assertEquals(exists,true);
    }

    @Then("Select customer account# and verify that account# is added")
    public void selectCustomerAccountAndVerifyThatAccountIsAdded()
    {
        exists=false;
        createOGPage = new CreateOGPage(driver, scenario);
        createOGPage.CustomerAccountSelect();
        exists=createOGPage.ValidateCustSelect();
        Assert.assertEquals(exists,true);

        //Code to save OG
        createOGPage.ClickOnSave();
    }

    @And("User should select products from catalog popup to add muliple products")
    public void userShouldSelectProductsFromCatalogPopupToAddMulipleProducts() throws SQLException
    {
        createOGPage = new CreateOGPage(driver, scenario);
        exists=createOGPage.ValidateCatalogDisplay();
        createOGPage.AddFromCatalog(DataBaseConnection.DataConn1(TestBase.testEnvironment.getMultiple_Prod_Sql()));
    }
}
