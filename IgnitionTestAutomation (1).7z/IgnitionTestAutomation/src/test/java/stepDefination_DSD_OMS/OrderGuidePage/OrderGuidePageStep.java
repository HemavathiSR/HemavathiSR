package stepDefination_DSD_OMS.OrderGuidePage;

import helper.HelpersMethod;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import pages_DSD_OMS.orderEntry.NewOrderEntryPage;
import pages_DSD_OMS.orderEntry.OrderEntryPage;
import pages_DSD_OMS.orderGuide.CreateOGPage;
import pages_DSD_OMS.orderGuide.OrderGuidePage;
import util.DataBaseConnection;
import util.TestBase;

import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class OrderGuidePageStep
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;

    String XPath = null;
    static boolean exists = false;
    static String Prod_No=null;

    OrderEntryPage orderpage;
    NewOrderEntryPage newOE;
    OrderGuidePage orderGuidePage;
    CreateOGPage createOGPage;

    @Before
    public void LaunchBrowser1(Scenario scenario) throws Exception
    {
        this.scenario = scenario;
        TestBase driver1 = TestBase.getInstanceOfDriver();
        driver = driver1.getDriver();
    }

    @Given("User must be on Order Entry Page to select OG")
    public void user_must_be_on_order_entry_page_to_select_og() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        orderpage.HandleError_Page();
        newOE = new NewOrderEntryPage(driver,scenario);
        newOE.Click_Back_But();
        orderGuidePage = new OrderGuidePage(driver, scenario);
        orderGuidePage.Refresh_Page();
    }

    @And("User should navigate to OG")
    public void user_should_navigate_to_og() throws InterruptedException, AWTException
    {
        if (HelpersMethod.EleDisplay(HelpersMethod.FindByElement(driver, "xpath", "//li[contains(@class,'k-item')]/span[@class='k-link' and contains(text(),'Order Guides')]")))
        {
            exists=false;
            orderGuidePage = new OrderGuidePage(driver, scenario);
            HelpersMethod.navigate_Horizantal_Tab(driver, "Order Guides", "//li[contains(@class,'k-item')]/span[@class='k-link' and contains(text(),'Order Guides')]", "xpath", "//li[contains(@class,'k-item')]/span[@class='k-link']");
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 20);
            exists = orderGuidePage.ValidateOG();
            Assert.assertEquals(exists, true);
        }
        else
        {
            scenario.log("ORDER GUIDE TAB DOESN'T EXISTS");
        }
    }

    @Then("User clicks on Create new button and should navigate to New OG page")
    public void user_clicks_on_create_new_button_and_should_navigate_to_new_og_page() throws InterruptedException, AWTException
    {
        exists=false;
        orderGuidePage=new OrderGuidePage(driver,scenario);
        orderGuidePage.CrateOG();
        createOGPage=new CreateOGPage(driver,scenario);
        exists=createOGPage.ValidateNewOG();
        Assert.assertEquals(exists,true);
    }

    @Then("Then User enters Description {string} and End date")
    public void thenUserEntersDescriptionAndEndDate(String Og)
    {
        createOGPage=new CreateOGPage(driver,scenario);
        createOGPage.DescriptionOG(Og);

        //selecting end date
        LocalDate myDateObj = LocalDate.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
        String formattedDate = myDateObj.format(myFormatObj);
        createOGPage.CalenderEnd();
        createOGPage.SelectEndDate(formattedDate,2);
    }

    @And("User enters Quick Product number and Sequence number")
    public void user_enters_quick_product_number_and_sequence_number(DataTable tabledata) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException
    {
        List<List<String>> SeqNo=tabledata.asLists(String.class);
        createOGPage=new CreateOGPage(driver,scenario);
        Prod_No= DataBaseConnection.DataBaseConn(TestBase.testEnvironment.getSingle_Prod_Sql());
        createOGPage.EnterQuickProduct(Prod_No,SeqNo.get(0).get(0));
    }

    @Then("User click on Save button")
    public void user_click_on_save_button()
    {
        createOGPage=new CreateOGPage(driver,scenario);
        createOGPage.ClickOnSave();
    }

    //code to verify whether user is on OG page or not
    @And("User should navigate back to OG page and verify OG {string}  existence")
    public void user_should_navigate_back_to_og_page(String Og) throws InterruptedException, AWTException
    {
        exists=false;
        orderGuidePage = new OrderGuidePage(driver, scenario);
        exists = orderGuidePage.ValidateOG();
        Assert.assertEquals(exists, true);
        scenario.log("USER IS ON ORDER GUIDE PAGE");

        exists=false;
        //Code to verify whether OG is existing in OG grid or not
        orderGuidePage = new OrderGuidePage(driver, scenario);
        exists=orderGuidePage.OGSearchBox(Og);
        Assert.assertEquals(exists,true);
    }

    //Code to search for OG using search box
    @Then("User enters OG Description in search box")
    public void user_enters_og_description_in_search_box(DataTable tabledata) throws InterruptedException, AWTException
    {
        exists=false;
        List<List<String>> OGSearch=tabledata.asLists(String.class);
        orderGuidePage = new OrderGuidePage(driver, scenario);
        exists=orderGuidePage.OGSearchBox(OGSearch.get(0).get(0));
        Assert.assertEquals(exists,true);
        orderGuidePage.SearchOGSelect();

        exists=false;
        createOGPage=new CreateOGPage(driver,scenario);
        exists=createOGPage.OGDetailValidate();
        Assert.assertEquals(exists,true);
    }

    //code to enter products to exitsting OG for editing OG, using quick product entry
    @And("User enters multiple Quick Product number and Sequence number")
    public void user_enters_multiple_quick_product_number_and_sequence_number(DataTable tabledata) throws SQLException
    {
        createOGPage=new CreateOGPage(driver,scenario);
        List<List<String>> SeqList=tabledata.asLists(String.class);
        List<String> Product=DataBaseConnection.DataConn1(TestBase.testEnvironment.getMultiple_Prod_Sql());
        for(int i=0;i<=SeqList.size()-1;i++)
        {
            createOGPage.EnterQuickProduct(Product.get(i + 1),SeqList.get(i).get(0));
        }
    }

    //Code to click on Delete button to remove product from OG
    @And("User click on Delete button to remove product from OG")
    public void user_cllick_on_delete_button_to_remove_product_from_og()
    {
        createOGPage=new CreateOGPage(driver,scenario);
        createOGPage.DeleteProd();
    }

    //code to click on More button in Open OG
    @Then("User click on More button")
    public void user_click_on_more_button()
    {
        createOGPage=new CreateOGPage(driver,scenario);
        exists=createOGPage.More_Button();
        Assert.assertEquals(exists,true);
    }

    //Code to select Clear sequence from drop down
    @And("User selects Clear Sequence from drop down")
    public void user_selects_clear_sequence_from_drop_down()
    {
        createOGPage=new CreateOGPage(driver,scenario);
        exists=createOGPage.SequenceClear();
        Assert.assertEquals(exists,true);
    }

    //Code to handle sequence clear popup and select No from popup
    @And("User handles popup for clearing sequence number by selecting No")
    public void user_handles_popup_for_clearing_sequence_number_by_selecting_No()
    {
        createOGPage=new CreateOGPage(driver,scenario);
        createOGPage.SequencePopupNo();
    }

    //Code to handle sequence clear popup and select Yes from popup
    @And("User handles popup for clearing sequence number by selecting Yes")
    public void user_handles_popup_for_clearing_sequence_number_by_selecting_yes()
    {
        createOGPage=new CreateOGPage(driver,scenario);
        createOGPage.SequencePopupYes();
    }

    //Code to edit sequence number in Order guide, Product grid
    @And("User changes sequence number in product grid of OG")
    public void user_changes_sequence_number_in_product_grid_of_og(DataTable tabledata)
    {
        List<List<String>> SeqNo=tabledata.asLists(String.class);
        createOGPage=new CreateOGPage(driver,scenario);
        exists=createOGPage.EditSequence(SeqNo.get(0).get(0));
        Assert.assertEquals(exists,true);
    }

    @And("User enters multiple Product# Quick Product number and Sequence number")
    public void user_enters_multiple_product_quick_product_number_and_sequence_number(DataTable tabledata) throws SQLException
    {
        createOGPage=new CreateOGPage(driver,scenario);
        List<List<String>> SeqList=tabledata.asLists(String.class);
        List<String> Product=DataBaseConnection.DataConn1(TestBase.testEnvironment.getMultiple_Prod_Sql());

        for(int i=0;i<=SeqList.size()-1;i++)
        {
            createOGPage.EnterQuickProduct(Product.get(i),SeqList.get(i).get(0));
        }
    }

    //Code to create OG with multiple products, and to select end date
    @Then("User enters Description and End date 2 day from current date")
    public void user_enters_description_and_end_date_two_days_from_current_date(DataTable tabledata)
    {
        //entering discription
        List<List<String>> OGDesc = tabledata.asLists(String.class);
        createOGPage=new CreateOGPage(driver,scenario);
        createOGPage.DescriptionOG(OGDesc.get(0).get(0));

        //selecting end date
        LocalDate myDateObj = LocalDate.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
        String formattedDate = myDateObj.format(myFormatObj);
        createOGPage.CalenderEnd();
        createOGPage.SelectEndDate(formattedDate,2);
    }

    //code for creating OG by adding OG
    @Then("User clicks on Add product button and select OG from drop down")
    public void user_clicks_on_add_product_button_and_select_OG_from_drop_down(DataTable dataTable)
    {
        List<List<String>> option=dataTable.asLists(String.class);
        createOGPage=new CreateOGPage(driver,scenario);
        createOGPage.ClickOnAddProduct();
        createOGPage.SelectValueFromAddProduct(option.get(0).get(0));
    }

    //Code for selecting OG from Popup
    @And("User should select OG from popup")
    public void user_should_select_og_from_popup()
    {
        createOGPage=new CreateOGPage(driver,scenario);
        createOGPage.OrderGuidePopup();
    }

    @Then("User clicks on Add product button and select Order from drop down")
    public void user_clicks_on_add_product_button_and_select_order_from_drop_down(DataTable dataTable)
    {
        List<List<String>> option=dataTable.asLists(String.class);
        createOGPage=new CreateOGPage(driver,scenario);
        createOGPage.ClickOnAddProduct();
        createOGPage.SelectValueFromAddProduct(option.get(0).get(0));
    }

    @And("User should select Order# from Order popup")
    public void user_should_select_order_from_order_popup()
    {
        createOGPage=new CreateOGPage(driver,scenario);
        createOGPage.OrderPopup();
    }

    //code for adding product from quick entry and from catalog
    @And("User enters multiple Product# Quick Product entry and catalog and Sequence number")
    public void user_enters_multiple_product_quick_product_entry_and_catalog_and_sequence_number(DataTable dataTable) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException
    {
        List<List<String>> ProdOption=dataTable.asLists(String.class);
        createOGPage=new CreateOGPage(driver,scenario);

        //Code to get data from database
        String Product=DataBaseConnection.DataBaseConn(TestBase.testEnvironment.getSingle_Prod_Sql());
        //Enter value in  quick product, sequence input text box
        createOGPage.EnterQuickProduct(Product,ProdOption.get(0).get(0));
        //handling catalog popup. Selecting Catalog option from drop down
        createOGPage.ClickOnAddProduct();
        createOGPage.SelectValueFromAddProduct(ProdOption.get(0).get(1));
    }

    @Then("User enters Description {string} Start date {int} and End date {int} day from current date")
    public void userEntersDescriptionStartDateSdateAndEndDateEdateDayFromCurrentDate(String arg0,int Sdate,int Edate)
    {
        createOGPage=new CreateOGPage(driver,scenario);
        createOGPage.DescriptionOG(arg0);

        //selecting start date
        LocalDate myDateObj = LocalDate.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
        String formattedDate = myDateObj.format(myFormatObj);
        createOGPage.CalenderStart();
        createOGPage.SelectStartDate(formattedDate, Sdate);

        //selecting end date
        LocalDate myDateObj1 = LocalDate.now();
        DateTimeFormatter myFormatObj1= DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
        String formattedDate1 = myDateObj1.format(myFormatObj1);
        createOGPage.CalenderEnd();
        createOGPage.SelectEndDate(formattedDate1,Edate);
    }

    @Then("User enters OG {string} Description in search box")
    public void userEntersOGDescriptionInSearchBox(String Og) throws InterruptedException, AWTException
    {
        exists=false;
        orderGuidePage = new OrderGuidePage(driver, scenario);
        exists=orderGuidePage.OGSearchBox(Og);
        Assert.assertEquals(exists,true);
        orderGuidePage.SearchOGSelect();

        exists=false;
        createOGPage=new CreateOGPage(driver,scenario);
        exists=createOGPage.OGDetailValidate();
        Assert.assertEquals(exists,true);
    }

    @And("User search for Product# in New OG page")
    public void userSearchForProductInNewOGPage() throws InterruptedException, SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException
    {
        exists=false;
        createOGPage=new CreateOGPage(driver,scenario);
        String ProdNo=DataBaseConnection.DataBaseConn(TestBase.testEnvironment.getSingle_Prod_Sql());

        exists= createOGPage.SearchProd(ProdNo);
        if(exists==true)
        {
            scenario.log(ProdNo+" HAS BEEN FOUND IN PRODUCT GRID");
        }
        else
        {
            scenario.log(ProdNo+" PRODUCT IS NOT PART OF OG");
        }
        Assert.assertEquals(exists,true);
    }

    @Then("Then User enters Description {string}")
    public void thenUserEntersDescription(String Og)
    {
        createOGPage=new CreateOGPage(driver,scenario);
        createOGPage.DescriptionOG(Og);
    }
}
