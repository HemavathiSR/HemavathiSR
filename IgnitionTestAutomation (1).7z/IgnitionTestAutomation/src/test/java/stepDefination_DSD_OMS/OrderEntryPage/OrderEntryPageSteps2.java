package stepDefination_DSD_OMS.OrderEntryPage;

import helper.HelpersMethod;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import pages_DSD_OMS.orderEntry.CheckOutSummaryPage;
import pages_DSD_OMS.orderEntry.NewOrderEntryPage;
import pages_DSD_OMS.orderEntry.OrderEntryPage;
import util.DataBaseConnection;
import util.TestBase;

import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @Project DSD_OMS_
 * @Author Divya.Ramadas
 */
public class OrderEntryPageSteps2
{
    /* Created by Divya.Ramadas */
    private static boolean flag = false;
    WebDriver driver;
    Scenario scenario;

    OrderEntryPage orderpage;
    NewOrderEntryPage newOE;
    CheckOutSummaryPage summary;

    String Tot_Amt=null;
    String Tot_Amt1=null;
    String Route=null;
    String Route1=null;
    String Order_No=null;

    @Before
    public void LaunchBrowser1(Scenario scenario) throws Exception
    {
        this.scenario=scenario;
        TestBase driver1= TestBase.getInstanceOfDriver();
        driver= driver1.getDriver();
    }

    //for entering multiple products from Quick product entry, using it for drag and drop
    @Then("Enter Prod_No in Quick Product Entry area")
    public void enterProd_NoInQuickProductEntryArea(DataTable tabledata) throws InterruptedException, AWTException, SQLException
    {
        java.util.List<java.util.List<String>> Prod_details = tabledata.asLists(String.class);
        newOE = new NewOrderEntryPage(driver,scenario);
        HelpersMethod.Implicitwait(driver, 10);
        ArrayList<String> Prod_No= (ArrayList<String>) DataBaseConnection.DataConn1(TestBase.testEnvironment.getMultiple_Prod_Sql());
        //productPage = new ProductPage(driver);
        for (int i = 0; i <= Prod_details.size() - 1; i++)
        {
            String pro=String.valueOf(Prod_No.get(i));
            newOE.QuickProduct(pro);
            newOE.CheckForQuickCaseEnabled(Prod_details.get(i).get(0));
            newOE.CheckForQuickUnitEnabled(Prod_details.get(i).get(1));
        }
    }

    @And("Drag and drop table header")
    public void drag_and_drop_table_header(DataTable tabledata) throws InterruptedException, AWTException
    {
        java.util.List<java.util.List<String>> TableHead=tabledata.asLists(String.class);
        newOE = new NewOrderEntryPage(driver,scenario);
        newOE.FindtableHeader(TableHead.get(0).get(0));
    }

    @Then("User enters ProdDes in Search box")
    public void user_enters_prodDes_in_search_box() throws InterruptedException, AWTException
    {
        newOE=new NewOrderEntryPage(driver,scenario);
        //Enter product Desc in search bar
        newOE.SearchBox_ProdDesc(TestBase.testEnvironment.get_ProdDesc());
    }

    //Reading total amount from the New OE page
    @And ("Find total amount from New oe page")
    public void find_total_amount_from_new_oe_page() throws InterruptedException, AWTException
    {
        newOE=new NewOrderEntryPage(driver,scenario);
        Tot_Amt=newOE.Total_NewOE();
    }

    //Reading total amount from the summary page
    @And ("Get total amount from summary page and Click on SubmitOrder button")
    public void get_total_amount_from_summary_page_and_click_on_submitorder_button() throws InterruptedException, AWTException
    {
        summary=new CheckOutSummaryPage(driver,scenario);
        Tot_Amt1=summary.Find_TotalAmt();
        summary.ClickSubmit();
        scenario.log("Product Total found in New OE page: "+Tot_Amt+" Product total found in summary page: "+Tot_Amt1);
        //asserting totals
        Assert.assertEquals(Tot_Amt,Tot_Amt1);
    }

    //selecting rout from the Route index popup
    @Then ("User should  click on route index icon and select route")
    public void user_should_click_on_route_index_icon_and_select_route() throws InterruptedException, AWTException
    {
        orderpage=new OrderEntryPage(driver, scenario);
        //Select Route number using Add Filter
        orderpage.Route_No(TestBase.testEnvironment.get_RouteFilt(),TestBase.testEnvironment.get_Route());
    }
    //Compare route selected in OE page and New OE page
    @Then ("Compare route selected in OE page with route in NewOE page")
    public void compare_route_selected_in_oe_page_with_route_in_newoe_page() throws InterruptedException, AWTException
    {
        boolean result=false;
        HelpersMethod.Implicitwait(driver,8);
        newOE=new NewOrderEntryPage(driver,scenario);
        Route1=newOE.Read_Route();
        if(Route1.contains(Route))
        {
            result=true;
        }
        Assert.assertEquals(result,true);
    }
    //To find total number of products in summary page
    @Then ("In Order Summary page compare Total no of line compare it with no of products")
    public void in_order_summary_page_compare_total_no_of_line_compare_it_with_no_of_products() throws InterruptedException, AWTException
    {
        String TotalProd,TotGrid;
        summary= new CheckOutSummaryPage(driver,scenario);
        TotalProd=driver.findElement(By.xpath("//div[contains(text(),'Total lines')]/following-sibling::div")).getText();
        TotGrid=Integer.toString(summary.Read_no_of_Product_Grid());
        Assert.assertEquals(TotalProd,TotGrid);
    }

    //To compare total amount in summary card and order total card
    @And ("Get total amount from summary card and Order total on SubmitOrder button")
    public void get_total_amount_from_summary_card_and_order_total_on_submitorder_button() throws InterruptedException, AWTException
    {
        summary=new CheckOutSummaryPage(driver,scenario);
        Tot_Amt1=summary.Find_TotalAmt();
        //find total in summary card
        String tot=driver.findElement(By.xpath("//div[contains(text(),'Product total')]/following-sibling::div")).getText();

        //asserting totals
        Assert.assertEquals(tot,Tot_Amt1);
        summary.ClickSubmit();
    }

    //Code to change Account# to other Account#
    @And ("change the account_No to someother account#")
    public void change_the_account_no_to_someother_account_no() throws InterruptedException, AWTException
    {
        HelpersMethod.Implicitwait(driver,5);
        orderpage=new OrderEntryPage(driver, scenario);

        //Changing account number
        orderpage.Change_NewAccount(TestBase.testEnvironment.get_AnotherAcc());
        orderpage.PopUps_After_AccountChange();
    }
    //check whether user has navigated to NewOE enter page
    @And ("Check whether user navigated to NewOE page")
    public void check_whether_user_navigated_to_newoe_page() throws InterruptedException, AWTException
    {
        newOE=new NewOrderEntryPage(driver,scenario);
        WebElement WebCardTitle=HelpersMethod.FindByElement(driver,"xpath","//div[@id='orderEntryCard']/descendant::label[contains(text(),'New order')]");
        String CardTitle=WebCardTitle.getText();
        Assert.assertEquals(CardTitle,"New order");
    }
    //changing the account number to the previous account# which was loaded before
    @And ("user should change the Account# back to Previous Account#")
    public void user_should_change_the_account_no_back_to_previous_account_no() throws InterruptedException, AWTException
    {
        newOE=new NewOrderEntryPage(driver,scenario);
        newOE.Click_Back_But();

        orderpage=new OrderEntryPage(driver, scenario);
        //Change Customer account to old account number
            orderpage.Change_NewAccount(TestBase.testEnvironment.get_Account());
            orderpage.PopUps_After_AccountChange();
    }
    //Cancel the order from Order summary page
    @Then("Click on Cancel button in OE summary page and handle warning popup")
    public void click_on_cancel_button_in_oe_summary_page_and_handle_warning_popup() throws InterruptedException, AWTException
    {
        summary=new CheckOutSummaryPage(driver,scenario);
        Order_No=summary.Get_Order_No();
        summary.Cancel_Button();
    }

    //verifying whether ordernumber is existing in OG or not
    @And("verify whether Order number is not existing in OG")
    public void verify_whether_order_number_is_not_existing_in_OG() throws InterruptedException, AWTException
    {
        boolean result=false;
        orderpage=new OrderEntryPage(driver, scenario);
        orderpage.Enter_OrderNo_Searchbox(Order_No);
        orderpage.Existence_OrderNo_OG();
        Assert.assertEquals(result,true);
    }

    //To check whether the products in order summary page are in sorted order or not
    @Then ("In Order Summary page click on up arrow for sorting product in descending order of product number")
    public void in_order_summary_page_click_on_up_arrow_for_sorting_product_in_descending_order_of_product_number() throws InterruptedException, AWTException
    {
        summary=new CheckOutSummaryPage(driver,scenario);
        summary.Product_UpArrow();
    }
}
