package stepDefination_DSD_OMS.OrderEntryPage;

import helper.HelpersMethod;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.stringtemplate.v4.DateRenderer;
import org.testng.Assert;
import pages_DSD_OMS.login.HomePage;
import pages_DSD_OMS.login.LoginPage;
import pages_DSD_OMS.orderEntry.*;
import util.DataBaseConnection;
import util.TestBase;

import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class OrderEntryPageSteps
{
    /* Created by Divya.Ramadas@afsi.com */
    private static boolean flag = false;
    private static boolean flag1=false;
    WebDriver driver;
    Scenario scenario;

    LoginPage loginpage;
    HomePage homepage;
    OrderEntryPage orderpage;
    NewOrderEntryPage newOE;
    CheckOutSummaryPage summary;
    OrderHistoryPage orderhistory;
    CheckOutOrderPage checkorder;

    String XPath=null;
    boolean exists=false;
    String Ord_No=null;
    String ProdNo=null;
    String PageTitle=null;

    @Before
    public void LaunchBrowser1(Scenario scenario) throws Exception
    {
        this.scenario=scenario;
        TestBase driver1=TestBase.getInstanceOfDriver();
        driver= driver1.getDriver();
    }

    @Given("User enters URL and is on login page and entered credentials")
    public void user_enters_url_and_is_on_login_page_and_entered_credentials() throws Exception
    {
        if(flag==false)
        {
            loginpage = new LoginPage(driver,scenario);
            HelpersMethod.Implicitwait(driver, 10);
            loginpage.EnterUsername(TestBase.testEnvironment.username());
            loginpage.EnterPassword(TestBase.testEnvironment.password());
            HelpersMethod.Implicitwait(driver, 2);
            loginpage.ClickSignin();
        }
    }

    @When("User is on Home Page")
    public void user_is_on_home_page() throws InterruptedException, AWTException
    {
        if(flag==false)
        {
            //verify the home page
            HelpersMethod.Implicitwait(driver,10);
            homepage = new HomePage(driver,scenario);
            homepage.VerifyHomePage();
        }
    }

    @Then("User navigate to Client side")
    public void user_navigate_to_client_side() throws InterruptedException, AWTException
    {
        boolean result=false;
        if(flag==false)
        {
            Thread.sleep(10000);
            homepage = new HomePage(driver,scenario);
            String title = driver.getTitle();
            Assert.assertEquals(title, "Ignition - Admin");
            homepage.verifyUserinfoContainer();
            homepage.navigateToClientSide();
        }
    }

    @Then("User should select Order Entry tab")
    public void user_should_select_order_entry_tab() throws InterruptedException, AWTException
    {
        if(flag==false)
        {
            orderpage = new OrderEntryPage(driver, scenario);
            orderpage.NavigateToOrderEntry();
            flag=true;
        }
    }

    @Then("User selects Account#")
    public void user_selects_account() throws InterruptedException, AWTException
    {
        if(flag1==false)
        {
            orderpage = new OrderEntryPage(driver, scenario);
            orderpage.ChangeAccount();
            orderpage.PopUps_After_AccountChange();
            flag1=true;
        }
    }

    @Given("User must be on Order Entry Page")
    public void user_must_be_on_order_entry_page() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        orderpage.HandleError_Page();
        orderpage.Refresh_Page();
        orderpage.ClickCalender();
        orderpage.ResetToCurrentDate();
        HelpersMethod.Implicitwait(driver, 5);
    }

    @Then("Change the date {int} days after current date")
    public void change_the_date_days_after_current_date(Integer int1) throws InterruptedException, AWTException
    {
        //create object of OE Page
        orderpage = new OrderEntryPage(driver, scenario);

        //get current date add some days to current date
        LocalDate myDateObj = LocalDate.now().plusDays(int1);
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
        String formattedDate = myDateObj.format(myFormatObj);
        HelpersMethod.Implicitwait(driver, 15);
        orderpage.ClickCalender();
        orderpage.SelectDate(formattedDate, int1);
        HelpersMethod.Implicitwait(driver,5);
    }

    @Then("Reset Delivery date to original date")
    public void reset_delivery_date_to_original_date() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        //get current date add some days to current date
        LocalDate myDateObj = LocalDate.now().plusDays(2);
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
        String formattedDate = myDateObj.format(myFormatObj);
        HelpersMethod.Implicitwait(driver, 10);
        orderpage.ClickCalender();
        orderpage.SelectDate(formattedDate, 1);
    }

    @Then("User must click Start Order button")
    public void user_must_click_start_order_button() throws InterruptedException, AWTException
    {
        exists=false;
        orderpage = new OrderEntryPage(driver, scenario);
        //check for 'Start Order' button
        orderpage.Scroll_start();
        exists=orderpage.Start_Order();
        Assert.assertEquals(exists,true);
    }

    @Then("User should make selection between Pending order or Start New order")
    public void user_should_make_selection_between_pending_order_or_start_new_order() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        HelpersMethod.Implicitwait(driver, 10);
        //Handling Pending order popup
        orderpage.NoPendingOrderPopup();
    }

    @Then("User must again click Start Order button")
    public void userMustAgainClickStartOrderButton() throws InterruptedException, AWTException
    {
        exists=false;
        orderpage=new OrderEntryPage(driver,scenario);
        exists=orderpage.Start_OrderAgain();
        Assert.assertEquals(exists,true);
    }

    @Then("User should select Note from popup")
    public void user_should_select_note_from_popup() throws Throwable
    {
        orderpage = new OrderEntryPage(driver, scenario);
        orderpage.NoNotePopHandling();
    }

    @Then("User should find select Order guide from popup")
    public void user_should_find_select_order_guide_from_popup() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        orderpage.OrderGuidePopup();
    }

    @Then("User enters Product# in Search box")
    public void user_enters_product_in_search_box() throws Throwable
    {
        newOE = new NewOrderEntryPage(driver,scenario);
        String ProdNo= DataBaseConnection.DataBaseConn(TestBase.testEnvironment.getSingle_Prod_Sql());
        newOE.EnterProdNo_InSearchBar(ProdNo);
    }

    @Then("Check for Catalog popup")
    public void check_for_catalog_popup() throws InterruptedException, AWTException
    {
        newOE = new NewOrderEntryPage(driver,scenario);
        HelpersMethod.Implicitwait(driver, 8);
        boolean exists = newOE.CheckForCatalog();
       Assert.assertEquals(exists, true);
    }

    @Then("Enter PO# for New order")
    public void enter_po_for_new_order(DataTable tabledata) throws InterruptedException, AWTException
    {
         HelpersMethod.Implicitwait(driver,20);///40
         HelpersMethod.WaitElementPresent(driver,"id","orderEntryCard",20);/////8
        newOE = new NewOrderEntryPage(driver,scenario);
        PageTitle=HelpersMethod.gettingTitle(driver);
       // Assert.assertEquals(PageTitle,"Ignition - Order Entry");
        List<List<String>> PO_No = tabledata.asLists(String.class);
        newOE.EnterPO_No(PO_No.get(0).get(0));
    }

    //For entering Qty in catalog, based on catalog display. i.e. card catalog/list catalog
    @Then("Enter the Qty in the Product grid Case and Unit")
    public void enter_the_qty_in_the_product_grid_Case_and_Unit(DataTable tabledata) throws Throwable
    {
        newOE = new NewOrderEntryPage(driver,scenario);
        List<List<String>> ProQty = tabledata.asLists(String.class);
        newOE.EnterQty(ProQty.get(0).get(0), ProQty.get(0).get(1));
    }

    @Then("Click on Next button")
    public void click_on_next_button() throws InterruptedException, AWTException
    {
        exists=false;
        newOE = new NewOrderEntryPage(driver,scenario);
        //newOE.ReadProductNo();
        exists=newOE.ClickNext();
        Assert.assertEquals(exists,true);
        newOE.OutOfStockPop_ERP();
        checkorder=new CheckOutOrderPage(driver,scenario);
        checkorder.Select_PaymentMethod_ClickDownArrow();
        if(checkorder.Verify_Existence_of_ContinuePayment())
        {
            checkorder.Click_On_Without_Providing_Payment();
        }
        checkorder.DeliveryAddressCard();
        checkorder.NextButton_Click();
    }

    @Then("Click on Next after editing order All order")
    public void ClickOnNextAfterEditingOrderAllOrder() throws InterruptedException, AWTException
    {
        exists=false;
        newOE = new NewOrderEntryPage(driver,scenario);
        exists=newOE.ClickNext();
        Assert.assertEquals(exists,true);
        checkorder=new CheckOutOrderPage(driver,scenario);
        checkorder.Select_PaymentMethod_ClickDownArrow();
        if(checkorder.Verify_Existence_of_ContinuePayment())
        {
            checkorder.Click_On_Without_Providing_Payment();
        }
        checkorder.DeliveryAddressCard();
        checkorder.NextButton_Click();
    }

    @Then("Click on SubmitOrder button")
    public void click_on_submit_order_button() throws InterruptedException, AWTException
    {
        summary = new CheckOutSummaryPage(driver,scenario);
        summary.ClickSubmit();
        summary.SucessPopup();
    }

    @Then("Click on Submit Order button and read Order_no")
    public void click_on_submit_order_button_and_read_order_no() throws InterruptedException, AWTException
    {
        summary = new CheckOutSummaryPage(driver,scenario);
        summary.ClickSubmit();
        Ord_No = summary.Get_Order_No();
        summary.SucessPopup();
    }

    @Then("User should be navigated to Order Entry page")
    public void user_should_be_navigated_to_order_entry_page() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        orderpage.Verify_OEPage();
        orderpage.Verify_OE_Title();
    }

    @Then("Enter Pro# in Quick Product Entry area")
    //public void enter_pro_in_quick_product_entry_area(DataTable tabledata) throws InterruptedException, AWTException
    public void enter_pro_in_quick_product_entry_area() throws InterruptedException, AWTException, SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException
    {
        newOE = new NewOrderEntryPage(driver,scenario);
        newOE.QuickProduct(DataBaseConnection.DataBaseConn(TestBase.testEnvironment.getSingle_Prod_Sql()));
    }

    @Then("Click on Cancel button")
    public void click_on_cancel_button() throws InterruptedException, AWTException
    {
        newOE = new NewOrderEntryPage(driver,scenario);
        newOE.OECancel();
    }

    @Then("Check for Warning popup")
    public void check_for_warning_popup()
    {
        newOE.CancelPop();
    }

    @Then("Check for Skip button is visible and Click on Skip button")
    public void check_for_skip_button_is_visible_and_Click_on_Skip_button() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        orderpage.SkipVisible_Click();
    }

    //code to select skip reason in OE page
    @And("User should select reason for skip in popup")
    public void user_should_select_reason_for_skip_in_popup(DataTable tabledata) throws InterruptedException, AWTException
    {
        orderpage=new OrderEntryPage(driver, scenario);
        List<List<String>> Reason = tabledata.asLists(String.class);
        orderpage.OE_Skip_Reason(Reason.get(0).get(0));
    }

    @Then("Check for visibility of Remove Skip button")
    public void check_for_visibility_of_remove_skip_button() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        boolean visible = orderpage.CheckForRemoveSkip();
        Assert.assertEquals(visible, true);
    }

    @Then("Check for Remove Skip button is visible and Click on Remove Skip button")
    public void check_for_remove_skip_button_is_visible_and_click_on_skip_button() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        orderpage.ClickRemoveSkip();
    }

    @Then("Check for visibility of Skip button")
    public void check_for_visibility_of_skip_button() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        Assert.assertEquals(orderpage.CheckForSkip(),true);
    }

    @Then("Check for Case and Unit input box enabled or not based on that enter value")
    public void check_for_case_and_unit_input_box_enabled_or_not_based_on_that_enter_value(DataTable tabledata) throws InterruptedException, AWTException
    {
        newOE=new NewOrderEntryPage(driver,scenario);
        List<List<String>> PO_Qty = tabledata.asLists(String.class);
        String Case=PO_Qty.get(0).get(0);
        String Unit=PO_Qty.get(0).get(1);
        newOE.CheckForQuickCaseEnabled(Case);
        newOE.CheckForQuickUnitEnabled(Unit);
    }

    @Then("Click on Back button")
    public void click_on_back_button() throws InterruptedException, AWTException
    {
        newOE=new NewOrderEntryPage(driver,scenario);
        newOE.Click_Back_But();
    }

    @Then("Popup message for Pending order should be displayed")
    public void popup_message_for_pending_order_should_be_displayed()
    {
        newOE.Create_Pending_Order_Popup();
    }

    @Then("Discard all Pending order should be displayed")
    public void discard_all_pending_order_should_be_displayed()
    {newOE.Discard_All_Pending_Order();}

    @Then("Click on Skip button in New order entry page and also select the reason")
    public void click_on_skip_button_in_new_order_entry_page_and_also_select_the_reason(DataTable tabledata) throws InterruptedException, AWTException
    {
        newOE=new NewOrderEntryPage(driver,scenario);
        List<List<String>> Reason = tabledata.asLists(String.class);
        newOE.New_OE_Click_Skip_Button(Reason.get(0).get(0));
    }

    @Then("Click on History button")
    public void click_on_history_button() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        orderpage.Click_HistoryButton();
    }

    @Then("User verifies Order history page and click on checkbox")
    public void user_verifies_order_history_page() throws InterruptedException, AWTException
    {
        orderhistory=new OrderHistoryPage(driver,scenario);
        exists=orderhistory.VerifiyHistoryGrid();
        Assert.assertEquals(exists,true);

        //code to select first order in order history
        WebElement OrderHist=HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row')][1]/descendant::input[contains(@class,'k-checkbox')]");
        HelpersMethod.ActClick(driver,OrderHist,1);
    }

    @Then("Enter order# in search box in Order History page")
    public void enter_order_in_search_box_in_order_history_page(DataTable tabledata) throws InterruptedException, AWTException
    {
        orderhistory=new OrderHistoryPage(driver,scenario);
        HelpersMethod.Implicitwait(driver,15);
        List<List<String>> Ord_num = tabledata.asLists(String.class);
        orderhistory.SearchBox_Entry(Ord_num.get(0).get(1));
    }

    @Then("Click on check box in the Order grid")
    public void click_on_check_box_in_the_order_grid()
    {
        orderhistory.Check_Box();
    }

    @Then("Click on Copy button")
    public void click_on_copy_button() throws InterruptedException
    {
        orderhistory.Copy_Button();
    }

    @Then("Enter Order# in Search box in Order Entry page")
    public void enter_order_in_search_box_in_order_entry_page() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        orderpage.Enter_OrderNo_Searchbox(Ord_No);
    }

    @Then("Click on Order number in Order Entry page")
    public void click_on_order_number_in_order_entry_page() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        orderpage.Select_Order_OrdersGrid();
    }

    @Then("Navigate to Summary order entry page")
    public void navigate_to_new_order_entry_page() throws InterruptedException, AWTException
    {
        summary = new CheckOutSummaryPage(driver,scenario);
        summary.Click_Edit();
        //Check for Delivery address page
        XPath="//div[@id='checkoutCard']";
        exists=HelpersMethod.IsExists(XPath,driver);
        if(exists==true)
        {
            XPath="CancelCheckoutButton";
            exists=HelpersMethod.IsExistsById(XPath,driver);
            if(exists==true)
            {
                //Click on back button
                HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver,"id","CancelCheckoutButton"),1);
            }
        }
    }

    @Then("Enter new product# in the quick product entry with qty")
    public void enter_new_product_in_the_quick_product_entry_with_qty(DataTable table) throws InterruptedException, AWTException, SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException
    {
        List<List<String>> ProdDetails=table.asLists(String.class);
        newOE=new NewOrderEntryPage(driver,scenario);
        newOE.QuickProduct(DataBaseConnection.DataBaseConn(TestBase.testEnvironment.getSingle_Prod_Sql()));
        String Case=ProdDetails.get(0).get(0);
        String Unit=ProdDetails.get(0).get(1);
        newOE.CheckForQuickCaseEnabled(Case);
        newOE.CheckForQuickUnitEnabled(Unit);
    }

    @Then("User should Select delivery date from popup")
    public void user_shold_select_delivery_date_from_popup()
    {
        // HelpersMethod.Implicitwait(driver,10);
        XPath="//div[contains(text(),'Select delivery date')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
        exists=HelpersMethod.IsExists(XPath,driver);
        if(exists==true)
        {
            HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver,"xpath","//div[contains(@id,'dialog-title')]/following-sibling::div[contains(@class,'k-dialog-content')]/descendant::tr[2]"),1);
        }
    }

    @Then("Select New order option from popup")
    public void select_new_order_option_from_popup()
    {
        HelpersMethod.Implicitwait(driver,5);
        WebElement WebEle=null;
        XPath="//h4[contains(text(),'Select order')]/ancestor::div[contains(@class,'modal-content')]";
        exists=HelpersMethod.IsExists(XPath,driver);
        //handling Select order no. popup
        if(exists==true)
        {
            WebEle=HelpersMethod.FindByElement(driver,"xpath","//button[contains(text(),'New order')]");
            HelpersMethod.ClickBut(driver,WebEle,1);
        }
        HelpersMethod.Implicitwait(driver,2);

        XPath="//p[text()='Notes']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
        exists=HelpersMethod.IsExists(XPath,driver);
        //handling note popup
        if(exists==true)
        {
            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
            HelpersMethod.ClickBut(driver,WebEle,2);
        }
    }

    @Then("User should enter Units and Cases in product grid")
    public void user_should_enter_units_and_cases_in_product_grid(DataTable tabledata) throws InterruptedException, AWTException
    {
        List<List<String>> ProdDetails=tabledata.asLists(String.class);
        newOE=new NewOrderEntryPage(driver,scenario);
        String Case=ProdDetails.get(0).get(1);
        String Unit=ProdDetails.get(0).get(0);
        newOE.Enter_Qty_InGrid(Unit,Case);
    }

    @When("User clicks on drop down next to Start order button")
    public void user_clicks_on_drop_down_next_to_start_order_button() throws InterruptedException, AWTException
    {
       //////////// Thread.sleep(1000);
        orderpage = new OrderEntryPage(driver, scenario);
        orderpage.Click_DropDown();
    }

    @Then("Select Par Order from drop down options")
    public void select_par_order_from_drop_down_options() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
     ///////   HelpersMethod.Implicitwait(driver,5);
        orderpage.Select_Par_Order();
    }

    //Code for Exporting order
    @Then("navigate to newOE page and Click on Export button")
    public void navigate_to_newoe_page_and_click_on_export_button() throws InterruptedException, AWTException
    {
        newOE=new NewOrderEntryPage(driver,scenario);
        Ord_No=newOE.Export_button();
    }

    //Click on Edit button in Order summary page
    @And("Click on Edit button")
    public void click_on_edit_button() throws InterruptedException, AWTException
    {
        summary = new CheckOutSummaryPage(driver,scenario);
        summary.Click_Edit();
    }

    @And("Click on Back button in Checkout Card page")
    public void click_on_back_button_in_checkout_card_page() throws InterruptedException, AWTException
    {
        newOE=new NewOrderEntryPage(driver,scenario);
        newOE.Click_on_BackButton();
    }

    //for imorting .csv file from local system. I am using same folder that has been exported
    @And ("Click on Import button")
    public void click_on_import_button() throws InterruptedException, AWTException
    {
        newOE=new NewOrderEntryPage(driver,scenario);
        newOE.Import_button(Ord_No);
    }

    @Then("Add Qty for first product in product grid")
    public void add_qty_for_first_product_in_product_grid(DataTable tabledata) throws InterruptedException, AWTException
    {
        newOE=new NewOrderEntryPage(driver,scenario);
        List<List<String>> ProdQty=tabledata.asLists(String.class);
        String Qty=ProdQty.get(0).get(0);
        newOE.QtyProdGrid(Qty);
    }

    @Then("User Should handle Pending order popup, and select continue with pending order button")
    public void userShouldHandlePendingOrderPopupAndSelectContinueWithPendingOrderButton() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        orderpage.ContinuePendingOrderFromPopup();
        orderpage.NO_NotePopup();
        orderpage.OrderGuidePopup();
    }
}
