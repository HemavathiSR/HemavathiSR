package stepDefination_DSD_OMS.CatalogPage;

import helper.HelpersMethod;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import pages_DSD_OMS.Catalog.CatalogPage;
import pages_DSD_OMS.Catalog.ProductDescriptionPage;
import pages_DSD_OMS.orderEntry.CheckOutOrderPage;
import pages_DSD_OMS.orderEntry.NewOrderEntryPage;
import pages_DSD_OMS.orderEntry.OrderEntryPage;
import util.DataBaseConnection;
import util.TestBase;

import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class CatalogPageStep
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;

    static boolean exists = false;

    OrderEntryPage orderpage;
    CatalogPage catalogpage;
    NewOrderEntryPage newOE;
    CheckOutOrderPage checkorder;
    ProductDescriptionPage productdesctiptionpage;

    @Before
    public void LaunchBrowser1(Scenario scenario) throws Exception
    {
        this.scenario = scenario;
        TestBase driver1 = TestBase.getInstanceOfDriver();
        driver = driver1.getDriver();
    }

    //Verify whether User is on OE page or not
    @Given("User must be on Order Entry Page to select Catalog")
    public void user_must_be_on_order_entry_page_to_select_catalog() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        orderpage.HandleError_Page();
        orderpage.Refresh_Page();
        newOE = new NewOrderEntryPage(driver,scenario);
        newOE.Click_Back_But();
    }

    //Click on Catalog tab
    @And("User should navigate to Catalog tab")
    public void user_should_navigate_to_catalog_tab() throws InterruptedException
    {
        if (HelpersMethod.EleDisplay(HelpersMethod.FindByElement(driver, "xpath", "//li[contains(@class,'k-item')]/span[@class='k-link' and contains(text(),'Catalog')]")))
        {
            Thread.sleep(10000);
            HelpersMethod.navigate_Horizantal_Tab(driver, "Catalog", "//li[contains(@class,'k-item')]/span[@class='k-link' and contains(text(),'Catalog')]", "xpath", "//li[contains(@class,'k-item')]/span[@class='k-link']");
            Thread.sleep(25000);
            catalogpage = new CatalogPage(driver, scenario);
            boolean result = catalogpage.ValidateCatalog();
            Assert.assertEquals(result, true);
        }
        else
        {
            scenario.log("CATALOG TAB IS NOT VISIBLE");
        }
    }

    //Click on Resetfilter and validate the page, and click on List view
    @And("User should click on Reset filter button and all the products should displayed in List view in Catalog page")
    public void user_should_click_on_reset_filter_button_and_all_the_products_should_displayed_in_list_view_in_catalog_page()
    {
        catalogpage = new CatalogPage(driver, scenario);
        catalogpage.Click_ResetFilterButton();
        catalogpage.Click_ListView();
    }

    @And("User should click on Reset filter button and all the products should displayed")
    public void user_should_click_on_reset_filter_button_and_all_the_products_should_displayed()
    {
        try
        {
            catalogpage = new CatalogPage(driver, scenario);
            catalogpage.Click_ResetFilterButton();
        }
        catch (Exception e) {}
    }

    @Then("User enters Product# in Search bar")
    public void enter_product_in_search_bar() throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException
    {
        catalogpage = new CatalogPage(driver, scenario);
        String pro = DataBaseConnection.DataBaseConn(TestBase.testEnvironment.getSingle_Prod_Sql());
        catalogpage.SearchProduct(pro);
    }

    //Code for searching of product using product description
    @Then("User enters Product description in Search bar")
    public void enter_product_description_in_search_bar() throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        catalogpage = new CatalogPage(driver, scenario);
        String pro = DataBaseConnection.DataBaseConn(TestBase.testEnvironment.get_ProdDesc());
        catalogpage.SearchProduct(pro);
    }

    //Enter the single product details
    @Then("User enters Product# in Search bar and enters Qty for single Product")
    public void user_enters_product_in_search_bar_and_enters_qty_for_single_product(DataTable tabledata) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException
    {
        List<List<String>> Prod_detail = tabledata.asLists(String.class);
        catalogpage = new CatalogPage(driver, scenario);
        String pro = DataBaseConnection.DataBaseConn(TestBase.testEnvironment.getSingle_Prod_Sql());
        catalogpage.SearchProduct(pro);
        exists = HelpersMethod.IsExists("//div[contains(text(),'Sorry, no products matched')]", driver);
        if (exists == true) {
            HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver, "xpath", "//span[contains(@class,'search-button')]/*[local-name()='svg']/*[local-name()='path' and contains(@d,'M17')]"),1);
            HelpersMethod.Implicitwait(driver, 10);
        } else if (exists == false) {
            catalogpage.ProductExistsCard(Prod_detail.get(0).get(0), Prod_detail.get(0).get(1));
        }
    }

    //Click on sort by best match drop down and select "Sort by price (ascending)" option
    //Sort the values in list catalog in ascending order
    @Then("Click on sort by best match and select ascending order and verify the same from Catalog page")
    public void click_on_sort_by_best_match_and_select_ascending_order_and_verify_the_same_from_catalog_page(DataTable tabledata)
    {
        List<List<String>> Best_Match = tabledata.asLists(String.class);
        catalogpage = new CatalogPage(driver, scenario);
        boolean result = catalogpage.Best_MatchDropDown(Best_Match.get(0).get(0));
        Assert.assertEquals(result, true);
    }

    //Code to click on Reset filter, and navigate to Card view
    @And("User should click on Reset filter button and all the products should displayed in Card view in Catalog page")
    public void user_should_click_on_reset_filter_button_and_all_the_products_should_displayed_in_card_view_in_catalog_page() {
        catalogpage = new CatalogPage(driver, scenario);
        catalogpage.Click_ResetFilterButton();
        catalogpage.Click_CardView();
    }

    //Code to Search for product
    @Then("User enters Product# in Search bar and enters Qty")
    public void user_enters_product_in_search_bar_and_enters_qty(DataTable tabledata) throws SQLException {
        List<List<String>> Prod_detail = tabledata.asLists(String.class);
        ArrayList<String> Prod_No = (ArrayList<String>) DataBaseConnection.DataConn1(TestBase.testEnvironment.getMultiple_Prod_Sql());
        catalogpage = new CatalogPage(driver, scenario);
        for (int i = 0; i <= Prod_No.size() - 1; i++)
        {
            HelpersMethod.Implicitwait(driver, 10);
            String pro = String.valueOf(Prod_No.get(i));
            catalogpage.SearchProduct(pro);
            exists = HelpersMethod.IsExists("//div[contains(text(),'Sorry, no products matched')]", driver);
            if (exists == true)
            {
                HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver, "xpath", "//span[contains(@class,'search-button')]/*[local-name()='svg']/*[local-name()='path' and contains(@d,'M17')]"),1);
                HelpersMethod.Implicitwait(driver, 10);
            }
            else if (exists == false)
            {
                catalogpage.ProductExistsCard(Prod_detail.get(i).get(0), Prod_detail.get(i).get(1));
            }
        }
    }

    //code to click on cart and click on checkout to order
    @Then("User click on cart in catalog and click on Gotocart")
    public void user_click_on_cart_in_catalog_and_click_on_gotocart() throws InterruptedException, AWTException {
        catalogpage = new CatalogPage(driver, scenario);
        HelpersMethod.Implicitwait(driver, 25);
        boolean result = catalogpage.Cart_Button();
        Assert.assertEquals(result, true);
        HelpersMethod.Implicitwait(driver, 25);
        catalogpage.GotoCartClick();
        result = catalogpage.Checkout_to_order();
        Assert.assertEquals(result, true);
        catalogpage.NewOrder_Option();
        HelpersMethod.Implicitwait(driver, 15);
        checkorder = new CheckOutOrderPage(driver, scenario);
        if (checkorder.VerifyCheckOut()) {
            checkorder.BackButton_Click();
        }
    }

    //Click on Delete Icon, that displays in card view. Delete button of 1st product that has been added will be clicked
    @Then("User enters Product# in Search bar and enter Qty and click on Delete button")
    public void user_enters_product_in_search_bar_and_enter_qty_and_click_on_delete_button(DataTable tabledata) throws SQLException, InterruptedException
    {
        WebElement WebEle=null;
        HelpersMethod.Implicitwait(driver, 8);
        List<List<String>> Prod_detail = tabledata.asLists(String.class);
        ArrayList<String> Prod_No = (ArrayList<String>) DataBaseConnection.DataConn1(TestBase.testEnvironment.getMultiple_Prod_Sql());

        catalogpage = new CatalogPage(driver, scenario);
        for (int i = 0; i <= Prod_No.size() - 1; i++)
        {
            HelpersMethod.Implicitwait(driver, 10);
            String pro = String.valueOf(Prod_No.get(i));
            catalogpage.SearchProduct(pro);
            exists = HelpersMethod.IsExists("//div[contains(text(),'Sorry, no products matched')]", driver);
            if (exists == true)
            {
                WebEle=HelpersMethod.FindByElement(driver, "xpath", "//span[contains(@class,'search-button')]/*[local-name()='svg']/*[local-name()='path' and contains(@d,'M17')]");
                HelpersMethod.ClickBut(driver,WebEle,1);
                HelpersMethod.Implicitwait(driver, 10);
            }
            else if (exists == false)
            {
                catalogpage.ProductExistsCard(Prod_detail.get(i).get(0), Prod_detail.get(i).get(1));
                if (i == 1)
                {
                    WebEle=HelpersMethod.FindByElement(driver, "xpath", "//*[local-name()='svg']/*[local-name()='path' and contains(@d,'M16 ')]");
                    HelpersMethod.ActClick(driver,WebEle, 0);
                    WebEle=HelpersMethod.FindByElement(driver, "xpath", "//span[contains(@class,'search-button')]/*[local-name()='svg']/*[local-name()='path' and contains(@d,'M17')]");
                    HelpersMethod.ClickBut(driver,WebEle,1);
                }
            }
        }
    }

    //Delete product from Shopping cart popup
    @Then("User click on cart in catalog and click on Gotocart, before that Delete Product from popup")
    public void user_click_on_cart_in_catalog_and_click_on_gotocart_before_that_delete_product_from_popup() throws InterruptedException, AWTException
    {
        catalogpage = new CatalogPage(driver, scenario);
        HelpersMethod.Implicitwait(driver, 5);
        boolean result = catalogpage.Cart_Button();
        Assert.assertEquals(result, true);
        HelpersMethod.Implicitwait(driver,20);
        catalogpage.DeleteProd_GotoCartClick();
        catalogpage.ClickGotoCart1();
        HelpersMethod.Implicitwait(driver,30);
        result = catalogpage.Checkout_to_order();
        Assert.assertEquals(result, true);
        catalogpage.NewOrder_Option();
        HelpersMethod.Implicitwait(driver, 10);
        checkorder = new CheckOutOrderPage(driver, scenario);
        if (checkorder.VerifyCheckOut())
        {
            checkorder.BackButton_Click();
        }
    }

    //Code for adding product to cart from catalog tab, Delete product from my cart page
    @Then("User click on cart in catalog and click on Gotocart, Delete product from Mycart page")
    public void user_click_on_cart_in_catalog_and_click_on_gotocart_delete_product_from_Mycart_page() throws InterruptedException, AWTException
    {
        catalogpage = new CatalogPage(driver, scenario);
        HelpersMethod.Implicitwait(driver, 40);
        boolean result = catalogpage.Cart_Button();
        Assert.assertEquals(result, true);
        HelpersMethod.Implicitwait(driver, 5);
        catalogpage.GotoCartClick();
        catalogpage.DeleteMyCart();
        result = catalogpage.Checkout_to_order();
        Assert.assertEquals(result, true);
        catalogpage.NewOrder_Option();
        HelpersMethod.Implicitwait(driver, 10);
        checkorder = new CheckOutOrderPage(driver, scenario);
        if (checkorder.VerifyCheckOut()) {
            checkorder.BackButton_Click();
        }
    }

    //While creating order should select Order#
    @Then("User click on cart in catalog and click on Gotocart and select existing order")
    public void user_click_on_cart_in_catalog_and_click_on_gotocart_and_select_existing_order() throws InterruptedException, AWTException
    {
        catalogpage = new CatalogPage(driver, scenario);
        HelpersMethod.Implicitwait(driver, 20);
        boolean result = catalogpage.Cart_Button();
        Assert.assertEquals(result, true);
        HelpersMethod.Implicitwait(driver, 5);
        catalogpage.GotoCartClick();
        result = catalogpage.Checkout_to_order();
        Assert.assertEquals(result, true);
        catalogpage.AddProductToOrder();
        HelpersMethod.Implicitwait(driver, 10);
        checkorder = new CheckOutOrderPage(driver, scenario);
        if (checkorder.VerifyCheckOut()) {
            checkorder.BackButton_Click();
        }
    }

    @And("User clicks on product image and enters Qty in Description page")
    public void user_clicks_on_product_image_and_enters_qty_in_description_page(DataTable tabledata)
    {
        List<List<String>> Qty = tabledata.asLists(String.class);
        catalogpage = new CatalogPage(driver, scenario);
        catalogpage.ClickImage();
        productdesctiptionpage = new ProductDescriptionPage(driver, scenario);
        productdesctiptionpage.Qty_Inputbox(Qty.get(0).get(0));
        productdesctiptionpage.Increase_Descrease();
    }

    //Enter Product# in search bar and click on product images
    @Then("User enters different Product# in Search bar and enter Qty by clicking image")
    public void user_enters_product_in_search_bar_and_enter_qty_by_clicking_image(DataTable tabledata) throws SQLException
    {
        HelpersMethod.Implicitwait(driver, 8);
        ArrayList<String> Prod_No = (ArrayList<String>) DataBaseConnection.DataConn1(TestBase.testEnvironment.getMultiple_Prod_Sql());
        List<List<String>> Qty = tabledata.asLists(String.class);

        catalogpage = new CatalogPage(driver, scenario);
        for (int i = 0; i <= Prod_No.size() - 1; i++) {
            HelpersMethod.Implicitwait(driver, 10);
            String pro = String.valueOf(Prod_No.get(i));
            catalogpage.SearchProduct(pro);
            exists = HelpersMethod.IsExists("//div[contains(text(),'Sorry, no products matched')]", driver);
            if (exists == true) {
                HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver, "xpath", "//span[contains(@class,'search-button')]/*[local-name()='svg']/*[local-name()='path' and contains(@d,'M17')]"),1);
                HelpersMethod.Implicitwait(driver, 10);
            } else if (exists == false) {
                catalogpage = new CatalogPage(driver, scenario);
                catalogpage.ClickImage();
                productdesctiptionpage = new ProductDescriptionPage(driver, scenario);
                productdesctiptionpage.Qty_Inputbox(Qty.get(i).get(0));
                productdesctiptionpage.Back_to_Catalog();
            }
        }
    }

    @Then("User enters different Product# in Search bar and enter Qty by clicking image and click Delete product")
    public void user_enters_different_product_in_search_bar_and_enter_qty_by_clicking_image_and_click_delete_product(DataTable tabledata) throws SQLException
    {
        HelpersMethod.Implicitwait(driver, 8);
        ArrayList<String> Prod_No = (ArrayList<String>) DataBaseConnection.DataConn1(TestBase.testEnvironment.getMultiple_Prod_Sql());
        List<List<String>> Qty = tabledata.asLists(String.class);

        catalogpage = new CatalogPage(driver, scenario);
        for (int i = 0; i <= Prod_No.size() - 1; i++) {
            HelpersMethod.Implicitwait(driver, 10);
            String pro = String.valueOf(Prod_No.get(i));
            catalogpage.SearchProduct(pro);
            exists = HelpersMethod.IsExists("//div[contains(text(),'Sorry, no products matched')]", driver);
            if (exists == true) {
                HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver, "xpath", "//span[contains(@class,'search-button')]/*[local-name()='svg']/*[local-name()='path' and contains(@d,'M17')]"),1);
                HelpersMethod.Implicitwait(driver, 10);
            } else if (exists == false) {
                catalogpage = new CatalogPage(driver, scenario);
                catalogpage.ClickImage();
                productdesctiptionpage = new ProductDescriptionPage(driver, scenario);
                productdesctiptionpage.Qty_Inputbox(Qty.get(i).get(0));
                if (i == 0)
                {
                    productdesctiptionpage.Delete_Icon();
                }
                productdesctiptionpage.Back_to_Catalog();
            }
        }
    }
}
