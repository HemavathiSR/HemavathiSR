package stepDefination_DSD_OMS.CatalogPage;

import helper.HelpersMethod;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import pages_DSD_OMS.Catalog.CatalogPage;
import pages_DSD_OMS.Catalog.ProductDescriptionPage;
import pages_DSD_OMS.orderEntry.CheckOutOrderPage;
import pages_DSD_OMS.orderEntry.NewOrderEntryPage;
import pages_DSD_OMS.orderEntry.OrderEntryPage;
import util.DataBaseConnection;
import util.TestBase;

import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class CatalogPageStep1
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    String XPath=null;
    static boolean exists=false;
    Scenario scenario;

    OrderEntryPage orderpage;
    CatalogPage catalogpage;
    NewOrderEntryPage newOE;
    CheckOutOrderPage checkorder;
    ProductDescriptionPage productdesctiptionpage;

    @Before
    public void LaunchBrowser1(Scenario scenario) throws Exception
    {
        this.scenario=scenario;
        scenario.log("Launched the browser");
        TestBase driver1=TestBase.getInstanceOfDriver();
        driver= driver1.getDriver();
    }

    //Code for finding product# which are separated by comma
    @Then("User enters Product# in Search bar separated by comma and Read the product# available in catalog")
    public void user_enters_product_in_search_bar_separated_by_comma_and_read_the_product_available_in_catalog() throws SQLException
    {
        HelpersMethod.Implicitwait(driver,8);
        ArrayList<String> Prod_No= (ArrayList<String>) DataBaseConnection.DataConn1(TestBase.testEnvironment.getMultiple_Prod_Sql());

        catalogpage=new CatalogPage(driver,scenario);
        boolean result=catalogpage.EnterProdSeparatedByComma(Prod_No);
        Assert.assertEquals(result,true);
    }

    //Code to increase or decrease the Qty, in My cart page
    @Then("User click on cart in catalog and click on Gotocart, Press Plus and Minus buttons")
    public void user_click_on_cart_in_catalog_and_click_on_gotocart_press_plus_and_minus_button() throws InterruptedException, AWTException
    {
        catalogpage=new CatalogPage(driver,scenario);
        HelpersMethod.Implicitwait(driver, 35);
        boolean result=catalogpage.Cart_Button();
        this.scenario.log("\n \n Cart Icon has been clicked");

        Assert.assertEquals(result,true);
        HelpersMethod.Implicitwait(driver,10);
        catalogpage.GotoCartClick();
        catalogpage.PlusMinus();

        result=catalogpage.Checkout_to_order();
        Assert.assertEquals(result,true);
        catalogpage.NewOrder_Option();
        HelpersMethod.Implicitwait(driver,25);
        checkorder=new CheckOutOrderPage(driver,scenario);
        if(checkorder.VerifyCheckOut())
        {
            checkorder.BackButton_Click();
        }
    }

    @Then("User should click on Category dropdown and select any of the category")
    public void user_should_click_on_category_dropdown_and_select_any_of_the_category()
    {
        catalogpage=new CatalogPage(driver,scenario);
        HelpersMethod.Implicitwait(driver, 35);
        catalogpage.CatalogCategoryDropDown();
    }

    @Then("User should click on SubCategory dropdown and select any of the category")
    public void user_should_click_on_subcategory_dropdown_and_select_any_of_the_category()
    {
        catalogpage=new CatalogPage(driver,scenario);
        HelpersMethod.Implicitwait(driver, 35);
        catalogpage.CatalogSubCategoryDropDown();
    }

    @Then("User should click on Brand dropdown and select any of the category")
    public void user_should_click_on_brand_dropdown_and_select_any_of_the_category()
    {
        catalogpage=new CatalogPage(driver,scenario);
        HelpersMethod.Implicitwait(driver, 35);
        catalogpage.BrandDropDown();
    }

    @Then ("User should click on Order Guide dropdown and select any of the category")
    public void user_should_click_on_order_guide_dropdown_and_select_any_of_the_category()
    {
        catalogpage=new CatalogPage(driver,scenario);
        HelpersMethod.Implicitwait(driver, 35);
        catalogpage.OGDropDown();
    }

    @And("User should read all the products available catalog page")
    public void user_should_read_all_the_products_available_catalog_page()
    {
        catalogpage=new CatalogPage(driver,scenario);
        HelpersMethod.Implicitwait(driver, 35);
        catalogpage.ReadProduct();
    }

    @Then("User reads all the products listed under featured products")
    public void user_reads_all_the_products_listed_under_featured_products()
    {
        catalogpage=new CatalogPage(driver,scenario);
        HelpersMethod.Implicitwait(driver, 35);
        catalogpage.FeaturedReadProduct();
    }

    @Then("User reads all the products listed under recent search card")
    public void user_reads_all_the_products_listed_under_recent_search_card()
    {
        catalogpage=new CatalogPage(driver,scenario);
        HelpersMethod.Implicitwait(driver, 35);
        catalogpage.RecentSearch();
    }

    @And("User clicks on Resetfilter to list all the products")
    public void user_clicks_on_resetfilter_to_list_all_the_products()
    {
        catalogpage=new CatalogPage(driver,scenario);
        HelpersMethod.Implicitwait(driver, 35);
        catalogpage.Click_ResetFilterButton();
    }

    @Then("User clicks on product details to navigate to Description page")
    public void user_clicks_on_product_details_to_navigate_to_description_page()
    {
        catalogpage=new CatalogPage(driver,scenario);
        HelpersMethod.Implicitwait(driver, 35);
        exists=false;
        exists=HelpersMethod.IsExists("//div[@class='card-view']",driver);
        if(exists==true)
        {
          WebElement Element =HelpersMethod.FindByElement(driver,"xpath","//div[@class='card-view']/descendant::div[@class='product-catalog-image-and-number-and-price-container'][1]");
          HelpersMethod.ClickBut(driver,Element,1);
        }
        else
        {
            exists=false;
            exists=HelpersMethod.IsExists("//div[@class='list-view']",driver);
            if(exists==true)
            {
                WebElement Element =HelpersMethod.FindByElement(driver,"xpath","//div[@class='list-view']/descendant::tr[contains(@class,'k-master-row')][1]/descendant::a/ancestor::td");
                HelpersMethod.ClickBut(driver,Element,1);
            }
        }
    }

    @And("User lists all the product numbers which comes under Frequently bought together")
    public void user_lists_all_the_product_numbers_which_comes_under_frequently_bought_together()
    {
        exists=false;
        productdesctiptionpage=new ProductDescriptionPage(driver,scenario);
        HelpersMethod.Implicitwait(driver, 35);
        productdesctiptionpage.FrequentlyBought();
    }



}
