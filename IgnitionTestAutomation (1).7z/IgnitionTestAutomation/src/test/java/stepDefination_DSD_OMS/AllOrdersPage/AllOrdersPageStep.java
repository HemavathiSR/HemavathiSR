package stepDefination_DSD_OMS.AllOrdersPage;

import gherkin.lexer.He;
import helper.HelpersMethod;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import pages_DSD_OMS.allOrder.AllOrderPage;
import pages_DSD_OMS.orderEntry.CheckOutOrderPage;
import pages_DSD_OMS.orderEntry.CheckOutSummaryPage;
import pages_DSD_OMS.orderEntry.NewOrderEntryPage;
import pages_DSD_OMS.orderEntry.OrderEntryPage;
import util.TestBase;

import java.awt.*;

/**
 * @Project OMS_DSD
 * @Author Divya.Ramadas@afsi.com
 */
public class AllOrdersPageStep
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;

    static boolean exists = false;
    static String Ord_No=null;

    OrderEntryPage orderpage;
    AllOrderPage allOrder;
    CheckOutSummaryPage summary;


    @Before
    public void LaunchBrowser1(Scenario scenario) throws Exception
    {
        this.scenario = scenario;
        TestBase driver1 = TestBase.getInstanceOfDriver();
        driver = driver1.getDriver();
    }

    @Given("User must be on Order Entry Page to select All Orders")
    public void userMustBeOnOrderEntryPageToSelectAllOrders() throws InterruptedException, AWTException
    {
        orderpage = new OrderEntryPage(driver, scenario);
        orderpage.HandleError_Page();
        orderpage.Refresh_Page();
    }

    @And("User should navigate to All Orders")
    public void userShouldNavigateToAllOrders() throws InterruptedException
    {
        try
        {
            HelpersMethod.Implicitwait(driver, 10);
            exists = false;
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//li[contains(@class,'k-item')]/span[@class='k-link' and contains(text(),'All Orders')]");
            if (HelpersMethod.EleDisplay(WebEle))
            {
                Thread.sleep(10000);
                HelpersMethod.navigate_Horizantal_Tab(driver, "All Orders", "//li[contains(@class,'k-item')]/span[@class='k-link' and contains(text(),'All Orders')]", "xpath", "//li[contains(@class,'k-item')]/span[@class='k-link']");
                HelpersMethod.Implicitwait(driver, 10);

                WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 50);

                HelpersMethod.waitTillLoadingPage(driver);

                allOrder = new AllOrderPage(driver, scenario);
                allOrder.ValidateAllOrder();
            }
        }
        catch (Exception e)
        {
            scenario.log("ALL ORDER TAB HAS NOT BEEN FOUND");
        }
    }

    @Then("User clicks on Show all orders check box")
    public void userClicksOnShowAllOrdersCheckBox()
    {
        HelpersMethod.Implicitwait(driver,60);
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.ClickShowAllOrderCheckbox();
    }

    @And("User Clicks on Add filter button and enter values for search options")
    public void userClicksOnAddFilterButtonAndEnterValuesForSearchOptions()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.AddFilterClick();
    }

    @Then("User clicks on Start order button and selects Add from drop down")
    public void userClicksOnStartOrderButtonAndSelectsAddFromDropDown()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.ClickOnStartOrder();
    }

    @Then("User selects customer account# and delivery date from popup")
    public void userSelectsCustomerAccountFromPopup()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.CustomerIndexPopup();
        allOrder.SelectDeliveryDate();
        allOrder.WarningChangeDeliveryDate();
        allOrder.SelectOrder();
    }

    @And("Click on Submit Order button and read Order_no created for All order")
    public void clickOnSubmitOrderButtonAndReadOrder_noCreatedForAllOrder() throws InterruptedException, AWTException
    {
        summary = new CheckOutSummaryPage(driver,scenario);
        summary.ClickSubmit();
        Ord_No = summary.Get_Order_No();
        summary.SucessPopup();
        scenario.log("ORDER CREATED IS "+Ord_No);
    }

    @Then("User should be navigated back to All order page")
    public void userShouldBeNavigatedBackToAllOrderPage()
    {
        allOrder = new AllOrderPage(driver, scenario);
        allOrder.ValidateAllOrder();
        HelpersMethod.Implicitwait(driver,60);
    }

    @Then("User clicks on Show all Quotes check box")
    public void userClicksOnShowAllQuotesCheckBox()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.ClickOnShowQuotes();
    }

    @And("User goes through all the order in Open order grid")
    public void userGoesThroughAllTheOrderInOpenOrderGrid()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.DisplayOrderNumbers();
    }

    @Then("USer should check for Comment icon")
    public void userShouldCheckForCommentIcon()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.ValidateCommentIcon();
    }

    @And("User Clicks on Add filter button and Search for OrderNo")
    public void userClicksOnAddFilterButtonAndSearchForOrderNo()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.ClickShowAllOrderCheckbox();
        allOrder.SearchNewlyCreatedOrder(Ord_No);
    }

    @Then("User clicks on Show all orders check box after Clicking All orders tab")
    public void userClicksOnShowAllOrdersCheckBoxAfterClickingAllOrdersTab()
    {
        HelpersMethod.Implicitwait(driver,60);
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.ClickShowAllOrderCheckbox1();
    }

    @And("then user clicks on All Order button in summary page and read order#")
    public void thenUserClicksOnAllOrderButtonInSummaryPageAndReadOrder() throws InterruptedException, AWTException
    {
        summary=new CheckOutSummaryPage(driver,scenario);
        Ord_No=summary.Get_Order_No();
        summary.ClickOnAllOrder();
    }

    @Then("User Clicks on the order# in All order grid")
    public void userClicksOnTheOrderInAllOrderGrid()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.ClickOnOrderInAllOrderGrid();
    }

    @And("User clicks on Show all orders check box again")
    public void userClicksOnShowAllOrdersCheckBoxAgain()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.ClickShowAllOrderCheckbox();
        allOrder.SearchNewlyCreatedOrder(Ord_No);
    }

    @Then("User clicks on OrderNo in All Order grid and he should be navigated Ordersummary page")
    public void userClicksOnOrderNoInAllOrderGridAndHeShouldBeNavigatedOrdersummaryPage()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.ClickOnOrderInAllOrderGrid();
        allOrder.NavigateToOrderSummaryPage();
    }

    @Then("User clicks on Back to Order list button and should be navigated to OE page")
    public void userClicksOnBackToOrderListButtonAndShouldBeNavigatedToOEPage()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.ClickOnBackToOrder();
    }

    @And("User enters orderNo That he has selected from order grid and validates it exists in order also")
    public void userEntersOrderNoThatHeHasSelectedFromOrderGridAndValidatesItExistsInOrderAlso() throws InterruptedException, AWTException
    {
        allOrder=new AllOrderPage(driver,scenario);
        String OrderNo=allOrder.ReadingOrderNo();
        orderpage=new OrderEntryPage(driver,scenario);
        HelpersMethod.Implicitwait(driver,10);
        orderpage.Enter_OrderNo_Searchbox(OrderNo);
        orderpage.Existence_OrderNo_OG();
    }

    @Then("User select the order and click on copy button and select delivery date")
    public void userSelectTheOrderAndClickOnCopyButtonAndSelectDeliveryDate()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.SelectOrderForCopying();
        allOrder.ClickOnCopyButton();
        allOrder.SelectDeliverDateForCopy();
        allOrder.SelectNewOrderInPopUp();
    }

    @And("User clicks on Submitted status and select Submitted option from drop down")
    public void userClicksOnSubmittedStatusAndSelectSubmittedOptionFromDropDown()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.SubmittedStatusDropDown();
        allOrder.SubmitOptionFromDropDown();
    }

    @And("User clicks on search button")
    public void userClicksOnSearchButton()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.ClickOnSearchButton();
    }

    @And("User clicks on Order status and select Active option from drop down")
    public void userClicksOnOrderStatusAndSelectActiveOptionFromDropDown()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.OrderStatusDropDown();
        allOrder.OrderOptionFromDropDown();
    }

    @And("User enters product# in input box")
    public void userEntersProductInInputBox()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.SearchProductInOrder();
        allOrder.ClickOnSearchButton();
    }

    @Then("User select the order and click on Print button")
    public void userSelectTheOrderAndClickOnPrintButton()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.SelectOrderForCopying();
        allOrder.PrintAllOrder();
    }

    @Then("User clicks on any of the order and verifies products")
    public void userClicksOnAnyOfTheOrderAndVerifiesProducts()
    {
        allOrder=new AllOrderPage(driver,scenario);
        allOrder.AddFilterClick();
        allOrder.ClickOnOrderInAllOrderGrid();
        allOrder.NavigateToOrderSummaryPage();
        allOrder.VerifyingProductsInOEWithOO();
    }
}
