package stepDefination_DSD_OMS.QuotePage;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import pages_DSD_OMS.orderEntry.*;
import pages_DSD_OMS.quote.NewQuotePage;
import pages_DSD_OMS.quote.QuotePage;
import pages_DSD_OMS.quote.QuoteSummaryPage;
import util.TestBase;

import java.awt.*;
import java.util.List;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */

public class QuotePageSteps
{
    /* Created by Divya.Ramadas@afsi.com */
    private static boolean flag = false;
    private static boolean flag1=false;
    WebDriver driver;
    Scenario scenario;



    static String XPath=null;
    static boolean exists=false;
    static String Ord_No=null;
    static String ProdNo=null;
    static String PageTitle=null;

    OrderEntryPage orderEntryPage;
    QuotePage quotePage;
    NewQuotePage newQuotePage;
    QuoteSummaryPage quoteSummaryPage;
    CheckOutSummaryPage summary;

    @Before
    public void LaunchBrowser1(Scenario scenario) throws Exception
    {
        this.scenario=scenario;
        TestBase driver1=TestBase.getInstanceOfDriver();
        driver= driver1.getDriver();
    }

    @Then("User enters Quote name {string} and Quote End date click on OK button")
    public void userEntersQuoteNameAndQuoteEndDateClickOnOKButton(String Quote)
    {
        quotePage=new QuotePage(driver,scenario);
        quotePage.EnterQuotName(Quote);
        quotePage.ClickOnCalender();
        quotePage.SelectEndDate();
        quotePage.ClickOnOKButton();
    }

    @Then("Enter Pro# in Quick Product Entry area in New Qutoe page and enter Qty for Case and Unit")
    public void enterProInQuickProductEntryAreaInNewQutoePageAndEnterQtyForCaseAndUnit(DataTable tabledata)
    {
      List<List<String>> QtyValue = tabledata.asLists(String.class);
      newQuotePage=new NewQuotePage(driver,scenario);
      newQuotePage.EnterQuickProductNo();
      newQuotePage.QtyInGrid(QtyValue.get(0).get(0),QtyValue.get(0).get(1));
    }

    @Then("Click on create button in New Quote page")
    public void clickOnCreateButtonInNewQuotePage()
    {
        newQuotePage=new NewQuotePage(driver,scenario);
        newQuotePage.ClickOnCreateButton();
    }

    @And("User click on Back to orderlist button from Quote summary page and Read order number")
    public void userClickOnBackToOrderlistButtonFromQuoteSummaryPageAndReadOrderNumber() throws InterruptedException, AWTException
    {
        summary =new CheckOutSummaryPage(driver,scenario);
        Ord_No=summary.Get_Order_No();
        quoteSummaryPage=new QuoteSummaryPage(driver,scenario);
        quoteSummaryPage.ClickOnBackToOrder();
    }

    @And("User clicks on drop down next to Start order button and select Quote option")
    public void userClicksOnDropDownNextToStartOrderButtonAndSelectQuoteOption() throws InterruptedException, AWTException
    {
        orderEntryPage = new OrderEntryPage(driver, scenario);
        orderEntryPage.Click_DropDown();
        orderEntryPage.SelectQuote();
    }

    @Then("Verify User is on Order Entry Page and verify Quote is existing")
    public void verifyUserIsOnOrderEntryPageAndVerifyQuoteIsExisting() throws InterruptedException, AWTException
    {
        orderEntryPage=new OrderEntryPage(driver,scenario);
        orderEntryPage.SearchBoxAction(Ord_No);
        orderEntryPage.ValidateQuoteOrder(Ord_No);
    }

    @Then("User selects Quote in Order Entry grid")
    public void userSelectsQuoteInOrderEntryGrid() throws InterruptedException, AWTException
    {
        orderEntryPage=new OrderEntryPage(driver,scenario);
        orderEntryPage.ClickOnQuote();
    }

    @And("User should be navigated to Quote summary page and click on Convert OG button")
    public void userShouldBeNavigatedToQuoteSummaryPageAndClickOnConvertOGButton()
    {
        quoteSummaryPage=new QuoteSummaryPage(driver,scenario);
        quoteSummaryPage.ClickOnConvertOG();
    }

    @And("User should be navigated to Quote summary page and click on Convert Order button")
    public void userShouldBeNavigatedToQuoteSummaryPageAndClickOnConvertOrderButton()
    {
        quoteSummaryPage=new QuoteSummaryPage(driver,scenario);
        quoteSummaryPage.ClickOnConvertOrder();
    }

    @And("User should be navigated to Quote summary page and click on cancel button")
    public void userShouldBeNavigatedToQuoteSummaryPageAndClickOnCancelButton()
    {
        quoteSummaryPage=new QuoteSummaryPage(driver,scenario);
        quoteSummaryPage.ClickOnCancel();
    }

    @Then("Click on Cancel button in New Quote page")
    public void clickOnCancelButtonInNewQuotePage()
    {
        newQuotePage=new NewQuotePage(driver,scenario);
        newQuotePage.ClickOnCancelButton();
    }

    @And("User clicks on Plus symbol in new Quote page and selects Catalog option from drop down")
    public void userClicksOnPlusSymbolInNewQuotePageAndSelectsCatalogOptionFromDropDown()
    {
        newQuotePage=new NewQuotePage(driver,scenario);
        newQuotePage.ClickOnAddProduct();
        newQuotePage.SelectCatalog();
    }

    @Then("User addes some products from catalog")
    public void userAddesSomeProductsFromCatalog(DataTable tabledata)
    {
        List<List<String>> Qty=tabledata.asLists(String.class);
        newQuotePage=new NewQuotePage(driver,scenario);
        newQuotePage.SelectProductFromCatalog();
        newQuotePage.EnterProductQtyCatalog(Qty.get(0).get(0), Qty.get(0).get(1));
    }

    @And("User clicks on Plus symbol in new Quote page and selects OG option from drop down")
    public void userClicksOnPlusSymbolInNewQuotePageAndSelectsOGOptionFromDropDown()
    {
        newQuotePage=new NewQuotePage(driver,scenario);
        newQuotePage.ClickOnAddProduct();
        newQuotePage.SelectOG();
        newQuotePage.SelectOGFromPopup();
    }

    @Then("User enters some Qty to product in Product grid")
    public void userEntersSomeQtyToProductInProductGrid(DataTable tabledata)
    {
        List<List<String>> QtyValue = tabledata.asLists(String.class);
        newQuotePage=new NewQuotePage(driver,scenario);
        newQuotePage.QtyInGrid(QtyValue.get(0).get(0),QtyValue.get(0).get(1));
    }

    @Then("User click on Copy button in summary page and enter Quote name {string} and Click on Create button")
    public void userClickOnCopyButtonInSummaryPageAndEnterQuoteNameAndClickOnCreateButton(String Quote1)
    {
        quoteSummaryPage=new QuoteSummaryPage(driver,scenario);
        quoteSummaryPage.ClickOnCopy();
        quotePage=new QuotePage(driver,scenario);
        quotePage.EnterQuotName(Quote1);
        quotePage.ClickOnCalender();
        quotePage.SelectEndDate();
        quotePage.ClickOnOKButton();
        newQuotePage=new NewQuotePage(driver,scenario);
        newQuotePage.ClickOnCreateButton();
    }

    @And("User click on Print button")
    public void userClickOnPrintButton()
    {
        newQuotePage=new NewQuotePage(driver,scenario);
        newQuotePage.PrintQuote();
    }


    @Then("User should navigated to Order Entry page from OG page")
    public void userShouldNavigatedToOrderEntryPageFromOGPage()
    {
        quoteSummaryPage=new QuoteSummaryPage(driver,scenario);
        quoteSummaryPage.NavgiateBackToOE();

    }
}
