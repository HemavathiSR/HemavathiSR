package helper;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @Project DSD_OMS
 * @Author DivyaRamadas@afsi.com
 */
public class HelpersMethod
{
    /* Created by DivyaRamadas@afsi.com */
    public static WebElement FindByElement(WebDriver driver,String selector,String value)
    {
        WebElement element=null;
        try
        {
            if(selector.equalsIgnoreCase("id"))
            {
                element=driver.findElement(By.id(value));
            }
            else if(selector.equalsIgnoreCase("class"))
            {
                element=driver.findElement(By.className(value));
            }
            else if(selector.equalsIgnoreCase("xpath"))
            {
                element=driver.findElement(By.xpath(value));
            }
            else if(selector.equalsIgnoreCase("cssselector"))
            {
                element=driver.findElement(By.cssSelector(value));
            }
            else if(selector.equalsIgnoreCase("linktext"))
            {
                element=driver.findElement(By.linkText(value));
            }
            else if(selector.equalsIgnoreCase("partiallinkedtext"))
            {
                element=driver.findElement(By.partialLinkText(value));
            }
            else if(selector.equalsIgnoreCase("tagname"))
            {
                element=driver.findElement(By.tagName(value));
            }
        }
        catch (Exception e){}
        return element;
    }

    //Generic method for creating list of web elements
    public static List<WebElement> FindByElements(WebDriver driver,String selector,String value)
    {
        List<WebElement> elements=null;
            if(selector.equalsIgnoreCase("id"))
            {
                elements=driver.findElements(By.id(value));
            }
            else if(selector.equalsIgnoreCase("class"))
            {
                elements=driver.findElements(By.className(value));
            }
            else if(selector.equalsIgnoreCase("xpath"))
            {
                elements=driver.findElements(By.xpath(value));
            }
            else if(selector.equalsIgnoreCase("cssselector"))
            {
                elements=driver.findElements(By.cssSelector(value));
            }
            else if(selector.equalsIgnoreCase("linktext"))
            {
                elements=driver.findElements(By.linkText(value));
            }
            else if(selector.equalsIgnoreCase("partiallinkedtext"))
            {
                elements=driver.findElements(By.partialLinkText(value));
            }
            else if(selector.equalsIgnoreCase("tagname"))
            {
                elements=driver.findElements(By.tagName(value));
            }
        return elements;
    }

    public static void NavigateBack(WebDriver driver)
    {
            driver.navigate().back();
    }

    public static void Implicitwait(WebDriver driver, int sec)
    {driver.manage().timeouts().implicitlyWait(sec, TimeUnit.SECONDS);}


    public static boolean waitVisibilityOfEle(WebDriver driver, WebElement ele, int timeOut)
    {
        if(!ele.isDisplayed())
        {
            WebDriverWait wait = new WebDriverWait(driver, timeOut);
            wait.until(ExpectedConditions.visibilityOf(ele));
        }
        else
        {
            ElementNotVisibleException EleVis= new ElementNotVisibleException("Element not Visible");
            throw EleVis;
        }
        return true;
    }

    public static boolean waitClickableOfEle(WebDriver driver,WebElement ele,int timeOut)
    {
           if (!ele.isDisplayed())
            {
                WebDriverWait wait = new WebDriverWait(driver,timeOut);
                wait.until(ExpectedConditions.elementToBeClickable(ele));
            }
           else
           {
                ElementNotVisibleException EleVis = new ElementNotVisibleException("Element not Visible");
                throw EleVis;
            }
           return true;
    }

    public static void WaitElementPresent(WebDriver driver,String selector,String val,int timeOut)
    {
        WebDriverWait wait = new WebDriverWait(driver,timeOut);
            if(selector.equalsIgnoreCase("id"))
            {
               wait.until(ExpectedConditions.presenceOfElementLocated(By.id(val)));
            }
            else if(selector.equalsIgnoreCase("class"))
            {
               wait.until(ExpectedConditions.presenceOfElementLocated(By.className(val)));
            }
            else if(selector.equalsIgnoreCase("xpath"))
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(val)));
            }
            else if(selector.equalsIgnoreCase("cssselector"))
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(val)));
            }
            else if(selector.equalsIgnoreCase("linktext"))
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(val)));
            }
            else if(selector.equalsIgnoreCase("partiallinkedtext"))
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(val)));
            }
            else if(selector.equalsIgnoreCase("tagname"))
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName(val)));
            }
    }

    public static boolean EleDisplay(WebElement ele)
    {
        boolean display=false;
            if (ele.isDisplayed())
            {
                display =true;
            }
            else
            {
                display= false;
            }
        return display;
    }

    public static void ScrollElement(WebDriver driver, WebElement ele)
    {
        if(ele.isDisplayed())
        {((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", ele);}
        else
        {
            ElementNotVisibleException EleVis= new ElementNotVisibleException("Element not Visible");
            throw EleVis;
        }
    }

    public static void EnterText(WebDriver driver,WebElement element,int timeOut ,String val)
    {
            new WebDriverWait(driver,timeOut).until(ExpectedConditions.visibilityOf(element));
            if ((element.isDisplayed() && element.isEnabled()) == true)
            {
                element.sendKeys(val);
            }
    }

    public static void ClearText(WebDriver driver,WebElement element,int timeOut)
    {
            new WebDriverWait(driver,timeOut).until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed() && element.isEnabled() == true)
            {
                element.clear();
            }
            else
            {
                ElementNotVisibleException EleVis = new ElementNotVisibleException("Element not Visible");
                throw EleVis;
            }
    }

    public static void ClickBut(WebDriver driver,WebElement element,int timeOut)
    {
            new WebDriverWait(driver,timeOut).until(ExpectedConditions.elementToBeClickable(element));
            element.click();
    }

    public static void ActSendKey(WebDriver driver,WebElement element,int timeOut,String val) throws InterruptedException
    {
        new WebDriverWait(driver,timeOut).until(ExpectedConditions.visibilityOf(element));
                Actions act = new Actions(driver);
                act.moveToElement(element).build().perform();
                element.sendKeys(val);
                act.moveToElement(element).build().perform();
                element.sendKeys(Keys.TAB);
    }

    public static void ActClearKey(WebDriver driver,WebElement element,int timeOut)
    {
        new WebDriverWait(driver,timeOut).until(ExpectedConditions.visibilityOf(element));
                Actions act = new Actions(driver);
                act.click(element).sendKeys(Keys.END).keyDown(Keys.SHIFT).sendKeys(Keys.HOME).keyUp(Keys.SHIFT).sendKeys(Keys.BACK_SPACE).perform();
    }

    public static String ReadValue(WebElement ele)
    {
        String Read_Val=null;
            if (ele.isDisplayed())
            {
                Read_Val = ele.getText();
            }
            else
            {
                ElementNotVisibleException EleVis = new ElementNotVisibleException("Element not Visible");
                throw EleVis;
            }
            return Read_Val;
    }

    public static String AttributeValue(WebElement ele,String Attribute)
    {
        String Value;
            Value=ele.getAttribute(Attribute);
        return Value;
    }

    public static boolean IsExists(String ele,WebDriver driver)
    {
        try
        {
            driver.findElement(By.xpath(ele));
            return true;
        }
        catch (Exception e)
        {return false;}
    }

    public static boolean IsExistsById(String Id,WebDriver driver)
    {
        try
        {
            driver.findElement(By.id(Id));
            return  true;
        }
        catch (Exception e)
        {return false;}
    }

    public static void ActClick(WebDriver driver,WebElement element,int timeOut) throws InterruptedException
    {
            new WebDriverWait(driver,timeOut).until(ExpectedConditions.elementToBeClickable(element));
            Actions act = new Actions(driver);
            act.moveToElement(element).build().perform();
            act.click(element).build().perform();
    }

    public static void JScriptClick(WebDriver driver,WebElement element,int timeOut)
    {
        new WebDriverWait(driver,timeOut).until(ExpectedConditions.elementToBeClickable(element));
        if (element.isDisplayed() && element.isEnabled())
        {
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", element);
        }
        else
        {
            ElementNotVisibleException EleVis= new ElementNotVisibleException("Element not Visible");
            throw EleVis;
        }
    }

    public static void JSSetValueEle(WebDriver driver,WebElement element,int timeOut,String val)
    {
        new WebDriverWait(driver,timeOut).until(ExpectedConditions.visibilityOf(element));
        if(element.isDisplayed() && element.isEnabled())
        {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].value='"+val+"';", element);
        }
        else
        {
            ElementNotVisibleException EleVis= new ElementNotVisibleException("Element not Visible");
            throw EleVis;
        }
    }

    public static String JSGetValueEle(WebDriver driver,WebElement element,int timeOut)
    {
        new WebDriverWait(driver,timeOut).until(ExpectedConditions.visibilityOf(element));
        if(element.isDisplayed() && element.isEnabled())
        {
            JavascriptExecutor js=(JavascriptExecutor) driver;
            return js.executeScript("return arguments[0].value", element).toString();
        }
        else
        {
            ElementNotVisibleException EleVis= new ElementNotVisibleException("Element not Visible");
            throw EleVis;
        }
    }

    //To check whether element is enabled or not
    public static boolean IsEnabledById(String eleId, WebDriver driver)
    {
        boolean exists = false;
        WebElement ele = driver.findElement(By.id(eleId));
        if (ele.isEnabled())
        {
            exists = true;
        }
        return exists;
    }

    public static boolean IsEnabledByXpath(String eleXpath,WebDriver driver)
    {
        boolean exists=false;
        WebElement ele=driver.findElement(By.xpath(eleXpath));
        if(ele.isEnabled())
            {exists=true;}
        return exists;
    }

    public static boolean IsEnabledByele(WebElement ele)
    {
        boolean result=false;
        result=ele.isEnabled();
        return result;
    }

    public static void WebElementClearInput(WebElement element)
    {
            element.clear();
    }

    public static void WebElementFromDropDown(WebDriver driver,String ListElements,String ItemXpath,String ListElement) throws InterruptedException
    {
        Actions act=new Actions(driver);

            //Thread.sleep(1000);
            Implicitwait(driver,1);
            int i = 0;
            List<WebElement> ListItems = FindByElements(driver,ItemXpath,ListElements);
            for (WebElement ListItem : ListItems)
            {
                i++;
                //Thread.sleep(1500);//1000
                Implicitwait(driver,1);
                String List_Item_value = ListItem.getText();
                if (List_Item_value.equalsIgnoreCase(ListElement) || List_Item_value.contains(ListElement.toLowerCase()))
                {
                    act.moveToElement(ListItem).build().perform();
                  //  Thread.sleep(1000);//500
                    Implicitwait(driver,1);
                    ListItem.click();
                    break;
                }
            }
    }

    public static void JSScroll(WebDriver driver,WebElement ele)
    {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
    }

    public static void ActScroll(WebDriver driver,WebElement element,int timeOut)
    {
        new WebDriverWait(driver,timeOut).until(ExpectedConditions.elementToBeClickable(element));
            Actions act = new Actions(driver);
            act.moveToElement(element);
            act.perform();
    }

    public static void ActDragDrop(WebDriver driver,WebElement From,WebElement To)
    {
            Actions act=new Actions(driver);
            //Dragged and dropped.
            act.dragAndDrop(From, To).build().perform();
    }

    public static void FileUploadRobot() throws AWTException
    {
            Robot robot = new Robot();
            robot.setAutoDelay(10000);
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);

            robot.keyRelease(KeyEvent.VK_CONTROL);
            robot.keyRelease(KeyEvent.VK_V);

            robot.setAutoDelay(10000);

            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
    }

    public static void FileDownload() throws InterruptedException, AWTException
    {
            Thread.sleep(15000);
            Robot robot = new Robot();

            robot.setAutoDelay(5000);
            robot.mouseMove(630, 420); // move mouse point to specific location
            robot.delay(4000);        // delay is to make code wait for mentioned milliseconds before executing next step
            robot.mousePress(InputEvent.BUTTON1_DOWN_MASK); // press left click
            robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK); // release left click
            robot.delay(5000);

            robot.keyPress(KeyEvent.VK_DOWN); // press keyboard arrow key to select Save radio button
            Thread.sleep(2000);
            robot.keyPress(KeyEvent.VK_ENTER);
    }

    //code to handle drop down feature
    public static void DropDownMenu(WebDriver driver,String locator,String value)
    {
            Actions act=new Actions(driver);
            List<WebElement> Values=FindByElements(driver,"xpath",locator);
            for(WebElement Val: Values)
            {
                act.moveToElement(Val).build().perform();
                String Val_Text = Val.getText();
                Implicitwait(driver,5);
                if (Val_Text.equalsIgnoreCase(value) || Val_Text.contains(value))
                {
                  act.click(Val).build().perform();
                  break;
                }
            }
    }

    //Code for navigating from tab to tab
    public static void navigate_Horizantal_Tab(WebDriver driver, String MenuItem,String MenuItemLocator,String selector,String MenuItems)
    {
            String Menu_Text=null;
            Actions act=new Actions(driver);
            List<WebElement> MenuBar=FindByElements(driver,selector,MenuItems);
            for(WebElement Menu:MenuBar)
            {
                Implicitwait(driver,20);
                act.moveToElement(Menu).build().perform();
                Implicitwait(driver,2);
                Menu_Text=Menu.getText();
                if(Menu_Text.contains(MenuItem))
                {
                    Implicitwait(driver,10);
                    WebElement menuItem=FindByElement(driver,selector,MenuItemLocator);
                   // act.click(menuItem).build().perform();
                    JScriptClick(driver,menuItem,4);
                    Implicitwait(driver,40);
                    break;
                }
            }
    }

    public static String gettingTitle(WebDriver driver)
    {
        String title=null;
         title=driver.getTitle();
        return title;
    }

    public static String gettingURL(WebDriver driver)
    {
        String url=null;
        url=driver.getCurrentUrl();
        return url;
    }

    /*For clearing input box*/
    public static void clearText(WebDriver driver,WebElement element,int timeOut)
    {
        new WebDriverWait(driver,timeOut).until(ExpectedConditions.visibilityOf(element));
        element.clear();
    }

    /*Send key with wait method*/
    public static void sendKeys(WebDriver driver,WebElement element,int timeOut,String value)
    {
        new WebDriverWait(driver,timeOut).until(ExpectedConditions.visibilityOf(element));
        element.sendKeys(value);
    }

    /*For clicking any button*/
    public static void clickOn(WebDriver driver,WebElement element,int timeOut)
    {
        new WebDriverWait(driver,timeOut).until(ExpectedConditions.elementToBeClickable(element));
        element.click();
    }

    /*Wait till visiblity of element*/
    public static boolean waitTillElementDisplayed(WebDriver driver,WebElement element,int timeOut)
    {
        new WebDriverWait(driver,timeOut).until(ExpectedConditions.visibilityOf(element));
        return true;
    }

    /*Wait till Visiblity of element located at*/
    public static boolean waitTillElementLocatedDisplayed(WebDriver driver,String selector,String val,int timeOut)
    {
        WebDriverWait wait = new WebDriverWait(driver, timeOut);
        if (selector.equalsIgnoreCase("id"))
        {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(val)));
        } else if (selector.equalsIgnoreCase("class")) {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(val)));
        } else if (selector.equalsIgnoreCase("xpath")) {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(val)));
        } else if (selector.equalsIgnoreCase("cssselector")) {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(val)));
        } else if (selector.equalsIgnoreCase("linktext")) {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(val)));
        } else if (selector.equalsIgnoreCase("partiallinkedtext")) {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.partialLinkText(val)));
        } else if (selector.equalsIgnoreCase("tagname")) {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName(val)));
        }
        return true;
    }

    public static boolean waitTillTitleContains(WebDriver driver, String title, int timeOut)
    {
        new WebDriverWait(driver,timeOut).until(ExpectedConditions.titleIs(title));
        return true;
    }

    public static boolean waitTillPageLoaded(WebDriver driver,int timeOut)
    {
        driver.manage().timeouts().pageLoadTimeout(timeOut, TimeUnit.SECONDS);
        return true;
    }

    public static boolean waitTillLoadingWheelDisappears(WebDriver driver,WebElement element,int timeOut)
    {
       new WebDriverWait(driver,timeOut).until(ExpectedConditions.invisibilityOf(element));
       return true;
    }

    public static void JSscrollUp(WebDriver driver)
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-250)", "");
    }

    public static void JSscrollDown(WebDriver driver)
    {
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,250)", "");
    }

    //Code to handle page load issues. Method that can be used when java scripts
    // are still running behind and not letting automation cod to execute
    public static boolean waitTillLoadingPage(WebDriver driver)
    {
        String pageLoadStatus="";
        boolean pageWasLoaded=false;
      //  long startTime=System.currentTimeMillis();
        do{
            try
            {
                pageLoadStatus=returnDocumentStatus(driver);
            }
            catch(Exception e)
            { e.printStackTrace();}
            if(pageLoadStatus.equals("complete") || pageLoadStatus.equals("interactive"))
            {
                pageWasLoaded=true;
            }
        }while(!pageWasLoaded); // && !isTimeout(startTime,timeOut));
        return pageWasLoaded;
    }

    private static boolean isTimeout(long startTime, int timeOut)
    {
        boolean flag=false;
        int count=0;

        while(count!=timeOut)
        {
            count++;
            startTime = startTime + count;
            flag=true;
        }
        return flag;
    }

    public static String returnDocumentStatus(WebDriver driver)
    {
        JavascriptExecutor js=(JavascriptExecutor) driver;
        return (String) js.executeScript("return document.readyState");
    }

    //**********************************************GENERIC METHODS FOR OMS AND DSD************************************
    //Code for AddFilterSearch for DSD and OMS applications
    public static void AddFilterSearch(WebDriver driver,String SearchBoxValue,String SearhBox2Value) throws InterruptedException
    {
        WebElement Search2=null;

            //Click on Add filter button
            WebDriverWait wait=new WebDriverWait(driver,10);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button/descendant::span[contains(text(),'Add filter')]")));
            driver.findElement(By.xpath("//button/descendant::span[contains(text(),'Add filter')]")).click();

            //Click on Clear all button
            WebElement Clear=driver.findElement(By.xpath("//div[contains(@class,'k-animation-container')]/descendant::button[contains(text(),'Clear all')]"));

            if(Clear.isEnabled()==true)
            {
                wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class,'k-animation-container')]/descendant::button[contains(text(),'Clear all')]")));
                driver.findElement(By.xpath("//div[contains(@class,'k-animation-container')]/descendant::button[contains(text(),'Clear all')]")).click();
            }

            //Enter value in first searchbox in popup
            WebElement Search1=driver.findElement(By.xpath("//div[contains(@class,'k-animation-container')]/descendant::input[contains(@class,'i-search-box__input')]"));
            EnterText(driver,Search1,4,SearchBoxValue);
            Thread.sleep(500);

            //Click on Check box
            driver.findElement(By.xpath("//div[contains(@class,'k-animation-container')]/descendant::input[contains(@class,'k-checkbox')]")).click();
            Thread.sleep(1000);

            //Handling 2nd popup,2nd popup with check box
            Search2=driver.findElement(By.xpath("//div[contains(@class,'k-animation-container')]/descendant::input[contains(@class,'k-textbox')]"));
            if(Search2.isDisplayed())
            {
                EnterText(driver,Search2,4,SearhBox2Value);
               //Thread.sleep(2000);

                //Click on Apply button
                Clear = driver.findElement(By.xpath("//div[contains(@class,'k-animation-container')]/descendant::button[text()='Apply']"));
                if (Clear.isDisplayed())
                {
                    driver.findElement(By.xpath("//div[contains(@class,'k-animation-container')]/descendant::button[text()='Apply']")).click();
                }
            }
            else
            {
                //Enter Value in Search box in 2nd popup
                Search2 = driver.findElement(By.xpath("//div[contains(@class,'k-animation-container')]/descendant::input[@class='i-search-box__input']"));
                if(Search2.isDisplayed())
                {
                    EnterText(driver,Search2,2,SearhBox2Value);
                  //  Thread.sleep(5000);

                    //Click on Check box
                    driver.findElement(By.xpath("//div[contains(@class,'k-animation-container')]/descendant::input[contains(@class,'k-checkbox')]")).click();
                //    Thread.sleep(5000);
                }
            }
    }

    //************************************Code for DSD and OMS applications****************************************
    //Index Field Icon in Order entry, in other pages xpath is different for index field
    public static void Click_On_IndexFieldIcon(WebDriver driver,String label,String Search1_Value,String Search2_Value) throws InterruptedException
    {
            Thread.sleep(1000);
            //To click on IndexField icon
            driver.findElement(By.xpath("//label[contains(text(),'"+label+"')]/following-sibling::div/descendant::button")).click();
            Thread.sleep(500);

            //To handle AddFilter button in the Index field popup
            HelpersMethod.AddFilterSearch(driver,Search1_Value,Search2_Value);

            //click on the table row after filter
            HelpersMethod.ActClick(driver,driver.findElement(By.xpath("//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[@class='k-master-row']")),1);
            Thread.sleep(3000);
    }




}