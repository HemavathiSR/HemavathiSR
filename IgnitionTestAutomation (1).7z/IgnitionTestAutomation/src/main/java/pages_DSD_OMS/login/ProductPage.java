package pages_DSD_OMS.login;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class ProductPage
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;

    //static WebElement WebEle=null;
    static boolean exists=false;

    @FindBy(xpath = "//button[text()='Print']")
    private WebElement Print;

    @FindBy(xpath = "//span[contains(text(),'Sort by best match')]")
    private WebElement SortByMatch;

    @FindBy(id = "CPcategories")
    private WebElement Categories;

    @FindBy(id = "CPbrands")
    private WebElement SubCategories;

    @FindBy(id = "CPsizes")
    private WebElement AllBrand;

    @FindBy(xpath = "//button[contains(text(),' Reset filter')]")
    private WebElement ReSetFilter;

    @FindBy(xpath = "//input[contains(@placeholder,'Search products')]")
    private WebElement SearchBar;

    @FindBy(xpath = "//*[local-name()='svg' and contains(@class,'i-icon   ')]//*[local-name()='path' and contains(@d,'M15')]")
    private WebElement SearchIndex;

    @FindBy(xpath = "//*[local-name()='svg' and contains(@class,'i-icon   ')]//*[local-name()='path' and contains(@d,'M17')]")
    private WebElement Close;

    @FindBy(xpath ="//input[contains(@id,'Units')]")
    private WebElement unit_Qty;

    @FindBy(xpath = "//input[contains(@id,'Cases)]")
    private WebElement case_Qty;

    @FindBy(xpath="//input[contains(@id,'ProductGridItemQuantityContainer')]")
    private WebElement Qtycard;

    @FindBy(xpath="//input[contains(@id,'catalog-list-view-quantity-input')]")
    private WebElement QtyList;

    @FindBy(xpath = "//button[contains(@class,'buttonPlus ')]")
    private WebElement QtyPlus;

    @FindBy(xpath = "//button[contains(@class,'buttonMinus')]")
    private WebElement QtyMinus;

    @FindBy(xpath = "//button/descendant::span[text()='Add to cart']")
    private WebElement AddToCart;

    @FindBy(xpath="//*[local-name()='svg']/*[local-name()='path' and contains(@d,'M4')]")
    private WebElement CardView;

    @FindBy(xpath ="//*[local-name()='svg']/*[local-name()='path' and contains(@d,'M3')]")
    private WebElement ListView;

    @FindBy(xpath = "//button[text()='Cart']")
    private WebElement Cart;

    @FindBy(xpath = "//button[text()='Return to Login']")
    private WebElement ReturnLogin;

    @FindBy(id="checkoutToOrder")
    private WebElement Checkout;

    @FindBy(id="sort-by-dropdown")
    private WebElement SortDrop;

    public ProductPage(WebDriver driver,Scenario scenario) throws InterruptedException, AWTException
    {
        this.driver= driver;
        this.scenario=scenario;
        PageFactory.initElements(driver,this);
    }

    //Validating Product catalog page has displayed or not
    public void ValidateProductPage()
    {
        exists=false;
        try
        {
            /*WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,15);*/
            HelpersMethod.Implicitwait(driver,6);
            HelpersMethod.waitTillTitleContains(driver,"Ignition - Product Catalog",1);
            if(HelpersMethod.gettingURL(driver).contains("cpExtProductCatalog"))
            {
                exists=true;
            }
        }
        catch (Exception e){}
      //  Assert.assertEquals(exists,true);
    }

    public void Click_ResetFilter()
    {
        try
        {
            HelpersMethod.Implicitwait(driver,10);
            HelpersMethod.ActClick(driver,ReSetFilter,2);
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,30);
        }
        catch (Exception e){}
    }

    //Change catalog  Card to grid view
    public void CardView()
    {
        try
        {
            if (!HelpersMethod.IsExists("//*[local-name()='svg']//*[local-name()='path' and contains(@d,'M4')]/ancestor::button[contains(@class,'k-primary')]", driver))
            {
                WebElement cardview = HelpersMethod.FindByElement(driver, "xpath", "//*[local-name()='svg']//*[local-name()='path' and contains(@d,'M4')]/ancestor::button");
                HelpersMethod.ClickBut(driver,cardview,1);
            }
        }
        catch (Exception e){}
    }

    //Change catalog grid view to card
    public void GridView()
    {
        try {
            if (!HelpersMethod.IsExists("//*[local-name()='svg']//*[local-name()='path' and contains(@d,'M3')]/ancestor::button[contains(@class,'k-primary')]", driver))
            {
                WebElement gridview = HelpersMethod.FindByElement(driver, "xpath", "//*[local-name()='svg']//*[local-name()='path' and contains(@d,'M3')]/ancestor::button");
                HelpersMethod.ClickBut(driver,gridview,1);
            }
        }
        catch (Exception e){}
    }

    //Enter Product# in Search bar and click on Index icon
    public void SearchProduct(String Prod_No)
    {
        try
        {
            WebElement WebEle=null;
            HelpersMethod.Implicitwait(driver,10);
            HelpersMethod.ActSendKey(driver,SearchBar,2,Prod_No);
            HelpersMethod.Implicitwait(driver,2);
            HelpersMethod.ActClick(driver,SearchIndex,2);
            WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
           if(WebEle.isDisplayed())
           {
               HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 40);
           }
           else
           {
               HelpersMethod.Implicitwait(driver,6);
           }

            //If sorry no products matches message is displayed
            WebEle=HelpersMethod.FindByElement(driver,"id","no-products-found");
            if(WebEle.isDisplayed())
            {
                scenario.log("PRODUCT DOESNOT EXISTS");
                HelpersMethod.ActClick(driver,Close,4);
                WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,40);
            }
        }
        catch(Exception e){}
    }

    //Validate whether product details are displayed or not,card view
    public void ProductExistsCard(String Qty_unit,String Qty_case)
    {
        exists=false;
        WebElement WebEle=null;
        try
        {
            //Find number of input boxes available to enter Qty with product details
            List<WebElement> Inputs=HelpersMethod.FindByElements(driver,"xpath","//input[contains(@id,'ProductGridItemQuantityContainer')]");
            WebElement Button_Ele=null;
            if(Inputs.size()==2)
            {
                //Enter Qty in input boxs, Check for units input box
                if (HelpersMethod.IsExists("//input[contains(@id,'Units')]", driver))
                {
                    HelpersMethod.ScrollElement(driver,unit_Qty);
                    HelpersMethod.ActSendKey(driver,unit_Qty,2,Qty_unit);

                    exists = HelpersMethod.IsExists("//div[contains(text(),'currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]", driver);
                    if (exists == true)
                    {
                        Button_Ele=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                        HelpersMethod.ClickBut(driver,Button_Ele,2);
                    }
                }
                else if (HelpersMethod.IsExists("//input[contains(@id,'Cases)]", driver))
                {
                    HelpersMethod.ScrollElement(driver,case_Qty);
                    HelpersMethod.ActSendKey(driver,case_Qty,2,Qty_case);

                    exists = HelpersMethod.IsExists("//div[contains(text(),'currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]", driver);
                    if (exists == true)
                    {
                        Button_Ele=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                        HelpersMethod.ClickBut(driver,Button_Ele,2);
                    }
                }
            }
            else
                {
                    HelpersMethod.ScrollElement(driver,Qtycard);
                     HelpersMethod.ActSendKey(driver,Qtycard,2,Qty_unit);

                    exists=HelpersMethod.IsExists("//div[contains(text(),'currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver);
                    if(exists==true)
                    {
                        Button_Ele=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                        HelpersMethod.ClickBut(driver,Button_Ele,2);
                    }
                }
                //Click on Add to cart button
                HelpersMethod.Implicitwait(driver,2);
                HelpersMethod.ClickBut(driver,AddToCart,2);
                HelpersMethod.Implicitwait(driver,2);
                HelpersMethod.JSScroll(driver,Close);
                HelpersMethod.ClickBut(driver,Close,8);
             WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
             HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,10);
             HelpersMethod.waitTillElementDisplayed(driver,SearchBar,4);
             exists=true;
        }
        catch (Exception e) { }

    }

    public void ProductExistsCardDelete(String Qty_unit,String Qty_case,int i,String Prod)
    {
        exists=false;
        WebElement WebEle = null;
        try
        {
            //Find number of input boxes available to enter Qty with product details
            List<WebElement> Inputs = HelpersMethod.FindByElements(driver, "xpath", "//input[contains(@id,'ProductGridItemQuantityContainer')]");
            WebElement Button_Ele = null;
            if (Inputs.size() == 2)
            {
                //Enter Qty in input boxs, Check for units input box
                if (HelpersMethod.IsExists("//input[contains(@id,'Units')]", driver)) {
                    HelpersMethod.ScrollElement(driver, unit_Qty);
                    HelpersMethod.ActSendKey(driver, unit_Qty, 2, Qty_unit);

                    exists = HelpersMethod.IsExists("//div[contains(text(),'currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]", driver);
                    if (exists == true) {
                        Button_Ele = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                        HelpersMethod.ClickBut(driver, Button_Ele, 2);
                    }
                } else if (HelpersMethod.IsExists("//input[contains(@id,'Cases)]", driver)) {
                    HelpersMethod.ScrollElement(driver, case_Qty);
                    HelpersMethod.ActSendKey(driver, case_Qty, 2, Qty_case);

                    exists = HelpersMethod.IsExists("//div[contains(text(),'currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]", driver);
                    if (exists == true) {
                        Button_Ele = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                        HelpersMethod.ClickBut(driver, Button_Ele, 2);
                    }
                }
            } else {
                HelpersMethod.ScrollElement(driver, Qtycard);
                HelpersMethod.ActSendKey(driver, Qtycard, 2, Qty_unit);

                exists = HelpersMethod.IsExists("//div[contains(text(),'currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]", driver);
                if (exists == true) {
                    Button_Ele = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                    HelpersMethod.ClickBut(driver, Button_Ele, 2);
                }
            }
            //Click on Add to cart button
            HelpersMethod.Implicitwait(driver, 2);
            HelpersMethod.ClickBut(driver, AddToCart, 2);

            //Click on delete button only for the first product
            HelpersMethod.Implicitwait(driver,2);
            if(i==1)
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//*[local-name()='svg']//*[local-name()='path' and contains(@d,'M16')]");
                HelpersMethod.ActClick(driver,WebEle,2);
                scenario.log("DELETED PRODUCT # "+Prod);
            }
            HelpersMethod.Implicitwait(driver,1);
            HelpersMethod.JSScroll(driver, Close);
            HelpersMethod.ClickBut(driver, Close, 8);
            WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);
            HelpersMethod.waitTillElementDisplayed(driver, SearchBar, 4);
            exists=true;
        } catch (Exception e) {}
    }


    //Click on Cart button
    public void Cart_Button()
    {
        try
        {
            if(HelpersMethod.EleDisplay(Cart))
            {
                HelpersMethod.ClickBut(driver,Cart,2);
                WebElement  WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,8);
            }
        }
        catch (Exception e){}
    }

    //Click on Delete button in "Items in cart" page
    public void Delete_Button()
    {
        exists=false;
        try
        {
            HelpersMethod.Implicitwait(driver,15);
            WebElement Del_But= HelpersMethod.FindByElement(driver,"xpath","//tr[1]//*[local-name()='svg' and contains(@class,'delete')]");
            HelpersMethod.ScrollElement(driver,Del_But);
            HelpersMethod.ActClick(driver,Del_But,1);
            HelpersMethod.Implicitwait(driver,5);
            exists=true;
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    //click on checkout to order
    public void Checout_to_order()
    {
        exists=false;
        HelpersMethod.Implicitwait(driver,8);
        try
        {
            if(HelpersMethod.EleDisplay(Checkout))
            {
                HelpersMethod.ScrollElement(driver,Checkout);
                HelpersMethod.ClickBut(driver,Checkout,2);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e)
        {scenario.log("CHECKOUT TO ORDER");}
    }

    //Code for entering Qty for products when Catalog is displayed in List view
    public void ProductExistsList(String Qty_unit,String Qty_case)
    {
        exists=false;
        WebElement WebEle=null;
        try
        {
            //Find number of input boxes available to enter Qty with product details
            List<WebElement> Inputs=HelpersMethod.FindByElements(driver,"xpath","//input[contains(@id,'catalog-list-view-quantity-input')]");
            WebElement Button_Ele=null;
            if(Inputs.size()==2)
            {
                //Enter Qty in input boxs, Check for units input box
                if (HelpersMethod.IsExists("//input[contains(@id,'Units')]", driver))
                {
                    HelpersMethod.ScrollElement(driver,unit_Qty);
                    HelpersMethod.ActSendKey(driver,unit_Qty,2,Qty_unit);
                    exists = HelpersMethod.IsExists("//div[contains(text(),'currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]", driver);
                    if (exists == true)
                    {
                        Button_Ele=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                        HelpersMethod.ClickBut(driver,Button_Ele,2);
                    }
                }
                else if (HelpersMethod.IsExists("//input[contains(@id,'Cases)]", driver))
                {
                    HelpersMethod.ScrollElement(driver,case_Qty);
                    HelpersMethod.ActSendKey(driver,case_Qty,2,Qty_case);
                    exists = HelpersMethod.IsExists("//div[contains(text(),'currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]", driver);
                    if (exists == true)
                    {
                        Button_Ele=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                        HelpersMethod.ClickBut(driver,Button_Ele,2);
                    }
                }
            }
            else
            {
                HelpersMethod.ClearText(driver,QtyList,4);
                HelpersMethod.ActSendKey(driver,QtyList,2,Qty_unit);
                exists=HelpersMethod.IsExists("//div[contains(text(),'currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver);
                if(exists==true)
                {
                    Button_Ele=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                    HelpersMethod.ClickBut(driver,Button_Ele,4);
                }
            }
            HelpersMethod.JSScroll(driver,Close);
            HelpersMethod.ClickBut(driver,Close,4);
            WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,10);
            HelpersMethod.waitTillElementDisplayed(driver,SearchBar,4);
        }
        catch (Exception e)
        {scenario.log("NOT ABLE TO ENTER QTY"); }
    }

    //code to click on sort by best match
    public void Sort_By_ascending_order(String value)
    {
        boolean result=false;
        try
        {
            if(HelpersMethod.EleDisplay(SortDrop))
            {
              //  HelpersMethod.Implicitwait(driver,20);
                HelpersMethod.ClickBut(driver,SortDrop,25);
                HelpersMethod.DropDownMenu(driver, "//ul[contains(@class,'k-list k-reset')]/li", value);
                List<WebElement> Prices = HelpersMethod.FindByElements(driver, "xpath", "//div[@class='product-price-container']/descendant::span[@class='product-price']");
                List<Double> Prices1=new ArrayList<>();
                List<Double> Prices2=new ArrayList<>();

                //copy content of web element, i.e. prices to list
                for(WebElement Price:Prices)
                {
                    String Price_Text=Price.getText();
                    if(!Price_Text.equals(" "))
                    {
                        Prices1.add(Double.valueOf(Price_Text));
                        Prices2.add(Double.valueOf(Price_Text));
                    }
                }
                //Sort the values in ascending order
                Collections.sort(Prices1);
                //Comparing List of integers, to find whether array is in sorted order
                result = Prices1.equals(Prices2);
            }
            else
            {
                scenario.log("Sorting dropdown is not visible");
            }
        }
        catch (Exception e){ }//scenario.log("NOT ABLE TO HANDLE ASCENDING ORDER BUTTON");}
      //  Assert.assertEquals(result,true);
    }

    //Enter product details in search box separated by comma
    public void EnterProdSeparatedByComma(java.util.List<String> Prod)
    {
        boolean result=false;
        try
        {
            String Products="";
            java.util.List<String> ProdList=new ArrayList<String>();

            for(int i=0;i<=Prod.size()-1;i++)
            {
                Products=Products+String.valueOf(Prod.get(i)+", ");
            }

            HelpersMethod.ActSendKey(driver,SearchBar,4,Products);
            HelpersMethod.Implicitwait(driver,6);
            HelpersMethod.ActClick(driver,SearchIndex,20);
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,120);
            HelpersMethod.waitVisibilityOfEle(driver,SearchBar,20);


            scenario.log("PRODUCTS ENTERED IN SEARCH BOX "+Products);
            List<WebElement> Prods=HelpersMethod.FindByElements(driver,"xpath","//div[@class='product-number']/span");
            for (WebElement Product:Prods)
            {
                String Prod_Text=Product.getText();
                scenario.log("PRODUCTS FOUND "+Prod_Text);
            }

            //get the product no. that get displayed on catalog page
           List<WebElement> Prods1=HelpersMethod.FindByElements(driver,"xpath","//div[@class='product-number']/descendant::span") ;
            for (WebElement Pro:Prods1)
            {
                String Pro_Text=Pro.getText();
                ProdList.add(Pro_Text.substring(1));
                Collections.sort(ProdList);
            }

            //traverse through list to read product no. from both the list
            for(int i=0;i<=Prod.size()-1;i++)
            {
                System.out.println(Prod.get(i)+","+ProdList.get(i));
                if(Prod.get(i).equals(ProdList.get(i)))
                {
                    result=true;
                }
                else
                {
                    result=false;
                    break;
                }
            }
            HelpersMethod.Implicitwait(driver,4);
        }
        catch (Exception e)
        {//scenario.log("SOMETHING WENT WRONG WHILE SEARCHING FOR PRODUCTS");
        }
    }

    //Click on Category drop down and select the 1st option in the drop down
    public void CategoryDropDown()
    {
        boolean result=false;
        try
        {
            HelpersMethod.waitTillPageLoaded(driver,10);
          if(Categories.isDisplayed())
          {
              HelpersMethod.ClickBut(driver, Categories, 4);
              WebElement WebEle=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-child-animation-container')]/descendant::li[2]");
              HelpersMethod.ActClick(driver,WebEle,6);
              WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
              HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,120);


             /* if (!HelpersMethod.IsExists("//span[@id='CPcategories']/span[text()='All Categories']", driver)) {
                  result = true;
              }
              if (result == true) {
                  scenario.log("CATEGORY HAS NOT BEEN CHANGED");
              } else {
                  scenario.log("CATEGORY HAS BEEN CHANGED");
              }*/
          }
          else
          {
              scenario.log("CATEGORY DROP DOWN IS NOT VISIBLE");
          }
        }
        catch (Exception e)
        {//scenario.log("CATEGORY DROPDOWN HAS NOT BEEN HANDLED");
        }
        Assert.assertEquals(result, true);
    }

    //Code to verify whether category has been reset to All category or not after clicking reset button
    public void VerifyCategory()
    {
        exists=false;
        try
        {
            String Cat_text=HelpersMethod.FindByElement(driver,"xpath","//span[@id='CPcategories']/span[@class='k-input']").getText();
            if(Cat_text.equalsIgnoreCase("All categories"))
            {
                exists=true;
            }
        }
        catch (Exception e)
        {
           // scenario.log("VERIFYING CATEGORY HAS NOT BEEN HANGLED PROPERLY");
        }
        Assert.assertEquals(exists,true);
    }
}
