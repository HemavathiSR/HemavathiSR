package pages_DSD_OMS.login;

import gherkin.lexer.He;
import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import io.cucumber.java.bs.A;
import io.cucumber.java.en_old.Ac;
import io.cucumber.java.ro.Si;
import lombok.experimental.Helper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.List;

/**
 * @Project DSD_ERP
 * @Author Divya.Ramadas@afsi.com
 */
public class HomePage
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;
    static boolean exists=false;

    @FindBy(xpath = "//div[@class='user-info-initial-container']")
    private WebElement IconContainer;

    @FindBy(xpath = "//div[contains(@class,'user-info-container')]/div[contains(@class,'user-info-initial-container')]")
    private WebElement UserIcon;

    //Initializing the Page Objects:
    public HomePage(WebDriver driver, Scenario scenario)
    {
        this.scenario=scenario;
        this.driver =driver;
        PageFactory.initElements(driver,this);
    }

    public void VerifyHomePage()
    {
        exists=false;
        HelpersMethod.waitTillPageLoaded(driver,60);
        WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
        HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,120);
        try
        {
            HelpersMethod.waitTillTitleContains(driver,"Ignition - Admin",10);
            String HomeTitle=driver.getTitle();
            if(HomeTitle.contains("Ignition - Admin"))
            {
                exists=true;
            }
        }
        catch (Exception e)
        {}//scenario.log("NOT NAVIGATED TO HOME PAGE");}
        Assert.assertEquals(exists,true);
    }

    public void verifyUserinfoContainer()
    {
        exists=false;
        try
        {
            HelpersMethod.Implicitwait(driver,20);
            WebElement UserInfo=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'user-info-container')]");
            exists = HelpersMethod.EleDisplay(UserInfo);
        }
        catch (Exception e)
        {scenario.log("USER ICON IS NOT VISIBLE");}
        Assert.assertEquals(exists,true);
    }

    public void navigateToClientSide()
    {
        try
        {
            HelpersMethod.Implicitwait(driver,10);
            //create webdriverwait instance
            WebDriverWait wait = new WebDriverWait(driver, 40);
            WebElement side_menu= HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'MuiPaper-root MuiDrawer-paper drawer')]");

            Actions act1 = new Actions(driver);
            Thread.sleep(2000);

            //move mouse to Ignition icon container
            //WebElement ele2=HelpersMethod.FindByElement(driver,"xpath","//div[@class='application-icon-container']");

           // WebElement ele2=HelpersMethod.FindByElement(driver,"xpath","//div[@class='drawer-menu-application-container']");
          //  act1.moveToElement(ele2).build().perform();
            WebElement ele2=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'MuiPaper-root MuiDrawer-paper drawer-closed MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft MuiPaper-elevation0')]");
            act1.moveToElement(ele2).build().perform();

            //find whether side menu bar has expanded
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'MuiPaper-root MuiDrawer-paper drawer-opened MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft MuiPaper-elevation0')]")));
            side_menu =HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'MuiPaper-root MuiDrawer-paper drawer-opened MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft MuiPaper-elevation0')]");
            act1.moveToElement(side_menu).build().perform();


            //Click on arrow symbol
            WebElement arrow = HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'settings-back-container')] //*[name()='svg']//*[local-name()='path' and contains(@d,'M5,8L1,12L5,16L5,13L23,13L23,11L5,11L5,8,z')]");
            if (arrow.isDisplayed())
            {
                WebElement ele4 =HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'settings-back-container')] //*[name()='svg']//*[local-name()='path' and contains(@d,'M5,8L1,12L5,16L5,13L23,13L23,11L5,11L5,8,z')]");
               // HelpersMethod.ClickBut(driver,ele4,5);
                act1.moveToElement(ele4).build().perform();
                act1.click(ele4).build().perform();
            }
            //Identify side menu bar to identify the webelements
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'MuiPaper-root MuiDrawer-paper drawer-opened MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft MuiPaper-elevation0')]")));
            side_menu =HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'MuiPaper-root MuiDrawer-paper drawer-opened MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft MuiPaper-elevation0')]");
            HelpersMethod.Implicitwait(driver,30);
        }
        catch (Exception e) {}//scenario.log("NOT ABLE TO NAVIGATE TO CLIENT SIDE");}
    }

    public void Click_On_UserIcon() throws InterruptedException
    {
           HelpersMethod.Implicitwait(driver,45);
           WebElement UserIcon = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'user-info-container')]/div[contains(@class,'user-info-initial-container')]");
            exists=false;
            try
            {
                if (UserIcon.isDisplayed())
                {
                    HelpersMethod.ActClick(driver, UserIcon, 10);
                    exists = true;
                }
                else
                {
                    scenario.log("USER ICON NOT RECOGNIZED");
                }
            }
            catch (Exception e)
            {
              //  scenario.log("NOT ABLE TO CLICK ON USER ICON");
              //  e.printStackTrace(System.out);
            }
        HelpersMethod.Implicitwait(driver,10);
        Assert.assertEquals(exists, true);
    }

    public void Click_On_Signout()
    {
        exists=false;
        WebElement SignOut = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(text(),'Sign out')]");
        new WebDriverWait(driver,15).until(ExpectedConditions.elementToBeClickable(SignOut));/////////////////////////////
        try {

            WebElement DropDown = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,' user-info k-animation-container-shown')]");

            HelpersMethod.Implicitwait(driver, 6);
            HelpersMethod.ActClick(driver,SignOut,8);
            HelpersMethod.Implicitwait(driver,20);

            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            if (WebEle.isDisplayed()) {
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);
            } else {
                HelpersMethod.Implicitwait(driver, 10);
            }
            HelpersMethod.Implicitwait(driver,40);
        }
        catch (Exception e)
        { }
    }

    public void Change_Language() throws InterruptedException
    {
        String Lang1=null;
        String Lang2=null;
        try
        {
            HelpersMethod.Implicitwait(driver,10);
            Actions act1 = new Actions(driver);
            WebElement LangInMenu = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'user-info-line bgonhover')]/descendant::li");
            HelpersMethod.waitTillElementDisplayed(driver, LangInMenu, 2);
            Lang1 = LangInMenu.getAttribute("aria-label");
            scenario.log("LANGAUGE BEFORE CHANGEING LANGUAGE " + Lang1);

            HelpersMethod.waitTillElementDisplayed(driver, LangInMenu, 2);
            act1.moveToElement(LangInMenu).build().perform();
            HelpersMethod.waitTillElementLocatedDisplayed(driver, "xpath", "//div[contains(@class,'k-menu-popup k-popup')]/descendant::li", 2);
            //Code to check for drop down containing different language option
            if (HelpersMethod.IsExists("//div[contains(@class,'k-menu-popup k-popup')]", driver)) ;
            {
                //creating list of langauges
                List<WebElement> Langauges = HelpersMethod.FindByElements(driver, "xpath", "//div[contains(@class,'k-menu-popup k-popup')]/descendant::li");
                int i = 0;
                for (WebElement Language : Langauges)
                {
                    i++;
                    act1.moveToElement(Language).build().perform();
                    if (i == Langauges.size() - 1)
                    {
                        act1.click(Language).build().perform();
                        break;
                    }
                }
            }
            //Thread.sleep(2000);
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,10);
            HelpersMethod.ActClick(driver,UserIcon,2);

            LangInMenu=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'user-info-line bgonhover')]/descendant::li");
            HelpersMethod.waitTillElementDisplayed(driver,LangInMenu,2);
            Lang2=LangInMenu.getAttribute("aria-label");
            scenario.log("LANGUAGE FOUND IS "+Lang2);
            Thread.sleep(5000);
        }
        catch (Exception e)
        {}//scenario.log("NOT ABLE TO CHANGE LANGUAGE");}
    }

    public void Change_Language1(String s)
    {
        String Lang1=null;
        String Lang2=null;
        try
        {
            HelpersMethod.Implicitwait(driver,10);
            Actions act1 = new Actions(driver);
            WebElement LangInMenu = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'user-info-line bgonhover')]/descendant::li");
            HelpersMethod.waitTillElementDisplayed(driver, LangInMenu, 6);
            Lang1 = LangInMenu.getAttribute("aria-label");
            scenario.log("LANGAUGE BEFORE CHANGEING LANGUAGE " + Lang1);

            UserIcon=HelpersMethod.FindByElement(driver,"xpath","//div[@class='user-info-container']");
            HelpersMethod.ActClick(driver,UserIcon,6);
            LangInMenu=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'user-info-line bgonhover')]/descendant::li");
            HelpersMethod.waitTillElementDisplayed(driver, LangInMenu, 8);
            act1.moveToElement(LangInMenu).build().perform();
            HelpersMethod.waitTillElementLocatedDisplayed(driver, "xpath", "//div[contains(@class,'k-menu-popup k-popup')]", 8);
            //Code to check for drop down containing different language option
            if (HelpersMethod.IsExists("//div[contains(@class,'k-menu-popup k-popup')]", driver)) ;
            {
                //creating list of langauges
                List<WebElement> Langauges = HelpersMethod.FindByElements(driver, "xpath", "//div[contains(@class,'k-menu-popup k-popup')]/descendant::li");
                for (WebElement Language : Langauges)
                {
                    act1.moveToElement(Language).build().perform();
                    if (Language.getText().contains(s))
                    {
                        act1.click(Language).build().perform();
                        break;
                    }
                }
            }

            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,40);
            HelpersMethod.ActClick(driver,UserIcon,2);

            LangInMenu=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'user-info-line bgonhover')]/descendant::li");
            HelpersMethod.waitTillElementDisplayed(driver,LangInMenu,2);
            Lang2=LangInMenu.getAttribute("aria-label");
            scenario.log("LANGUAGE FOUND IS "+Lang2);
            HelpersMethod.Implicitwait(driver,6);
                if(Lang2.contains(s))
                {
                    exists=true;
                }
            HelpersMethod.Implicitwait(driver,20);

            WebElement SignOut = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(text(),'Sign out')]");
            new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(SignOut));
            WebElement DropDown = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,' user-info k-animation-container-shown')]");

                HelpersMethod.Implicitwait(driver, 6);
                HelpersMethod.ActClick(driver,SignOut,8);
                //HelpersMethod.JScriptClick(driver,SignOut,15);
                HelpersMethod.Implicitwait(driver,4);
        }
        catch (Exception e)
        {}//scenario.log("NOT ABLE TO RESET LANGUAGE TO ENGLISH(USA)");}
        Assert.assertEquals(exists,true);

    }
}
