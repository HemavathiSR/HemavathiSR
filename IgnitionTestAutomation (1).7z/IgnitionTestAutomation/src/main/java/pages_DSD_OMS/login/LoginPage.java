package pages_DSD_OMS.login;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import io.cucumber.java.bs.A;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import util.TestBase;

import java.awt.*;
import java.util.concurrent.TimeUnit;

/**
 * @Project DSD_ERP
 * @Author Divya.Ramadas@afsi.com
 */
public class LoginPage
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;
    static boolean exists=false;
    public static String url=null;

    @FindBy(xpath = "//label[text()='Login']/following-sibling::input")
    private WebElement Username;

    @FindBy(xpath = "//label[text()='Password']/following-sibling::input")
    private WebElement Password;

    @FindBy(xpath = "//button[contains(@class,'k-button k-primary k-button-icontext') and contains(text(),'Sign in')]")
    private WebElement SignIn;

    @FindBy(xpath = "//button[text()='Forgot password']")
    private WebElement Forgotten;

    @FindBy(xpath = "//a/p[contains(text(),'View product catalog')]")
    private WebElement ExternalCatalog;

    @FindBy(id="rememberMe")
    private WebElement RememberMe;

    @FindBy(xpath = "//p[contains(text(),'Register here')]")
    private WebElement Register;

    @BeforeClass
    public void WaitForPage()
    {
        HelpersMethod.Implicitwait(driver,40);
    }

    public LoginPage(WebDriver driver,Scenario scenario) throws InterruptedException, AWTException
    {
        this.scenario=scenario;
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    //Actions
    public void GetURL()
    {
        url=driver.getCurrentUrl();
    }

    public void validateLoginPageTitle()
    {
        exists=false;
        try
        {
            HelpersMethod.waitTillTitleContains(driver,"Ignition - Login",20);
            String title= driver.getTitle();
            if(title.equals("Ignition - Login"))
            {
                exists=true;
            }
        }
        catch (Exception e)
        {}//scenario.log("USER IS ON LOGIN PAGE");}
        Assert.assertEquals(exists,true);
    }

    public void EnterUsername(String un) throws InterruptedException
    {
        exists=false;
        try
        {
            HelpersMethod.Implicitwait(driver,10);
            HelpersMethod.clearText(driver,Username,4);
            HelpersMethod.sendKeys(driver,Username,1,un);
            exists=true;
        }
        catch (Exception e){}//scenario.log("NOT ABLE TO ENTER USER NAME");}
      //  Assert.assertEquals(exists,true);
    }
    public void EnterPassword(String pwd) throws InterruptedException
    {
        exists=false;
        try
        {
            HelpersMethod.clearText(driver,Password,4);
            HelpersMethod.sendKeys(driver,Password,1,pwd);
            exists=true;
        }
        catch (Exception e){}//scenario.log("NOT ABLE TO ENTER PASSWORD");}
        Assert.assertEquals(exists,true);
    }
    public void ClickSignin() throws InterruptedException
    {
        exists=false;
        try
        {
            if(HelpersMethod.IsExists("//button[contains(@class,'k-button k-primary k-button-icontext') and contains(text(),'Sign in')]",driver))
            {
                HelpersMethod.ScrollElement(driver,SignIn);
                HelpersMethod.JScriptClick(driver,SignIn,2);
                WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,120);
                exists=true;
            }
        }
        catch (Exception e){}//scenario.log("NOT ABLE TO CLICK ON SING IN");}
        Assert.assertEquals(exists,true);
    }
    public boolean CheckErrorMessage()
    {
        Boolean visiblity=null;
        try
        {
            WebElement ErrorMessage=HelpersMethod.FindByElement(driver,"id","errorValidation");
            new WebDriverWait(driver,8).until(ExpectedConditions.visibilityOf(ErrorMessage));
            if (ErrorMessage.isDisplayed())
            {
                visiblity = true;
            }
            else
            {
                visiblity = false;
            }
        }
        catch (Exception e){}//scenario.log("NOT ABLE TO HANDLE ERROR MESSAGE");}
        return visiblity;
    }

    public void ForgottenPassword()
    {
        exists=false;
        try
        {
            if (Forgotten.isDisplayed())
            {
                HelpersMethod.ScrollElement(driver,Forgotten);
                HelpersMethod.ActClick(driver, Forgotten, 20);
                exists=true;
            }
            else
            {
                scenario.log("FORGOTTEN PASSWORD BUTTON HAS NOT BEEN DISPLAYED");
            }

        } catch (Exception e) {}//scenario.log("NOT ABLE TO HANDELE FORGOTTEN PASSWORD BUTTON");}
        Assert.assertEquals(exists,true);
    }

    public void ForgottenPasswordFunctionality(String username)
    {
        exists=false;
        try
        {
            HelpersMethod.waitTillElementLocatedDisplayed(driver, "xpath", "//div[contains(@class,'password-assistance-dialog ')]/descendant::div[contains(@class,'k-widget k-window k-dialog')]", 2);
            WebElement ForgottenPass = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'password-assistance-dialog ')]/descendant::div[contains(@class,'k-widget k-window k-dialog')]");
            if (ForgottenPass.isDisplayed())
            {
                //Enter user name in input box, in popup
                WebElement UserInput = HelpersMethod.FindByElement(driver, "xpath", "//label[contains(text(),'User name')]/following-sibling::input");
                HelpersMethod.clearText(driver, UserInput, 1);
                HelpersMethod.sendKeys(driver, UserInput, 1,username);
                //Click on Send button
                WebElement SendBut = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Send']");
                HelpersMethod.clickOn(driver, SendBut, 1);
                exists=true;
            }
        }
        catch (Exception e){}//scenario.log("NOT ABLE TO ENTER USER NAME TO GET FORGOTTEN PASSWORD");}
        Assert.assertEquals(exists,true);
    }

    //Click on View product catalog in login page
    public void ClickExternalCatalog()
    {
        exists=false;
        HelpersMethod.Implicitwait(driver,15);
        try
        {
            HelpersMethod.waitTillElementLocatedDisplayed(driver, "xpath", "//p[contains(text(),'product catalog')]", 10);
            if(HelpersMethod.EleDisplay(ExternalCatalog))
            {
                HelpersMethod.ScrollElement(driver,ExternalCatalog);
                HelpersMethod.ActClick(driver,ExternalCatalog,4);
                exists=true;
                WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,50);
            }
            else
            {
                scenario.log("EXTERNAL CATALOG IS NOT VISIBLE");
            }
        }
        catch (Exception e)
        {}//scenario.log("EXTERNAL CATALOG HAS NOT BEEN HANBLED");}
        Assert.assertEquals(exists,true);
    }

    //Click on Register here link
    public void RegisterHere()
    {
        exists=false;
        try
        {
            if(Register.isDisplayed())
            {
                HelpersMethod.ScrollElement(driver,Register);
                HelpersMethod.ClickBut(driver,Register,2);
                HelpersMethod.Implicitwait(driver,4);
                exists=true;
            }
            else
            {scenario.log("REGISTER HERE BUTTON IS NOT VISIBLE");}
        }
        catch (Exception e)
        {}//scenario.log("REGISTER HERE BUTTON IS NOT VISIBLE");}
        Assert.assertEquals(exists,true);
    }

    public void RefreshLogin()
    {
        try
        {
           driver.navigate().to(url);
        }
        catch (Exception e){}//scenario.log("NOT ABLE TO NAVIGATE TO LOGIN PAGE AND REFRESH");}
    }

    public void ConfirmPopup()
    {
        HelpersMethod.Implicitwait(driver,10);
        try
        {
            WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@id='toast-container']");
            if(HelpersMethod.EleDisplay(WebEle))
            {
                scenario.log("CONFIRMATION POPUP HAS BEEN DISPLAYED");
            }
            else
            {
                scenario.log("CONFIRMATION POPUP HAS NOT BEEN DISPLAYED");
            }
        }
        catch (Exception e){}//scenario.log("SOMETHING WENT WRONG WITH CONFIRMATION POPUP");}
    }

    public void RememberMe()
    {
        try
        {
            if (RememberMe.isDisplayed())
            {
                HelpersMethod.ActClick(driver, RememberMe, 4);
            }
            else
            {scenario.log("REMEMBER ME CHECKBOX IS NOT VISIBLE");}
        }
        catch (Exception e){}//scenario.log("NOT ABLE TO CLICK ON REMEMBER ME CHECK BOX");}
    }
}
