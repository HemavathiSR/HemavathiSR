package pages_DSD_OMS.login;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import util.TestBase;
import util.RandomValues;

import java.awt.*;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class UserRegistrationPage
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;
    boolean exists=false;

    @FindBy(id="add-account-part-1")
    private WebElement Acc1;

    @FindBy(id="add-account-part-2")
    private WebElement Acc2;

    @FindBy(id="add-account-part-3")
    private WebElement Acc3;

    @FindBy(id="FirstName")
    private WebElement Fname;

    @FindBy(id="LastName")
    private WebElement Lname;

    @FindBy(id="UserName")
    private WebElement Uname;

    @FindBy(id="Email")
    private WebElement Actual_Email;

    @FindBy(id="ConfirmEmail")
    private WebElement ConfirmMail;

    @FindBy(id="Password")
    private WebElement Pass;

    @FindBy(id="ConfirmPassword")
    private WebElement ConfirmPass;

    @FindBy(xpath="//button[text()='Cancel']")
    private WebElement RegCancel;

    @FindBy(xpath = "//button[text()='Register']")
    private WebElement Registration;

    @FindBy(id = "NewUserCompanyRegistration")
            private WebElement NoAccCheckbox;

    @FindBy(id="CustomerName")
            private WebElement CustomerName;

    @FindBy(id="AddressLine1")
            private WebElement Address1;

    @FindBy(id="City")
            private WebElement City;

    @FindBy(id="State")
            private WebElement State;

    @FindBy(id="Zip")
            private WebElement Zip;

    @FindBy(id="PhoneNumber")
            private WebElement Phone;

    String Email= RandomValues.generateEmail(30);
    String Pass_Confirm= RandomValues.generateStringWithAllobedSplChars(10);

    public UserRegistrationPage(WebDriver driver, Scenario scenario) throws InterruptedException, AWTException
    {
        this.driver=driver;
        this.scenario=scenario;
        PageFactory.initElements(driver,this);
    }

    //Method to enter Account_No in input box
    public void EnterAccount_No()
    {
        String Account_No=null;
        try
        {
            if(HelpersMethod.EleDisplay(Acc3))
            {
                Account_No= TestBase.testEnvironment.FullAcc();
                String[] accArray = Account_No.split("-");

                //Enter the Customer Account#
                HelpersMethod.EnterText(driver,Acc1,1,accArray[0]);
                HelpersMethod.EnterText(driver,Acc2,1,accArray[1]);
                HelpersMethod.EnterText(driver,Acc3,1,accArray[2]);
            }
            else if(HelpersMethod.EleDisplay(Acc1))
            {
                HelpersMethod.EnterText(driver,Acc1,1,TestBase.testEnvironment.get_Account());
            }
        }
        catch (Exception e)
        {scenario.log("WHILE ENTERING ACCOUNT NUMBER HAVING SOME ISSUE");}
    }

    //Enter value in First name input box
    public void EnterFirstName()
    {
        try
        {
            HelpersMethod.waitTillElementDisplayed(driver,Fname,2);
            if(HelpersMethod.EleDisplay(Fname))
            {
                HelpersMethod.EnterText(driver,Fname,1,RandomValues.generateRandomString(20));
            }
        }
        catch (Exception e)
        {scenario.log("FIRST NAME HAS NOT BEEN ENTERED");}
    }

    //Enter Last name in input box
    public void EnterLastName()
    {
        try
        {
            HelpersMethod.waitTillElementDisplayed(driver,Lname,4);
            if(HelpersMethod.EleDisplay(Lname))
            {
                HelpersMethod.EnterText(driver,Lname,2,RandomValues.generateRandomString(20));
            }
        }
        catch (Exception e)
        {scenario.log("LAST NAME HAS NOT BEEN ENTERED");}
    }

    //Enter username
    public void EnterUserName()
    {
        try
        {
            HelpersMethod.waitTillElementDisplayed(driver,Uname,4);
            if(HelpersMethod.EleDisplay(Uname))
            {
                HelpersMethod.EnterText(driver,Uname, 2,RandomValues.generateRandomString(20));
            }
        }
        catch (Exception e)
        {scenario.log("USER NAME HAS NOT BEEN HANDLED");}
    }

    //Enter Actual_Email Id
    public void ActualEmail()
    {
        try
        {
            HelpersMethod.waitTillElementDisplayed(driver,Actual_Email,2);
            if(HelpersMethod.EleDisplay(Actual_Email))
            {
                HelpersMethod.ScrollElement(driver,Actual_Email);
                HelpersMethod.EnterText(driver,Actual_Email,2,Email);
            }
        }
        catch (Exception e)
        {scenario.log("ACTUAL MAIL HAS NOT BEEN ENTERED");}
    }

    //Enter value in confirmation email input box
    public void EnterConfirmEmail()
    {
        try
        {
            HelpersMethod.waitTillElementDisplayed(driver,ConfirmMail,4);
            if(HelpersMethod.EleDisplay(ConfirmMail))
            {
                HelpersMethod.EnterText(driver,ConfirmMail,1,Email);
            }
        }
        catch (Exception e)
        {scenario.log("CONFIRMATION EMAIL HAS NOT BEEN ENTERED");}
    }

    //Enter password in password input box
    public void EnterPassword()
    {
        try
        {
            HelpersMethod.waitTillElementDisplayed(driver, Pass,4);
            if(HelpersMethod.EleDisplay(Pass))
            {
                HelpersMethod.EnterText(driver,Pass,1,Pass_Confirm);
            }
        }
        catch (Exception e)
        {scenario.log("PASSWORD ENTRY HAS NOT BEEN HANDLED");}
    }

    //Enter confirm password in confirm password input box
    public void EnterConfirmPass()
    {
        try
        {
            HelpersMethod.waitTillElementDisplayed(driver,ConfirmPass,4);
            if(HelpersMethod.EleDisplay(ConfirmPass))
            {
                HelpersMethod.EnterText(driver,ConfirmPass,1,Pass_Confirm);
            }
        }
        catch (Exception e)
        {scenario.log("CONFIRMATION PASSWORD HAS NOT BEEN ENTERED"); }
    }

    //Click on Register button
    public void ClickOnRegistration()
    {
        try
        {
            HelpersMethod.waitTillElementDisplayed(driver,Registration,8);
            if(HelpersMethod.EleDisplay(Registration))
            {
                HelpersMethod.ScrollElement(driver,Registration);
                HelpersMethod.ClickBut(driver,Registration,1);
                WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,50);
            }
            HelpersMethod.Implicitwait(driver,10);
            if(HelpersMethod.IsExists("//div[contains(text(),'pending approval')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button"),1);
            }
            HelpersMethod.Implicitwait(driver,10);
        }
        catch (Exception e)
        {scenario.log("CLICKING ON REGISTRATION BUTTON IS NOT WORKING");}
    }

    //Click on cancel button in during registration
    public void CancelRegistration()
    {
        try
        {
            HelpersMethod.waitTillElementDisplayed(driver,RegCancel,4);
            if (HelpersMethod.EleDisplay(RegCancel))
            {
                HelpersMethod.ScrollElement(driver,RegCancel);
                HelpersMethod.ClickBut(driver,RegCancel,1);
            }
            if(HelpersMethod.IsExists("//div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button"),1);
            }
            HelpersMethod.Implicitwait(driver,10);
        }
        catch (Exception e)
        {  scenario.log("CANCEL REGISTRATION BUTTON IS NOT WORKING");}
    }

    //Click on 'Do't have account' check box
    public void DoNotHaveAccount()
    {
        try
        {
            if(HelpersMethod.EleDisplay(NoAccCheckbox))
            {
                HelpersMethod.ActClick(driver,NoAccCheckbox, 1);
            }
        }
        catch (Exception e)
        { scenario.log("DON'T HAVE ACCOUNT CHECK BOX IS NOT WORKING");}
    }

    //Enter customer name, only whe Donot have Account check box is selected
    public void CustomerName()
    {
        try
        {
            if(HelpersMethod.EleDisplay(CustomerName))
            {
                HelpersMethod.EnterText(driver,CustomerName,2,RandomValues.generateRandomString(10));
            }
        }
        catch (Exception e)
        {scenario.log("ENTERING CUSTOMER NAME IS MISSING");}
    }

    //Enter value for Addressline1, only when Don't have account check box is selected
    public void Address1()
    {
        try
        {
            if(HelpersMethod.EleDisplay(Address1))
            {
                HelpersMethod.EnterText(driver,Address1,2,RandomValues.generateRandomString(10));
            }
        }
        catch (Exception e)
        {scenario.log("ENTERING ADDRESS1 IS MISSING");}
    }

    //Enter city name, only when Don't have account check box is selected
    public void City()
    {
        try
        {
            if(HelpersMethod.EleDisplay(City))
            {
                HelpersMethod.EnterText(driver,City,2,RandomValues.generateRandomString(10));
            }
        }
        catch (Exception e)
        {scenario.log("ENTERING CITY IS MISSING");}
    }

    //Enter Value for state, only when Don't have account check box is selected
    public void State()
    {
        try
        {
            if (HelpersMethod.EleDisplay(State))
            {
                HelpersMethod.EnterText(driver,State, 2,RandomValues.generateRandomString(2));
            }
        } catch (Exception e)
        {scenario.log("ENTERING STATE IS MISSING");}
    }

    //Enter Zip value, only when Don't have account check box is selected
    public void Zip()
    {
        try
        {
            if (HelpersMethod.EleDisplay(Zip))
            {
                HelpersMethod.EnterText(driver,Zip,2,RandomValues.generateRandomNumber(10));
            }
        }
        catch (Exception e)
        {scenario.log("ENTERING ZIP IS MISSING");}
    }

    //Enter telephone number, only when Don't have account check box is selected
    public void Telephone()
    {
        try
        {
            if(HelpersMethod.EleDisplay(Phone))
            {
                HelpersMethod.EnterText(driver,Phone,2,RandomValues.generateRandomNumber(16));
            }
        }
        catch (Exception e)
        {scenario.log("ENTERING TELPHONE NUMBER IS MISSING");}
    }
}
