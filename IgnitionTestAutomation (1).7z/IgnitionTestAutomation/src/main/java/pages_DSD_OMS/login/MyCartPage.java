package pages_DSD_OMS.login;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.awt.*;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class MyCartPage
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;

    @FindBy(id="checkoutToOrder")
    private WebElement CheOutOrder;

    @FindBy(xpath = "//div[@class='delete-button-container']")
    private WebElement DeleteIcon;

    @FindBy(xpath = "//button[contains(@class,'buttonMinus')]")
    private WebElement MinusButton;

    @FindBy(xpath = "//button[contains(@class,'buttonPlus')]")
    private  WebElement PlusButton;


    public MyCartPage(WebDriver driver,Scenario scenario) throws InterruptedException, AWTException
    {
        this.driver=driver;
        this.scenario=scenario;
        PageFactory.initElements(driver,this);
    }

    //Click on Check out to order button
    public void CheckOut_To_Order()
    {
        try
        {
            WebElement WebEle=null;
            HelpersMethod.Implicitwait(driver,25);
            HelpersMethod.waitTillTitleContains(driver,"Ignition - Order Cart",15);
            HelpersMethod.ScrollElement(driver,CheOutOrder);
            HelpersMethod.ActClick(driver,CheOutOrder,10);

            HelpersMethod.Implicitwait(driver,15);//20

            if(HelpersMethod.IsExists("//div[contains(text(),'Select order')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::div[contains(text(),'New order')]");
                    HelpersMethod.ActClick(driver,WebEle,1);
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                    HelpersMethod.ClickBut(driver,WebEle,2);
                }
            WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,15);
        }
        catch (Exception e)
        {//scenario.log("NOT ABLE TO HANDLE CHECK OUT ORDER");
        }
    }

    //Delete button in 'My cart' page
    public void DeleteButton()
    {
        try
        {
            HelpersMethod.Implicitwait(driver, 10);
            WebElement Del_But = HelpersMethod.FindByElement(driver, "xpath", "//tr[1]//*[local-name()='svg' and contains(@class,'delete')]");
            HelpersMethod.ActClick(driver,Del_But,10);
            HelpersMethod.Implicitwait(driver, 20);
        }
        catch (Exception e)
        {scenario.log("DELETE BUTTON IS NOT VISIBLE");}
    }
}
