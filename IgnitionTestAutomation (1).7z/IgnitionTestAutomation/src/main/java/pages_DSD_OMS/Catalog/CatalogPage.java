package pages_DSD_OMS.Catalog;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class CatalogPage
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;

    String XPath=null;
    static boolean exists=false;

    @FindBy(xpath="//button[contains(text(),'Reset filter')]")
    private WebElement ResetFilter;

    @FindBy(xpath = "//input[contains(@placeholder,'Search products')]")
    private WebElement SearchBar;

    @FindBy(xpath = "//span[contains(@class,'search-button-addon search-button input-group-addon')]/descendant::*[local-name()='svg']")
    private WebElement SearchIndex;

    @FindBy(xpath ="//input[contains(@id,'Units')]")
    private WebElement unit_Qty;

    @FindBy(xpath = "//input[contains(@id,'Cases)]")
    private WebElement case_Qty;

    @FindBy(xpath="//input[contains(@id,'ProductGridItemQuantityContainer')]")
    private WebElement Qtycard;

    @FindBy(id="sort-by-dropdown")
    private WebElement SortByDropDown;

    @FindBy(xpath="//div[contains(@class,'items-found-container')]//*[local-name()='svg']/*[local-name()='path' and contains(@d,'M4')]")
    private WebElement CardView;

    @FindBy(xpath ="//div[contains(@class,'items-found-container')]//*[local-name()='svg']/*[local-name()='path' and contains(@d,'M3')]")
    private WebElement ListView;

    @FindBy(xpath = "//button[contains(@class,'buttonPlus ')]")
    private WebElement QtyPlus;

    @FindBy(xpath = "//button[contains(@class,'buttonMinus')]")
    private WebElement QtyMinus;

    @FindBy(xpath = "//button/descendant::span[text()='Add to cart']")
    private WebElement AddToCart;

    @FindBy(xpath = "//div[contains(@class,'shopping-cart-container')]//*[local-name()='svg']/*[local-name()='path' and contains(@d,'M15')]")
    private WebElement Cart;

    @FindBy(id="CPcategories")
    private WebElement Categories;

    @FindBy(id="CPbrands")
    private WebElement SubCat;

    @FindBy(id="CPsizes")
    private WebElement Brand;

    @FindBy(id="CPorderGuies")
    private WebElement OGDrop;


    //Constructor for Catalog page, Initializing the Page Objects:
    public CatalogPage(WebDriver driver, Scenario scenario)
    {
        this.scenario=scenario;
        this.driver =driver;
        PageFactory.initElements(driver,this);
    }

    public boolean ValidateCatalog()
    {
        exists=false;
        try
        {
            HelpersMethod.Implicitwait(driver,30);
            if(HelpersMethod.gettingURL(driver).contains("cpProductCatalog"))
            {
                exists=true;
            }
        }
        catch (Exception e){}
        return exists;
    }

    //code to click on Reset button
    public void Click_ResetFilterButton()
    {
        try
        {
            HelpersMethod.Implicitwait(driver,10);
            HelpersMethod.ClickBut(driver,ResetFilter,4);
        }
        catch (Exception e){}
    }

    //Code to click on Card view
    public void Click_CardView()
    {
        try
        {
           // HelpersMethod.Implicitwait(driver,10);
            HelpersMethod.ActClick(driver,CardView,8);
        }
        catch (Exception e){}
    }

    //code to click on List view
    public void Click_ListView()
    {
        try
        {
            HelpersMethod.ActClick(driver,ListView,1);
        }
        catch (Exception e){}
    }

    //Verify existence of sort by best match drop down, and then click on it. And select value from drop down
    public boolean Best_MatchDropDown(String DropSelect)
    {
        boolean result=false;
        HelpersMethod.Implicitwait(driver,10);
        try
        {
            if(HelpersMethod.EleDisplay(SortByDropDown))
            {
                HelpersMethod.ActClick(driver,SortByDropDown,4);
                HelpersMethod.DropDownMenu(driver, "//ul[contains(@class,'k-list k-reset')]/li", DropSelect);
                List<WebElement> Prices = HelpersMethod.FindByElements(driver, "xpath", "//span[@class='product-price']");
                ArrayList<Double> Prices1=new ArrayList<Double>();
                ArrayList<Double> Prices2=new ArrayList<Double>();

                //copy content of web element, i.e. prices to list
                for(WebElement Price:Prices)
                {
                    String Price_Text=Price.getText();
                    if(!Price_Text.equals(" "))
                    {
                        Prices1.add(Double.valueOf(Price_Text));
                        Prices2.add(Double.valueOf(Price_Text));
                    }
                }
                //Sort the values in ascending order
                HelpersMethod.Implicitwait(driver,5);
                Collections.sort(Prices1);

                //Comparing List of integers, to find whether array is in sorted order
                for (int i = 0; i < Prices1.size(); i++)
                {
                    System.out.println("VALUES AFTER SELECTING PRICE SORT FROM DROP DOWN "+Prices1.get(i)+" VALUE AFTER PROGRAMMATICALLY SORTING "+Prices2.get(i));
                    if (Prices1.get(i).equals(Prices2.get(i)))
                    {
                        result = true;
                        scenario.log("PRICES ARE IN SORTED ORDER");
                    }
                    else
                    {
                        result=false;
                        scenario.log("PRICES ARE NOT IN SORTED ORDER");
                        break;
                    }
                }
            }
        }
        catch (Exception e){}
        return result;
    }

    //Code for entering product#s in search bar
    public void SearchProduct(String Prod_no)
    {
        try
        {
            WebElement ProductCard= HelpersMethod.FindByElement(driver,"id","productsCard");
            HelpersMethod.ScrollElement(driver,ProductCard);
            HelpersMethod.ClearText(driver,SearchBar,4);
            HelpersMethod.ActSendKey(driver,SearchBar,2,Prod_no);
            HelpersMethod.ActClick(driver,SearchIndex,1);
            HelpersMethod.Implicitwait(driver,5);
        }
        catch (Exception e){}
    }

    //Validate whether product details are displayed or not
    public void ProductExistsCard(String Qty_unit,String Qty_case)
    {
        try
        {
            //Find number of input boxes available to enter Qty with product details
            List<WebElement> Inputs=HelpersMethod.FindByElements(driver,"xpath","//input[contains(@id,'ProductGridItemQuantityContainer')]");
            WebElement Button_Ele=null;
            if(Inputs.size()==2)
            {
                //HelpersMethod.ScrollElement(driver,Inputs.get(0));
                //Enter Qty in input boxs,Check for units input box
                if (HelpersMethod.IsExists("//input[contains(@id,'Units')]", driver))
                {
                    // HelpersMethod.ActSendKey(driver,unit_Qty,Qty_unit);
                    HelpersMethod.ClearText(driver,unit_Qty,4);
                    HelpersMethod.EnterText( driver,unit_Qty,1,Qty_unit);
                    exists = HelpersMethod.IsExists("//div[contains(text(),'currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]", driver);
                    if (exists == true)
                    {
                        Button_Ele=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                        HelpersMethod.ClickBut(driver,Button_Ele,2);
                    }
                }
                else if (HelpersMethod.IsExists("//input[contains(@id,'Cases)]", driver))
                {
                    // HelpersMethod.ActSendKey(driver,case_Qty,Qty_case);
                    HelpersMethod.ClearText(driver,case_Qty,4);
                    HelpersMethod.EnterText(driver,case_Qty,2,Qty_case);
                    exists = HelpersMethod.IsExists("//div[contains(text(),'currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]", driver);
                    if (exists == true)
                    {
                        Button_Ele=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                        HelpersMethod.ClickBut(driver,Button_Ele,4);
                    }
                }
            }
            else
            {
               // HelpersMethod.ScrollElement(driver,Inputs.get(0));
                HelpersMethod.ClearText(driver,Qtycard,4);
                HelpersMethod.EnterText(driver,Qtycard,2,Qty_unit);
                exists=HelpersMethod.IsExists("//div[contains(text(),'currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver);
                if(exists==true)
                {
                    Button_Ele=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                    HelpersMethod.ClickBut(driver,Button_Ele,4);
                }
            }
            //Click on Add to cart button
            HelpersMethod.ClickBut(driver,AddToCart,4);
            HelpersMethod.Implicitwait(driver,8);
        }
        catch (Exception e) { }
    }

    //Click on Cart button
    public boolean Cart_Button()
    {
       exists=false;
       HelpersMethod.Implicitwait(driver,10);
        try
        {
            if(HelpersMethod.EleDisplay(Cart))
            {
                HelpersMethod.ActClick(driver,Cart,1);
               // HelpersMethod.JScriptClick(Cart,driver);
                HelpersMethod.WaitElementPresent(driver,"xpath","//div[contains(text(),'Shopping cart')]/ancestor::div[@class='popup-content']",20);
                if(HelpersMethod.IsExists("//div[contains(text(),'Shopping cart')]/ancestor::div[@class='popup-content']",driver))
                {
                    exists=true;
                }
            }
        }
        catch (Exception e){}
        return exists;
    }

    //Click on GotoCart button
    public void GotoCartClick()
    {
        try
        {
            Actions act = new Actions(driver);
            //Create instance of web driver wait, i.e. explisit wait
            WebDriverWait wait = new WebDriverWait(driver, 10);
            //create webelement for shopping cart popup
            WebElement ShoppingCart = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='popup-content']");

            //reload the Webelement ShoppingCart
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='popup-content']")));
            ShoppingCart = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='popup-content']");
            act.moveToElement(ShoppingCart).build().perform();

            //Move control to GotoCart button and click on it
            WebElement GotoCart = HelpersMethod.FindByElement(driver, "id", "goToCartButton");
            HelpersMethod.EleDisplay(GotoCart);

            act.moveToElement(GotoCart).build().perform();
            act.click(GotoCart).build().perform();
        }
        catch (Exception e){}
    }

    //Code to Delete Product from Shopping cart popup and Click on GotoCart button
    public void DeleteProd_GotoCartClick()
    {
        try {
            HelpersMethod.Implicitwait(driver,15);
            Actions act = new Actions(driver);
            //HelpersMethod.Implicitwait(driver,20);
            //Thread.sleep(30000);
            //Create instance of web driver wait, i.e. explisit wait
            WebDriverWait wait = new WebDriverWait(driver, 5);
            //create webelement for shopping cart popup
            WebElement ShoppingCart = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='popup-content']");
            //move control to shopping cart popup
            act.moveToElement(ShoppingCart).build().perform();

            HelpersMethod.Implicitwait(driver,4);
            // Thread.sleep(2000);
            WebElement ProdRow = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='shopping-cart-row'][1]");
            act.moveToElement(ProdRow).build().perform();
            //Create Webelement for 'x' of first product
            WebElement x_Delete = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='shopping-cart-row'][1]/descendant::div[@class='item-remove-button']");

            //Move control 'x' button of first product to delete the product from cart
            act.moveToElement(x_Delete).build().perform();
            act.click(x_Delete).build().perform();
        }
        catch (Exception e) {}
    }
    //Code to click on Goto cart button, this part of code is used only in scenario where trying to delete product from shopping cart popup
    public void ClickGotoCart1()
    {
        try
        {
            //Thread.sleep(3000);
            HelpersMethod.Implicitwait(driver,4);
            Actions act = new Actions(driver);
            //Create instance of web driver wait, i.e. explisit wait
            WebDriverWait wait = new WebDriverWait(driver, 10);
            //create webelement for shopping cart popup
            WebElement ShoppingCart = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='popup-content']");

            //reload the Webelement ShoppingCart
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='popup-content']")));
            ShoppingCart = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='popup-content']");
            act.moveToElement(ShoppingCart).build().perform();

            //Move control to GotoCart button and click on it
            WebElement GotoCart = HelpersMethod.FindByElement(driver, "id", "goToCartButton");
            HelpersMethod.EleDisplay(GotoCart);

            act.moveToElement(GotoCart).build().perform();
            act.click(GotoCart).build().perform();
        }
        catch (Exception e) {}
    }

    //click on checkout to order
    public boolean Checkout_to_order()
    {
        exists=false;
        try
        {
           HelpersMethod.Implicitwait(driver,25);
         //   HelpersMethod.WaitElementPresent(driver,"id","cartItemsCard",25);
            if(HelpersMethod.IsExists("//span[contains(text(),'Items in cart')]",driver))
            {
                exists=true;
                WebElement Checkout=HelpersMethod.FindByElement(driver,"id","checkoutToOrder");
                if(Checkout.isEnabled())
                {
                    HelpersMethod.ScrollElement(driver, Checkout);
                    HelpersMethod.ActClick(driver,Checkout,1);

                    HelpersMethod.Implicitwait(driver,5);
                    //Check for Pending order popup and select start new order button in popup
                    if (HelpersMethod.IsExists("//div[contains(text(),' open order that is pending submission.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]", driver))
                    {
                        WebElement Button_Start = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[contains(text(),'Start new order')]");
                        HelpersMethod.ActClick(driver,Button_Start,1);
                    }
                }
            }
            HelpersMethod.Implicitwait(driver,40);
        }
        catch (Exception e){}
        return exists;
    }

    //Select new order from popup
    public void NewOrder_Option()
    {
        try
        {
            if(HelpersMethod.EleDisplay(HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'Select order')]/ancestor::div[@class='k-widget k-window k-dialog']")))
            {
                WebElement NewOrderPop=HelpersMethod.FindByElement(driver,"xpath","//div[@class='k-widget k-window k-dialog']/descendant::div[contains(text(),'New order')]");
                HelpersMethod.ActClick(driver,NewOrderPop,6);
                WebElement Button_Ele= HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ClickBut(driver,Button_Ele,2);
            }
        }
        catch (Exception e){}
    }

    //Code to Delete product details from my cart page
    public void DeleteMyCart()
    {
        try
        {
            WebElement DeletePro=HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row')][1]//*[local-name()='svg' and contains(@class,'i-icon   delete-button ')]");
            HelpersMethod.ClickBut(driver,DeletePro,2);
        }
        catch (Exception e){}
    }

    //Select the first order from the existing order
    public void AddProductToOrder()
    {
        try
        {
            if(HelpersMethod.EleDisplay(HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'Select order')]/ancestor::div[@class='k-widget k-window k-dialog']")))
            {
                WebElement ProdNo=HelpersMethod.FindByElement(driver,"xpath","//div[@class='k-widget k-window k-dialog']/descendant::div[contains(text(),'#' )][1]");
                HelpersMethod.ActClick(driver,ProdNo,1);
                WebElement Button_Ele=HelpersMethod.FindByElement(driver,"xpath","//div[@class='k-widget k-window k-dialog']/descendant::button[text()='Ok']");
                HelpersMethod.ClickBut(driver,Button_Ele,2);
            }
        }
        catch (Exception e){}
    }

    //Click on image of product
    public void ClickImage()
    {
        try
        {
            WebElement Prodimg=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'search-results-container')]/descendant::img[@class='product-thumb']");
            HelpersMethod.ScrollElement(driver,Prodimg);
            HelpersMethod.ClickBut(driver,Prodimg,2);
        }
        catch (Exception e){}
    }

    //Enter product details in search box separated by comma
    public boolean EnterProdSeparatedByComma(List<String> Prod)
    {
        exists=false;
        try
        {
            String Products="";
            List<String> ProdList=new ArrayList<String>();
            List<String> Prod1=new ArrayList<>();

            for(int i=0;i<=Prod.size()-1;i++)
            {
                Products=Products+String.valueOf(Prod.get(i)+", ");
            }
            HelpersMethod.EnterText(driver,SearchBar,2,Products);
            HelpersMethod.ClickBut(driver,SearchIndex,2);

            //get the product no. that get displayed on catalog page
            List<WebElement> Prods=HelpersMethod.FindByElements(driver,"xpath","//div[@class='product-number']/descendant::span") ;
            for (WebElement Pro:Prods)
            {
                String Pro_Text=Pro.getText();
                scenario.log("PRODUCT FOUND IS "+Pro_Text);
                ProdList.add(Pro_Text.substring(1));
                Collections.sort(ProdList);
            }

            //code to remove precding zero's from product number
            for (int i=0;i<=Prod.size()-1;i++)
            {
                //removing leading zeros
                String ProdNo= StringUtils.stripStart(Prod.get(i),"0");
                Prod1.add(ProdNo);
            }

            //traverse through list to read product no. from both the list
            for(int i=0;i<=Prod1.size()-1;i++)
            {
                  if(ProdList.get(i).equals(Prod1.get(i)))
                  {
                      exists=true;
                  }
                  else
                  {
                      exists=false;
                      break;
                  }
            }
        }
        catch (Exception e){}
        return exists;
    }

    //Code to increase or decrease the qty
    public void PlusMinus()
    {
        try
        {
            WebElement Plus1=HelpersMethod.FindByElement(driver,"xpath", "//tr[1]/descendant::button[contains(@class,'Plus')]");
            WebElement Minus1=HelpersMethod.FindByElement(driver,"xpath","//tr[1]/descendant::button[contains(@class,'Minu')]");
            WebDriverWait wait1=new WebDriverWait(driver,10);

            for(int i=0;i<=4;i++)
            {
                wait1.until(ExpectedConditions.elementToBeClickable(Plus1));
                Plus1=HelpersMethod.FindByElement(driver,"xpath", "//tr[1]/descendant::button[contains(@class,'Plus')]");
                HelpersMethod.ClickBut(driver,Plus1,2);
            }
            for(int i=0;i<=2;i++)
            {
                wait1.until(ExpectedConditions.elementToBeClickable(Minus1));
                Minus1=HelpersMethod.FindByElement(driver,"xpath","//tr[1]/descendant::button[contains(@class,'Minu')]");
                HelpersMethod.ClickBut(driver,Minus1,2);
            }
        }
        catch (Exception e){}
    }

    public void CatalogCategoryDropDown()
    {
        try
        {
            HelpersMethod.ClickBut(driver,Categories,4);
            String Value_Text = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-child-animation-container')]/descendant::li[2]").getText();
            HelpersMethod.WebElementFromDropDown(driver, "//div[contains(@class,'k-child-animation-container')]/descendant::li", "xpath", Value_Text);
            scenario.log("Categories selected is "+Categories.getText());
        }
        catch (Exception e) {}
    }

    public void ReadProduct()
    {
        try
        {
            if (HelpersMethod.IsExists("//div[@id='no-products-found']",driver))
            {
                scenario.log("NO PRODUCTS OF SELECTED CATEGORY IS AVAILABLE");
            }
            else
            {
                if(HelpersMethod.IsExists("//div[@class='card-view']",driver))
                {
                    List<WebElement> Product_Nos = HelpersMethod.FindByElements(driver, "xpath", "//div[@class='product-number']/span");
                    for (WebElement Prod_No : Product_Nos)
                    {
                        String Prod_Text = Prod_No.getText();
                        scenario.log("PRODUCT FOUND IS: " + Prod_Text);
                    }
                }
                else if(HelpersMethod.IsExists("//div[@class='list-view']",driver))
                {
                    List<WebElement> Product_Nos = HelpersMethod.FindByElements(driver, "xpath", "//tr[contains(@class,'k-master-row')]/descendant::span[contains(text(),'#')]");
                    for (WebElement Prod_No : Product_Nos)
                    {
                        String Prod_Text = Prod_No.getText();
                        scenario.log("PRODUCT FOUND IS: " + Prod_Text);
                    }
                }
            }
        }
        catch (Exception e){}
    }

    public void CatalogSubCategoryDropDown()
    {
        try
        {
            HelpersMethod.ClickBut(driver,SubCat,4);
            String Value_Text=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-child-animation-container')]/descendant::li[2]").getText();
            HelpersMethod.WebElementFromDropDown(driver,"//div[contains(@class,'k-child-animation-container')]/descendant::li","xpath",Value_Text);
            scenario.log("SubCategory selected is "+SubCat.getText());
        }
        catch (Exception e){}
    }

    public void BrandDropDown()
    {
        try
        {
            HelpersMethod.ClickBut(driver,Brand,4);
            String Value_Text=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-child-animation-container')]/descendant::li[2]").getText();
            HelpersMethod.WebElementFromDropDown(driver,"//div[contains(@class,'k-child-animation-container')]/descendant::li","xpath",Value_Text);
            scenario.log("Brand selected is "+Brand.getText());
        }
        catch (Exception e){}
    }

    public void OGDropDown()
    {
        exists=false;
        try
        {
            exists=HelpersMethod.IsExists("//span[@id='CPorderGuies']",driver);
            if(exists==true)
            {
                HelpersMethod.ClickBut(driver,OGDrop,4);
                String Value_Text = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-child-animation-container')]/descendant::li[2]").getText();
                HelpersMethod.WebElementFromDropDown(driver, "//div[contains(@class,'k-child-animation-container')]/descendant::li", "xpath", Value_Text);
                WebElement OGDrop=HelpersMethod.FindByElement(driver,"id","CPorderGuies");
                scenario.log("ORDER GUIDE SELECTED FROM DROP DOWN "+OGDrop.getText());
            }
            else
            {
                scenario.log("ORDER GUIDE DROP DOWN IS NOT EXISTING, MAY NEED TO ENABLE ADMIN SETTING");
            }
        }
        catch (Exception e){}
    }

    public void FeaturedReadProduct()
    {
        exists=false;
        try
        {
           exists=HelpersMethod.IsExists("//div[@class='slick-slider slick-initialized']",driver);
            if(exists==false)
            {
                scenario.log("FEATURED PRODUCTS LIST IS NOT DISPLAYED");
            }
           Assert.assertEquals(exists,true);
           //create list of webelements, containing list of products in featured products
           List<WebElement> Product_Nos = HelpersMethod.FindByElements(driver, "xpath", "//div[@class='product-number']");
            for (WebElement Prod_No : Product_Nos)
            {
                String Prod_Text = Prod_No.getText();
                scenario.log("FEATURED PRORDUCT : " + Prod_Text);
            }
        }
        catch (Exception e){}
    }

    public void RecentSearch()
    {
        exists=false;
        try
        {
            exists=HelpersMethod.IsExists("//div[@class='recent-searches-container']",driver);
            if(exists==false)
            {
                scenario.log("RECENT SEARCH CARD IS DISABLED,ENABLE IT IN ADMIN SETTINGS");
            }
            Assert.assertEquals(exists,true);
            //create list of webelements, containing list of products in featured products
            List<WebElement> Product_Nos = HelpersMethod.FindByElements(driver, "xpath", "//div[contains(@id,'Search_')]");
            for (WebElement Prod_No : Product_Nos)
            {
                String Prod_Text = Prod_No.getText();
                scenario.log("FEATURED PRORDUCT : " + Prod_Text);
            }
        }
        catch (Exception e){}
    }

}
