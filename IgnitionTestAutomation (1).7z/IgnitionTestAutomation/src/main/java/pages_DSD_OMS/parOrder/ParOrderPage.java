package pages_DSD_OMS.parOrder;

import com.sun.tools.xjc.reader.xmlschema.bindinfo.BIConversion;
import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;

/**
 * @Project OMS_DSD
 * @Author Divya.Ramadas@afsi.com
 */
public class ParOrderPage
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;
    boolean exists=false;
    String ProdNo=null;

    @FindBy(id = "plusAdditionalAccountButtonFlat")
    private WebElement NewPar;

    @FindBy(id="deleteAdditionalAccountButton")
    private WebElement DelPar;

    @FindBy(xpath ="//label[contains(text(),'Par list')]/following-sibling::span/span[@id='dropDownNoneType']")
    private WebElement ParlistDropdown;

    @FindBy(xpath="//label[contains(text(),'Code')]/following-sibling::input")
    private WebElement ParCode;

    @FindBy(xpath="//div[@class='parList-container']/descendant::label[contains(text(),'Description')]/following-sibling::input")
    private WebElement ParDes;

    @FindBy(xpath = "//div[@class='parList-container']/descendant::input[@id='SearchBox1']")
    private WebElement ParSearchBox;

    @FindBy(id="save")
    private WebElement ParSave;

    @FindBy(id="OGSaveButton")
    private WebElement OGSave;

    @FindBy(id="OGCancelButton")
    private WebElement OGCancel;

    public ParOrderPage(WebDriver driver,Scenario scenario)
    {
        this.driver=driver;
        this.scenario=scenario;
        PageFactory.initElements(driver,this);
    }

    //Actions methods
    public void ClickParTab()
    {
        try
        {
            HelpersMethod.Implicitwait(driver,10);
            WebElement ParList=HelpersMethod.FindByElement(driver,"xpath","//span[contains(text(),'Par list')]");
            HelpersMethod.ActClick(driver,ParList,0);
            HelpersMethod.Implicitwait(driver,10);
        }
        catch (Exception e){}
    }

    public boolean ValidateParlistTab()
    {
        exists=false;
        try
        {
            HelpersMethod.WaitElementPresent(driver,"xpath","//div[@class='parList-container']",10);
           exists = HelpersMethod.IsExists("//div[@class='parList-container']",driver);
        }
        catch (Exception e){}
        return exists;
    }

    public void ClickNewPar()
    {
        try
        {
            HelpersMethod.ClickBut(driver,NewPar,1);
        }
        catch (Exception e){}
    }

    public void DeletePar()
    {
        try
        {
            HelpersMethod.ClickBut(driver,DelPar,2);
            if(HelpersMethod.IsExists("//div[contains(text(),'Delete')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
               WebElement Ok_But=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
               HelpersMethod.ActClick(driver,Ok_But,1);
            }
        }
        catch (Exception e){}
    }

    public void EnterCode(String Code)
    {
        try
        {
            HelpersMethod.ClearText(driver,ParCode,4);
            HelpersMethod.EnterText(driver,ParCode,2,Code);
        }
        catch (Exception e){}
    }

    public void EnterDesc(String Desc)
    {
        try
        {
            HelpersMethod.ClearText(driver,ParDes,4);
            HelpersMethod.EnterText(driver,ParDes,2,Desc);
        }
        catch (Exception e){}
    }

    public void SavePar()
    {
        try
        {
            //////HelpersMethod.Implicitwait(driver,8);
            HelpersMethod.ClickBut(driver,ParSave,10);
           ///// HelpersMethod.Implicitwait(driver,2);
           if(HelpersMethod.IsExists("//div[contains(text(),'Par list')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                WebElement Ok_But=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                HelpersMethod.ActClick(driver,Ok_But,1);
            }
        }
        catch (Exception e){}
    }

    public void ReadProductValueFromOG()
    {
        try
        {
            WebElement WebEle=null;
            WebEle=HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row')][1]/descendant::button");
            ProdNo=WebEle.getText();
        }
        catch (Exception e){}
    }

    public void ClickParDropDown()
    {
        try
        {
          //  HelpersMethod.Implicitwait(driver,4);
            HelpersMethod.ActClick(driver,ParlistDropdown,4);
        }
        catch (Exception e){}
    }

    public void SelectParlistFromDropdown(String parList)
    {
        try
        {
            WebElement WebEle=null;
            String ParDes=null;
            HelpersMethod.WebElementFromDropDown(driver,"","xpath",parList);
            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'parList-container')]/descendant::label[text()='Description']/following-sibling::input");
            ParDes=HelpersMethod.JSGetValueEle(driver,WebEle,6);
            Assert.assertEquals(parList,ParDes);
        }
        catch (Exception e){}
    }

    public void EnterProductNoInSearchBox()
    {
        try
        {
            WebElement WebEle=null;
            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='i-search-box']/descendant::input");
            HelpersMethod.EnterText(driver,WebEle,2,ProdNo);
            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='i-search-box']//*[local-name()='svg' and contains(@class,'search-box__search')]");
            HelpersMethod.ClickBut(driver,WebEle,2);
            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'i-no-data__icon')]");
            if(!WebEle.isDisplayed())
            {
                scenario.log("PRODUCT HAS NOT BEEN FOUND IN PARLIST");
            }
            else
            {
                scenario.log("PRODUCT HAS BEEN FOUND IN PARLIST");
            }
        }
        catch (Exception e){}
    }

    public void ReadProducts()
    {
        try
        {
            String ProdNo=null;
            List<WebElement> Prods=HelpersMethod.FindByElements(driver,"xpath","//tr[contains(@class,'k-master-row ')]/descendant::button");
            for(WebElement Prod:Prods)
            {
                ProdNo=Prod.getText();
                scenario.log("PRODUCT FOUND IN PARLIST "+ProdNo);
            }
        }
        catch (Exception e){}
    }

    public boolean ConfirmDeletePar()
    {
        exists=false;
        try
        {
            HelpersMethod.ActClick(driver,ParlistDropdown,2);


        }
        catch (Exception e){}
        return exists;
    }


}
