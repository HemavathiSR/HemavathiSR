package pages_DSD_OMS.quote;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class QuoteSummaryPage
{
    WebDriver driver;
    Scenario scenario;
    static boolean exists=false;

    @FindBy(id="OrdersButton")
    private WebElement BackToOrderList;

    @FindBy(id="ConverToOrderGuideBtn")
    private WebElement ConvertOG;

    @FindBy(id="CopyQuoteBtn")
    private WebElement CopyQuote;

    @FindBy(id="CancelSummaryButton")
    private WebElement CancelButton;

    @FindBy(id="createOrderButton")
    private WebElement ConvertOrder;

    @FindBy(id="EditButton")
    private WebElement EditButton;

    public QuoteSummaryPage(WebDriver driver, Scenario scenario)
    {
        this.driver=driver;
        this.scenario=scenario;
        PageFactory.initElements(driver,this);
    }

    //Actions
    public void ClickOnBackToOrder()
    {
        HelpersMethod.Implicitwait(driver,10);
        exists=false;
        try
        {
            if(BackToOrderList.isDisplayed())
            {
                HelpersMethod.ClickBut(driver,BackToOrderList,8);
                exists=true;
            }
            Assert.assertEquals(exists,true);
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);
        }
        catch (Exception e){}
    }

    public void ClickOnConvertOG()
    {
        exists=true;
        try
        {
         if(ConvertOG.isDisplayed())
         {
             HelpersMethod.ClickBut(driver,ConvertOG,8);
             exists=true;
         }
         Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void ClickOnConvertOrder()
    {
        exists=true;
        try
        {
            if(ConvertOrder.isDisplayed())
            {
                HelpersMethod.ClickBut(driver,ConvertOrder,8);
                exists=true;
            }
            Assert.assertEquals(exists,true);
            exists=false;
            WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'Convert quote to order')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]");
            if(WebEle.isDisplayed())
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                HelpersMethod.ClickBut(driver,WebEle,4);
                exists=true;
                WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 20);
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void ClickOnCancel()
    {
        exists=true;
        try
        {
            if(ConvertOrder.isDisplayed())
            {
                HelpersMethod.ClickBut(driver,CancelButton,8);
                exists=true;
            }
            Assert.assertEquals(exists,true);
            exists=false;
            WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'Cancel quote')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]");
            if(WebEle.isDisplayed())
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                HelpersMethod.ClickBut(driver,WebEle,4);
                exists=true;
                WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 20);
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void ClickOnCopy()
    {
        exists=false;
        try
        {
            if(CopyQuote.isDisplayed() && CopyQuote.isEnabled())
            {
                HelpersMethod.ClickBut(driver,CopyQuote,6);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void ClickOnEdit()
    {
        exists=false;
        try
        {
            if(EditButton.isDisplayed())
            {
                HelpersMethod.ClickBut(driver,EditButton,6);
                WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 20);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void NavgiateBackToOE()
    {
        exists=false;
        try
        {
            HelpersMethod.navigate_Horizantal_Tab(driver, "Orders", "//li[contains(@class,'k-item')]/span[@class='k-link' and contains(text(),'Orders')]", "xpath", "//li[contains(@class,'k-item')]/span[@class='k-link']");
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 20);
        }
        catch (Exception e){}
    }
}
