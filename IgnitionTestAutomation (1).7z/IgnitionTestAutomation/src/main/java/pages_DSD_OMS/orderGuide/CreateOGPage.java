package pages_DSD_OMS.orderGuide;

import gherkin.lexer.He;
import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import util.TestBase;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class CreateOGPage
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;
    static boolean exists = false;
    static String XPath = null;
    static String DOfWeek=null;


    @FindBy(xpath = "//label[text()='Description']/following-sibling::input")
    private WebElement OG_Des;

    @FindBy(id = "quickProduct")
    private WebElement QuickProd;

    @FindBy(id = "quickSequence")
    private WebElement Sequence;

    @FindBy(xpath = "//button[contains(text(),'Add product')]")
    private WebElement AddProd;

    @FindBy(id = "buttonDelete")
    private WebElement DeleteProd;

    @FindBy(id = "Export")
    private WebElement OGExport;

    @FindBy(xpath = "//label[text()='Import']")
    private WebElement OGImport;

    @FindBy(xpath = "//div[@class='i-search-box']/descendant::input")
    private WebElement Searchbox;

    @FindBy(xpath = "//div[@class='i-search-box']//*[local-name()='svg']/*[local-name()='path' and contains(@d,'M15.5')]")
    private WebElement SearchIndex;

    @FindBy(xpath = "//button/descendant::span[contains(text(),'Add filter')]")
    private WebElement Addfilter;

    @FindBy(id = "checkBoxD")
    private WebElement AllCustCheckbox;

    @FindBy(xpath = "//label[contains(text(),'Day of week')]/following-sibling::span[contains(@class,'k-widget k-dropdown')]/span")
    private WebElement DayOfWeek;

    @FindBy(xpath = "//label[contains(text(),'Status')]/following-sibling::span[contains(@class,'k-widget k-dropdown')]/span")
    private WebElement Status;

    @FindBy(xpath = "//label[text()='Type']/following-sibling::span/span[@class='k-dropdown-wrap']")
    private WebElement Type;

    @FindBy(xpath = "//label[contains(text(),'Valid to')]/following-sibling::span/descendant::span[contains(@class,'k-icon k-i-calendar')]")
    private WebElement ValidTo;

    @FindBy(xpath = "//label[contains(text(),'Valid from')]/following-sibling::span/descendant::span[contains(@class,'k-icon k-i-calendar')]")
    private WebElement ValidFrom;

    @FindBy(id = "OGSaveButton")
    private WebElement OGSave;

    @FindBy(id = "OGCancelButton")
    private WebElement OGCancel;

    @FindBy(xpath="//button[text()='More']")
    private WebElement More;

    @FindBy(xpath = "//div[@id='card1']/descendant::button[text()='Delete']")
    private WebElement OG_Delete;

    public CreateOGPage(WebDriver driver, Scenario scenario)
    {
        this.scenario = scenario;
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    //Code to validate whether user navigated to New OG page or not
    public boolean ValidateNewOG()
    {
        exists = false;
        try
        {
            if (HelpersMethod.IsExists("//div[contains(@class,'topHeaderRow row')]/descendant::span[contains(text(),'New order guide')]", driver))
            {
                exists = true;
            }
        } catch (Exception e) {
        }
        return exists;
    }

    //code to enter values in description page
    public void DescriptionOG(String OGDesc)
    {
        try
        {
            HelpersMethod.EnterText(driver,OG_Des,4,OGDesc);
        }
        catch (Exception e) {}
    }
    //Code to click on Start date calender
    public void CalenderStart()
    {
        try
        {
            HelpersMethod.ScrollElement(driver,ValidFrom);
            HelpersMethod.ActClick(driver,ValidFrom, 2);
        }
        catch (Exception e) {}
    }

    //Code to click on End date calender
    public void CalenderEnd()
    {
        try
        {
            HelpersMethod.ScrollElement(driver,ValidTo);
            HelpersMethod.ActClick(driver,ValidTo, 2);
        }
        catch (Exception e) {}
    }

    //Selecting Start date
    public void SelectStartDate(String ChangeDate,int i)
    {
        try
        {
            String formattedDate1 = null;
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[contains(@class,'k-calendar-view k-calendar-monthview')]",6);
            //finding element/date in calendar drop down is enabled or not. if not enabled increase the date by 6 days
            String ele = "//div[contains(@class,'k-calendar-view k-calendar-monthview')]";
            boolean visible = HelpersMethod.IsExists(ele, driver);
            if (visible == true)
            {
                LocalDate myDateObj = LocalDate.now().plusDays(i);
                DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
                formattedDate1 = myDateObj.format(myFormatObj);
                WebElement ele1 = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-calendar-view k-calendar-monthview')]/descendant::td[contains(@title,'" + formattedDate1 + "')]");
                HelpersMethod.JSScroll(driver,ele1);
                HelpersMethod.ActClick(driver, ele1, 2);
                scenario.log(formattedDate1 + " HAS BEEN SELECTED AS START DATE FOR OG");
            }
            else
            {
                scenario.log("CALENDER DROP DOWN DOESN'T EXISTS");
            }
        }
        catch (Exception e) {}
    }

    //selecting end date
    public void SelectEndDate(String ChangeDate, int i)
    {
        try
        {
            String formattedDate1 = null;
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[contains(@class,'k-calendar-view k-calendar-monthview')]",6);
            //finding element/date in calendar drop down is enabled or not. if not enabled increase the date by 6 days
            String ele = "//div[contains(@class,'k-calendar-view k-calendar-monthview')]";
            boolean visible = HelpersMethod.IsExists(ele, driver);
            if (visible == true)
            {
                LocalDate myDateObj = LocalDate.now().plusDays(i);
                DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
                formattedDate1 = myDateObj.format(myFormatObj);
                WebElement ele1 = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-calendar-view k-calendar-monthview')]/descendant::td[contains(@title,'" + formattedDate1 + "')]");
                HelpersMethod.JSScroll(driver,ele1);
                HelpersMethod.ActClick(driver,ele1, 1);
                scenario.log(formattedDate1 + " HAS BEEN SELECTED AS END DATE FOR OG");
                DateTimeFormatter myFormatObjDay = DateTimeFormatter.ofPattern("EEEE");
                DOfWeek=  myDateObj.format(myFormatObjDay);
            }
            else
            {
                scenario.log("CALENDER DROP DOWN DOESN'T EXISTS");
            }
        }
        catch (Exception e) {}
    }

    //Code to Set the Valid To date as past date
    public void ValidToDatePast()
    {
        try
        {
            String formattedDate1 = null;
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[contains(@class,'k-calendar-view k-calendar-monthview')]",6);
            //finding element/date in calendar drop down is enabled or not. if not enabled increase the date by 6 days
            String ele = "//div[contains(@class,'k-calendar-view k-calendar-monthview')]";
            boolean visible = HelpersMethod.IsExists(ele, driver);
            if (visible == true)
            {
                LocalDate myDateObj = LocalDate.now().minusDays(1);
                DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
                formattedDate1 = myDateObj.format(myFormatObj);
                WebElement ele1 = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-calendar-view k-calendar-monthview')]/descendant::td[contains(@title,'" + formattedDate1 + "')]");
                HelpersMethod.JSScroll(driver,ele1);
                Thread.sleep(1000);
                HelpersMethod.ActClick(driver,ele1, 1);
                Thread.sleep(1000);
                scenario.log(formattedDate1 + " HAS BEEN SELECTED AS END DATE FOR OG");
            }
            else
            {
                scenario.log("CALENDER DROP DOWN DOESN'T EXISTS");
            }
        }
        catch (Exception e){}
    }

    //code for entereing Product# in Quick product input box, and sequence number
    public void EnterQuickProduct(String Product, String ProSeq)
    {
        try
        {
            WebElement WebEle=null;
            HelpersMethod.ScrollElement(driver,QuickProd);
            HelpersMethod.ClearText(driver,QuickProd,4);
            HelpersMethod.ActSendKey(driver, QuickProd,2,Product);
            HelpersMethod.ClearText(driver,Sequence,2);
            HelpersMethod.ActSendKey(driver, Sequence, 2,ProSeq);

            if(HelpersMethod.IsExists("//div[contains(text(),'no matching products')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[contains(text(),'Ok')]");
                HelpersMethod.ClickBut(driver,WebEle,2);
            }
            WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);
            scenario.log("PRODUCT# ENTERED IS "+Product+" SEQUENCE# ENTERED IS "+ProSeq);
        }
        catch (Exception e) {}
    }

    //Code to click on Save button
    public void ClickOnSave()
    {
        exists=false;
        try {
               WebElement WebEle=null;
            //Click on Save button
            HelpersMethod.ClickBut(driver,OGSave,2);
            WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);

            exists=HelpersMethod.IsExists("//div[contains(text(),'Order guides saved')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]", driver);
            if (exists==true)
            {
                WebElement PopupOk=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ActClick(driver,PopupOk,10);
                //to handle loading icon
                WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);
                scenario.log("OG HAS BEEN SAVED");
            }
            else
            {
                exists=HelpersMethod.IsExists("//div[contains(text(),'An order guide already exists with this code')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver);
                if(exists==true)
                {
                    scenario.log("OG CANN'T BE SAVED WITH GIVEN DESCRIPTION, START DATE AND END DATE");
                    WebElement PopupOk=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Cancel']");
                    HelpersMethod.ActClick(driver,PopupOk,6);
                    scenario.log("CANN'T CREATE MULTIPLE OG FOR SAME DATE");
                    Assert.assertEquals(exists, true);
                }
            }
        }
        catch (Exception e) {}
    }

    public boolean OGDetailValidate()
    {
        exists=false;
        try
        {
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[@id='card1']/descendant::span[contains(text(),'Detail order guide')]",5);
            if (HelpersMethod.IsExists("//div[@id='card1']/descendant::span[contains(text(),'Detail order guide')]", driver))
            {
                exists = true;
            }
        }
        catch (Exception e){}
        return exists;
    }

    //code to search product in OG
    public boolean SearchProd(String ProdNo) throws InterruptedException
    {
        exists = false;
        try
        {
            HelpersMethod.ScrollElement(driver,Searchbox);
            HelpersMethod.ActSendKey(driver, Searchbox,4,ProdNo);
            HelpersMethod.ActClick(driver,SearchIndex,1);
            scenario.log("PRODUCT# ENTERED FOR SEARCH IS "+ProdNo);

            if (HelpersMethod.IsExists("//button[@class='i-link-button ']/ancestor::tr[contains(@class,'k-master-row k-grid-edit-row')]",driver))
            {
                exists = true;
            }
        }
        catch (Exception e){}
        return exists;
    }

    //Code to click on Delete button
    public void DeleteProd()
    {
        try
        {
            WebElement Checkbox=HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row k-grid-edit-row')]/descendant::input[1]");
            WebElement Button_Ele=null;
            HelpersMethod.ClickBut(driver,Checkbox,2);
            if(DeleteProd.isEnabled())
            {
                HelpersMethod.ClickBut(driver,DeleteProd,2);
                Button_Ele=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'Order guides')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]");
                if(HelpersMethod.EleDisplay(Button_Ele))
                {
                    Button_Ele=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                    HelpersMethod.ClickBut(driver,Button_Ele,1);
                }
                scenario.log("PRODUCT HAS BEEN REMOVED FROM OG");
            }
            else
            {
                scenario.log("DELETE BUTTON IS NOT ENABLED,CHECK FOR THE REASON");
            }
        }
        catch (Exception e){}
    }

    //code to click on more button
    public boolean More_Button()
    {
        exists=false;
        try
        {
            if(HelpersMethod.EleDisplay(More))
            {
                exists=true;
                HelpersMethod.ScrollElement(driver,More);
                HelpersMethod.ClickBut(driver,More,2);
            }
            else
            {
                scenario.log("MORE BUTTON IS NOT DISPLAYED");
            }
        }
        catch (Exception e){}
        return exists;
    }

    //code to select Sequence clear option from drop down
    public boolean SequenceClear()
    {
        exists=false;
        try
        {
            HelpersMethod.Implicitwait(driver,10);
            WebElement SeqDrop=HelpersMethod.FindByElement(driver,"xpath","//ul[@class='k-list k-reset']/descendant::li[contains(text(),'Clear sequence')]");
            if(HelpersMethod.EleDisplay(SeqDrop))
            {
                HelpersMethod.Implicitwait(driver,2);
                exists=true;
                HelpersMethod.WebElementFromDropDown(driver,"//ul[@class='k-list k-reset']/descendant::li","xpath","Clear sequence");
                HelpersMethod.Implicitwait(driver,2);
                scenario.log("CLEAR SEQUENCE OPTION IS SELECTED FROM DROP DOWN");
            }
        }
        catch (Exception e){}
        return exists;
    }

    //Code to select No option in Clear popup
    public void SequencePopupNo()
    {
        try
        {
            HelpersMethod.Implicitwait(driver,8);
            if(HelpersMethod.IsExists("//div[text()='Clear']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='No']"),1);
                scenario.log("NO, OPTION IS SELECTED FROM POPUP");
            }
        }
        catch (Exception e){}
    }

    //Code to select Yes option in Clear popup
    public void SequencePopupYes()
    {
        try
        {
            HelpersMethod.Implicitwait(driver,8);
            if(HelpersMethod.IsExists("//div[text()='Clear']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']"),1);
                scenario.log("YES, OPTION IS SELECTED FROM POPUP");
            }
        }
        catch (Exception e){}
    }

    //Code to Edit sequence number in Product grid of OG
    public boolean EditSequence(String SeqNo)
    {
        exists=false;
        try
        {
            HelpersMethod.Implicitwait(driver,8);
            String Seqno=null;
            WebElement SeqInput= HelpersMethod.FindByElement(driver,"xpath","//tr[1]/descendant::span[contains(@class,'k-widget k-numerictextbox')]/descendant::input[@class='k-input k-formatted-value']");
            if(HelpersMethod.IsExists("//tr[1]/descendant::span[contains(@class,'k-widget k-numerictextbox')]/descendant::input[@class='k-input k-formatted-value']",driver))
            {
                exists=true;
            }
            Seqno=HelpersMethod.AttributeValue(SeqInput,"value");
            scenario.log("SEQUENCE NO. BEFORE EDITING "+Seqno);
            HelpersMethod.JSSetValueEle(driver,SeqInput,4,SeqNo);
            // Seqno=HelpersMethod.AttributeValue(SeqInput,"value");
            scenario.log("SEQUENCE NO. IS CHANGED TO "+SeqNo);
        }
        catch(Exception e){}
        return  exists;
    }

    //Code for Clicking Add product button in new OG page
    public void ClickOnAddProduct()
    {
        try
        {
            HelpersMethod.ScrollElement(driver,AddProd);
            HelpersMethod.ActClick(driver,AddProd,10);
        }
        catch (Exception e){}
    }

    //Code for Selecting value from drop down that appears after clicking Add product button
    public void SelectValueFromAddProduct(String AddFrom)
    {
        try
        {
            exists=false;
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//ul[contains(@class,'k-list k-reset')]",4);
            if(HelpersMethod.IsExists("//ul[contains(@class,'k-list k-reset')]",driver))
            {
                HelpersMethod.WebElementFromDropDown(driver,"//ul[contains(@class,'k-list k-reset')]/descendant::li","xpath",AddFrom);
                WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                if(WebEle.isDisplayed())
                {
                    HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);
                    exists=true;
                }
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    //Code for selecting OG from Order guide popup
    public void OrderGuidePopup()
    {
        try
        {
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[contains(text(),'Select order guides')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",10);
            if(HelpersMethod.IsExists("//div[contains(text(),'Select order guides')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                WebElement OrderSel=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[contains(@class,'k-master-row')][1]/descendant::input[@class='k-checkbox']");
                HelpersMethod.ActClick(driver,OrderSel,1);
                OrderSel=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ClickBut(driver,OrderSel,2);
                WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);
            }
            else
            {
                scenario.log("ORDER GUIDE HAS NOT BEEN CREATED");
            }
        }
        catch (Exception e){}
    }

    //Code for handling "Catalog" popup and adding products to OG using catalog
    public void CatalogPopup()
    {
        try
        {
            WebElement Prod=null;
            WebElement OkBut=null;
            if(HelpersMethod.IsExists("//div[contains(@class,'k-widget k-window k-dialog')]/descendant::div[@class='i-grid']",driver))
            {
                Prod=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[contains(@class,'k-master-row')][1]");
                OkBut=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
               HelpersMethod.ScrollElement(driver,Prod);
               HelpersMethod.ActClick(driver,Prod,2);
               HelpersMethod.ScrollElement(driver,OkBut);
                HelpersMethod.ActClick(driver,OkBut,2);
            }
            else if(HelpersMethod.IsExists("//div[contains(@class,'k-widget k-window k-dialog')]/descendant::div[@class='card-view']",driver))
            {
                Prod=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Select'][1]");
                OkBut=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ScrollElement(driver,Prod);
                HelpersMethod.ActClick(driver,Prod,2);
                HelpersMethod.ScrollElement(driver,OkBut);
                HelpersMethod.ActClick(driver,OkBut,2);
            }
            else
            {
                scenario.log("CATALOG POPUP DOESNOT EXISTS");
            }
        }
        catch (Exception e){}
    }

    //Code for handling Order popup
    public void OrderPopup()
    {
        try
        {
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[contains(text(),'Select orders')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",10);
            if(HelpersMethod.IsExists("//div[contains(text(),'Select orders')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                WebElement OrderSel=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[contains(@class,'list-group-item')][1]");
                HelpersMethod.ScrollElement(driver,OrderSel);
                HelpersMethod.ActClick(driver,OrderSel,2);
                OrderSel=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ScrollElement(driver,OrderSel);
                HelpersMethod.ClickBut(driver,OrderSel,2);
            }
            else
            {
                scenario.log("NO ORDER HAS BEEN SELECTED YET");
            }
        }
        catch (Exception e){}
    }

    //Code for Delete OG
    public void Click_Delete()
    {
        try
        {
            HelpersMethod.Implicitwait(driver,10);
            HelpersMethod.ScrollElement(driver,OG_Delete);
            HelpersMethod.ActClick(driver,OG_Delete,6);
        }
        catch (Exception e){}
    }
    //Code for handling Delete popup
    public void DeleteOk_Popup()
    {
        try
        {
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[contains(text(),'delete this order guide ?')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",6);
            if(HelpersMethod.IsExists("//div[contains(text(),'delete this order guide ?')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                WebElement DeleteOk=HelpersMethod.FindByElement(driver,"xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ClickBut(driver,DeleteOk,2);
                HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[contains(text(),'Order guides deleted')]/ancestor::div[@class='k-widget k-window k-dialog']",2);
                if(HelpersMethod.IsExists("//div[contains(text(),'Order guides deleted')]/ancestor::div[@class='k-widget k-window k-dialog']",driver))
                {
                    DeleteOk=HelpersMethod.FindByElement(driver,"xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                    HelpersMethod.ClickBut(driver,DeleteOk,2);
                }
            }
        }
        catch (Exception e){}
    }

    //Code for cancel the delete
    public void DeleteCancel_Popup()
    {
        try
        {
            if(HelpersMethod.IsExists("//div[contains(text(),'delete this order guide ?')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                WebElement DeleteCancel=HelpersMethod.FindByElement(driver,"xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Cancel']");
                HelpersMethod.ClickBut(driver,DeleteCancel,2);
            }
        }
        catch (Exception e){}
    }

    //Code for clicking Import button
    public void ImportClick()
    {
        try
        {
            exists=false;
            HelpersMethod.ClickBut(driver,OGImport,2);
            exists=HelpersMethod.IsExists("//div[contains(text(),'Order guides')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver);
            if(exists==true)
            {
                WebElement Popup=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ActClick(driver,Popup,2);
            }
        }
        catch (Exception e){}
    }

    //Handling File open popup to select file from popup
    public void FileOpen()
    {
        try
        {
            //Copying the file name to input box of file upload popup
            Thread.sleep(5000);
            StringSelection stringselection=new StringSelection("C:\\Users\\Divya.Ramadas\\Downloads\\OrderGuide_NEW.csv");
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringselection,null);

            //calling robot class and method for uploading file
            HelpersMethod.FileUploadRobot();

        }
        catch (Exception e){}
    }

    public void Click_On_Type()
    {
        try
        {
            HelpersMethod.ActClick(driver,Type,4);
        }
        catch (Exception e){}
    }

    public void SelectTypeFromDropDown(String type)
    {
        try
        {
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[contains(@class,'k-popup k-child-animation-container')]",4);
            if(HelpersMethod.IsExists("//div[contains(@class,'k-popup k-child-animation-container')]",driver))
            {
                HelpersMethod.WebElementFromDropDown(driver,"//div[contains(@class,'k-popup k-child-animation-container')]/descendant::ul/li","xpath",type);
            }
        }
        catch (Exception e){}
    }

    public void ClickOnDayOfWeek()
    {
        try
        {
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//label[contains(text(),'Day of week')]/following-sibling::span[contains(@class,'k-widget k-dropdown')]/span",4);
            if (HelpersMethod.IsExists("//label[contains(text(),'Day of week')]/following-sibling::span[contains(@class,'k-widget k-dropdown')]/span",driver))
            {
                HelpersMethod.ActClick(driver,DayOfWeek,2);
            }
            else
            {scenario.log("DAY OF WEEK DROP DOWN IS NOT VISIBLE");}
        }
        catch(Exception e){}
    }

    public String SelectDayOfWeek()
    {
        try
        {
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[contains(@class,'k-popup k-child-animation-container ')]/descendant::li",8);
            List<WebElement> WeekDays=HelpersMethod.FindByElements(driver,"xpath","//div[contains(@class,'k-popup k-child-animation-container ')]/descendant::li");
            if(HelpersMethod.IsExists("//div[contains(@class,'k-popup k-child-animation-container ')]",driver))
            {
                HelpersMethod.WebElementFromDropDown(driver,"//div[contains(@class,'k-popup k-child-animation-container ')]/descendant::li","xpath",DOfWeek);
            }
        }
        catch (Exception e){}
        return DOfWeek;
    }

    public String ValidateWeekOfDay()
    {
        String DayWeek=null;
        try
        {
            HelpersMethod.WaitElementPresent(driver,"xpath","//label[contains(text(),'Day of week')]",10);
            WebElement DWeek=HelpersMethod.FindByElement(driver,"xpath","//label[contains(text(),'Day of week')]/following-sibling::span/descendant::span[@class='k-input']");
            DayWeek=DWeek.getText();
        }
        catch (Exception e){}
      return DayWeek;
    }

    //Code to navigate Customer allocation menu
    public void CustomerAllocation()
    {
        try
        {
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//span[contains(text(),'Customer allocation')]",8);
            WebElement AlloCust=HelpersMethod.FindByElement(driver,"xpath","//span[contains(text(),'Customer allocation')]");
            HelpersMethod.ActClick(driver,AlloCust,2);
        }
        catch (Exception e){}
    }

    //Code to validate Customer Allocation grid
    public boolean ValidateCustomerAllocation()
    {
        exists=false;
        try
        {
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[@class='additional-accounts-grid']",6);
            exists=HelpersMethod.IsExists("//div[@class='additional-accounts-grid']",driver);
        }
        catch (Exception e){}
        return exists;
    }

    //Code to click on checkBox under customer allocation tab
    public void CheckBoxCustAllocation()
    {
        try
        {
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//tr[contains(@class,'k-master-row')]/descendant::input",8);
            WebElement CheckBox=HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row')]/descendant::input");
            HelpersMethod.ClickBut(driver,CheckBox,2);
        }
        catch (Exception e){}
    }

    //Code to click on Delete button to remove customer allocation
    public void ClickOnDelete()
    {
        try
        {
           HelpersMethod.Implicitwait(driver,8);
           WebElement DelCust=HelpersMethod.FindByElement(driver,"xpath","//button[@id='buttonDelete']");
           HelpersMethod.ActClick(driver,DelCust,2);
        }
        catch (Exception e){}
    }

    //Code to validate customer allowcation has been removed from the grid
    public boolean ValidateDelete()
    {
        exists=false;
        try
        {
            HelpersMethod.Implicitwait(driver,8);
            exists=HelpersMethod.IsExists("//table[@class='k-grid-table']/descendant::div[@class='i-no-data']",driver);
        }
        catch(Exception e){}
        return exists;
    }

    //Code to click on '+' button
    public void ClickPlus()
    {
        try
        {
            HelpersMethod.Implicitwait(driver,10);



            WebElement PlusAdd=HelpersMethod.FindByElement(driver,"xpath","//*[local-name()='svg']//*[local-name()='path' and contains(@d,'M19')]");
            HelpersMethod.ActClick(driver,PlusAdd,8);
            HelpersMethod.Implicitwait(driver,10);
        }
        catch (Exception e){}
    }

    public void DropDownAcc(String CustAlloc)
    {
        try
        {
            HelpersMethod.WebElementFromDropDown(driver,"//div[contains(@class,'k-animation-container-shown')]/descendant::ul/li","xpath",CustAlloc);
        }
        catch (Exception e){}
    }


    //Code to handle popup that appears after Plus button, Enter Account# in search box and select the account#
    public boolean PopupHandle()
    {
        exists=false;
        try
        {
            HelpersMethod.Implicitwait(driver,15);
            exists=HelpersMethod.IsExists("//div[contains(text(),'Select customer')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver);
            if(exists==true)
            {
                //Code to enter Customer allocation, and click on Index
                WebElement SearchBox=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::input[@id='SearchBox1']");
                HelpersMethod.EnterText(driver,SearchBox,2,TestBase.testEnvironment.get_Account());
                SearchBox=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]//*[local-name()='svg' and contains(@class,'i-search-box__search')]");
                HelpersMethod.ActClick(driver,SearchBox,2);
            }
        }
        catch (Exception e){}
        return exists;
    }

    //Code to select Customer Account
    public void CustomerAccountSelect()
    {
        try
        {
            WebElement SearchBox=null;
            //Code to select customer allocation from popup
            SearchBox=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[contains(@class,'k-master-row')]/descendant::input[@class='k-checkbox']");
            HelpersMethod.ActClick(driver,SearchBox,4);
            SearchBox=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
            HelpersMethod.ActClick(driver,SearchBox,4);
        }
        catch (Exception e){}
    }

    //Code to verify whether account has been selected or not
    public boolean ValidateCustSelect()
    {
        exists=false;
        try
        {
             exists=HelpersMethod.IsExists("//table[@class='k-grid-table']/descendant::tr[@class='k-master-row']",driver);
        }
        catch (Exception e){}
        return  exists;
    }

    //Code to validate catalog display
    public boolean ValidateCatalogDisplay()
    {
        try
        {
            exists=false;
            if(HelpersMethod.IsExists("//div[text()='Catalog']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                exists=true;
            }
        }
        catch (Exception e){}
        return exists;
    }

    //Code to add multiple products to OG through Catalog
    public void AddFromCatalog(List<String> Prods)
    {
        try
        {
            if(HelpersMethod.IsExists("//div[contains(@class,'card-view')]",driver))
            {
                WebElement SearchBar = null;
                WebElement SearchIndex = null;
                WebElement SelectBut = null;
                //Code to handle if catalog is displaying in card view
                for (int i = 0; i < Prods.size() - 1; i++) {
                    SearchBar = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::input[contains(@placeholder,'Search products')]");
                    SearchIndex = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]//*[local-name()='svg']//*[local-name()='path' and contains(@d,'M15.5')]");
                    HelpersMethod.ClearText(driver,SearchBar,4);
                    HelpersMethod.EnterText(driver,SearchBar,2,Prods.get(i));
                    HelpersMethod.ActClick(driver,SearchIndex,1);
                    HelpersMethod.Implicitwait(driver, 5);
                    if (HelpersMethod.IsExists("//div[@id='no-products-found']", driver)) {
                        scenario.log("SORRY PRODUCT WITH # " + Prods.get(i) + " DOESN'T EXISTS");
                        WebElement Close_But = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]//*[local-name()='svg']//*[local-name()='path' and contains(@d,'M17')]");
                        HelpersMethod.ActClick(driver,Close_But,2);
                    } else {
                        HelpersMethod.Implicitwait(driver, 8);

                        scenario.log("PRODUCT # " + Prods.get(i) + " HAS BEEN ADDED TO OG");
                        HelpersMethod.ActScroll(driver, HelpersMethod.FindByElement(driver, "xpath", "//button[text()='Select']"),2);
                        SelectBut = HelpersMethod.FindByElement(driver, "xpath", "//button[text()='Select']");
                        HelpersMethod.ActClick(driver,SelectBut, 2);
                    }
                }
                WebElement OK_But = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ActClick(driver,OK_But,1);
            }
            else
            {
                WebElement Input_Box=null;
                WebElement Filter_But=null;
                WebElement Filter_Remove=null;
                WebElement Product_Row=null;
                List<WebElement> Heads=HelpersMethod.FindByElements(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr/th/span[@class='k-link']");
                int i=0;
                for (WebElement Head:Heads)
                {
                    i++;
                    String Head_Text=Head.getText();
                    if(Head_Text.equals("Product #"))
                    {
                        Input_Box=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[contains(@class,'k-filter-row')]/th["+i+"]/descendant::input");
                        Filter_But=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[contains(@class,'k-filter-row')]/th["+i+"]/descendant::div[@class='k-filtercell-operator']/span");
                        for (int j = 0; j < Prods.size() - 1; j++)
                       {
                           HelpersMethod.EnterText(driver,Input_Box,4,Prods.get(j));
                           //Select the product row
                           Product_Row=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[contains(@class,'k-master-row')]");
                           HelpersMethod.ActClick(driver,Product_Row,2);
                           //Code to clear the filter
                           Filter_Remove=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[contains(@class,'k-filter-row')]/th[3]/descendant::div[@class='k-filtercell-operator']/descendant::button[contains(@class,'k-clear-button-visible')]");
                           HelpersMethod.ActClick(driver,Filter_Remove,2);

                           HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']",8);
                       }
                        break;
                    }
                }


                WebElement OK_But = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ActClick(driver,OK_But, 2);
            }
        }
        catch (Exception e){}
    }
}