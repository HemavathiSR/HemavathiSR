package pages_DSD_OMS.orderGuide;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import util.Environment;
import util.TestBase;

import java.awt.*;
import java.util.List;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class OrderGuidePage
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    static Environment testEnvironment;
    static boolean result=false;
    Scenario scenario;

    static boolean exists=false;

    @FindBy(id="dropDownNoneType")
    private WebElement CustRef;

    @FindBy(id="plusAdditionalAccountButtonFlat")
    private WebElement CreateOG;

    @FindBy(xpath="//label[@id='textBoxE-label']/ancestor::div[@class='flex-container']/descendant::button")
    private WebElement CustAccNoButton;

    @FindBy(id="SearchBox1")
    private WebElement SearchBox;

    @FindBy(xpath = "//div[@class='i-search-box']//*[local-name()='svg']/*[local-name()='path' and contains(@d,'M15.5')]")
    private WebElement SearchIndex;

    @FindBy(xpath="//div[@class='i-filter-tag i-filter-tag--add']/descendant::button[@class='i-filter-tag__main']")
    private WebElement AddFilter;

    @FindBy(xpath="//label[contains(text(),'Customer account #')]/ancestor::div[@class='flex-container']/descendant::button")
    private WebElement CustomerAccIndex;

    public OrderGuidePage(WebDriver driver, Scenario scenario) throws InterruptedException, AWTException
    {
        this.scenario=scenario;
        this.driver =driver;
        PageFactory.initElements(driver,this);
    }

    public void Refresh_Page()
    {
        driver.navigate().refresh();
        WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
        HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);
    }

    public boolean ValidateOG()
    {
        exists=false;
        try
        {
            String title=HelpersMethod.gettingTitle(driver);
            if(title.equals("Ignition - Web Order Guides"))
            {
                exists=true;
            }
        }
        catch (Exception e){}
        return exists;
    }

    public void CrateOG()
    {
        try
        {
            HelpersMethod.ScrollElement(driver,CreateOG);
            HelpersMethod.JScriptClick(driver,CreateOG,4);
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);
        }
        catch (Exception e){}
    }

    //code for searching OG using Searchbox
    public boolean OGSearchBox(String OGSearch)
    {
        exists=false;
        try
        {
            HelpersMethod.ScrollElement(driver,SearchIndex);
            HelpersMethod.ActSendKey(driver,SearchBox,5,OGSearch);
            HelpersMethod.ActClick(driver,SearchIndex,2);

            if(HelpersMethod.IsExists("//tr[@class='k-master-row']",driver))
            {
                exists=true;
                scenario.log("ORDER GUIDE ENTERED IN SEARCH BOX IS " + OGSearch);
            }
           else
           if(HelpersMethod.IsExists("//tr[@class='k-grid-norecords']",driver))
            {
                exists=false;
                scenario.log("ORDER GUIDE DOESNOT EXISTS");
            }
        }
        catch (Exception e){}
        return  exists;
    }

    //Click on OG in OG grid, once searching is sucessfull
    public void SearchOGSelect()
    {
        try
        {
            if(HelpersMethod.IsExists("//tr[@class='k-master-row']",driver))
            {
                exists=true;
                WebElement OGNo=HelpersMethod.FindByElement(driver,"xpath","//tr[@class='k-master-row']/descendant::td/button");
                HelpersMethod.ActClick(driver,OGNo, 2);
            }
            else
            {
                scenario.log("ORDER GUIDE DOESNOT EXISTS");
            }
        }
        catch (Exception e){}
    }

    //Code to click on Addfilter
    public boolean AddFilterClick(String search1,String search2)
    {
        exists=false;
        try
        {
            if(AddFilter.isDisplayed())
            {
                exists=true;
                HelpersMethod.AddFilterSearch(driver,search1,search2);
                if(!HelpersMethod.IsExists("//div[contains(@class,'i-no-data__message')]",driver))
                {
                    List<WebElement> OGLists = HelpersMethod.FindByElements(driver, "xpath", "//tr[contains(@class,'k-master-row')]/descendant::button");
                    for (int i = 0; i <= 5; i++)
                    {
                        for (WebElement OGList : OGLists)
                        {
                            String OG_Text = OGList.getText();
                            scenario.log("Filtered value from Add filter " + OG_Text);
                        }
                    }
                }
                else
                {
                    scenario.log("RELAVENT FILTER VALUES DOESN'T EXISTS");
                }
            }
        }
        catch (Exception e){}
        return exists;
    }

    //Code to click on Customer reference
    public void CustomerRef()
    {
        try
        {
            HelpersMethod.ActClick(driver,CustRef,5);
        }
        catch (Exception e){}
    }

    //Code to select different type of OG from drop down
    public void CustRefDropDown(String OGtype)
    {
        List<WebElement> CustRefTypes=null;
        Actions act1=new Actions(driver);
        try
        {
            if(HelpersMethod.IsExists("//div[contains(@class,'k-popup k-child-animation-container ')]",driver))
            {
                CustRefTypes=HelpersMethod.FindByElements(driver,"xpath","//div[contains(@class,'k-popup k-child-animation-container ')]/descendant::ul/li");
                for(WebElement CustRefType:CustRefTypes)
                {
                    act1.moveToElement(CustRefType).build().perform();
                    String CustRef_Text=CustRefType.getText();
                    if(CustRef_Text.equals(OGtype))
                    {
                        act1.click(CustRefType).build().perform();
                        WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                        HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);
                        break;
                    }
                }
            }
        }
        catch (Exception e){}
    }

    //Code to check for popup and to select sub category in Customer reference
    public void SubCustomerRef()
    {
        try
        {
            HelpersMethod.WaitElementPresent(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]",10);
            if(HelpersMethod.IsExists("//div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                WebElement SubRef=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[contains(@class,'k-master-row')][1]");
                HelpersMethod.ActClick(driver,SubRef,2);
                WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                if(WebEle.isDisplayed())
                {
                    HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);
                }
            }
        }
        catch (Exception e){}
    }

    //Code to click on customer account# index icon
    public void CustomerAcc()
    {
        try
        {
            HelpersMethod.ClickBut(driver,CustomerAccIndex,2);
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            if(WebEle.isDisplayed())
            {
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);
            }
        }
        catch (Exception e){}
    }

    //Code for handling customer account# popup
    public void AccountPopup()
    {
        try
        {
            if(HelpersMethod.IsExists("//div[contains(text(),'Select customer')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                if(HelpersMethod.IsExists("//div[contains(@class,'k-widget k-window k-dialog')]/descendant::input[@id='SearchBox1']",driver))
                {
                    WebElement SearchBox=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::input[@id='SearchBox1']");
                    HelpersMethod.EnterText(driver,SearchBox,2,TestBase.testEnvironment.get_AnotherAcc());
                    scenario.log("ANOTHER ACCOUNT SELECTED FOR CREATING OG IS "+TestBase.testEnvironment.get_AnotherAcc());
                    //code to check for existence of Account#
                    WebElement SearchIndex=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')] //*[local-name()='svg' and contains(@class,'i-icon   i-search-box__search')]");
                    HelpersMethod.ClickBut(driver,SearchIndex,2);
                    //code to select Account#
                    WebElement SelectAcc=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')] /descendant::tr[@class='k-master-row']");
                    HelpersMethod.ActClick(driver,SelectAcc,2);
                    WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                    if(WebEle.isDisplayed())
                    {
                        HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);
                    }
                }
                else
                {
                    scenario.log("SEARCH BOX IN CUSTOMER ACCOUNT# POPUP, DOESN'T EXISTS");
                }
            }
        }
        catch (Exception e){}
    }

    //Code to select first order guide from OG grid
    public String SelectOG()
    {
        String OGDis=null;
        try
        {
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            if(WebEle.isDisplayed())
            {
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);
            }
            WebElement DisOG=HelpersMethod.FindByElement(driver,"xpath","//tr[@class='k-master-row'][1]/descendant::button");
            OGDis=DisOG.getText();
            HelpersMethod.ClickBut(driver,DisOG,2);
            WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            if(WebEle.isDisplayed())
            {
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 10);
            }
        }
        catch (Exception e){}
        return OGDis;
    }
}
