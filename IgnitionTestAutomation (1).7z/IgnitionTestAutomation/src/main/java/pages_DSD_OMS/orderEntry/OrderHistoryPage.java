package pages_DSD_OMS.orderEntry;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.awt.*;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class OrderHistoryPage
{
    /* Created by Divya */
    WebDriver driver;
    Scenario scenario;
    static boolean exists=false;

    @FindBy(id="customerAccountIndexSearchBar")
    private WebElement SearchBox;

    @FindBy(xpath="//*[local-name()='svg' and contains(@class,'i-search-box__search')]")
    private WebElement SearchIndex;

    @FindBy(xpath="//button[text()='Copy']")
    private WebElement CopyButton;

    @FindBy(xpath="//button[text()='Print']")
    private WebElement PrintButton;

    @FindBy(xpath="//button[@class='i-filter-tag__main']")
    private WebElement Addfilter;

    @FindBy(id="order-history-card")
    private WebElement HistoryGrid;

    public OrderHistoryPage(WebDriver driver, Scenario scenario) throws InterruptedException, AWTException
    {
        this.scenario=scenario;
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    public void SearchBox_Entry(String Ord_No) throws InterruptedException
    {
        try
        {
           // HelpersMethod.Implicitwait(driver, 15);
            HelpersMethod.EnterText(driver,SearchBox, 10,Ord_No);
           // Thread.sleep(500);
            HelpersMethod.ClickBut(driver,SearchIndex,2);
        }
        catch (Exception e){}
    }
    public void Check_Box()
    {
        try
        {
            //HelpersMethod.Implicitwait(driver, 15);
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//tr[contains(@class,'k-master-row')][1]/descendant::input[contains(@class,'k-checkbox')]",10);
            HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row')][1]/descendant::input[contains(@class,'k-checkbox')]"),1);
        }
        catch (Exception e){}
    }
    public void Copy_Button()
    {
        try
        {
            HelpersMethod.ClickBut(driver,CopyButton,1);
        }
        catch (Exception e){}
    }

    public void Click_OrderNo()
    {
        try
        {
            ////HelpersMethod.Implicitwait(driver, 20);
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//tr[contains(@class,'k-master-row')][1]/descendant::div[contains(@id,'OrderNumberCol')]",18);
            HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row')][1]/descendant::div[contains(@id,'OrderNumberCol')]"),1);
        }
        catch (Exception e){}
    }

    public boolean VerifiyHistoryGrid()
    {
        exists=false;
        try
        {
            HelpersMethod.Implicitwait(driver,20);
            if(HelpersMethod.EleDisplay(HistoryGrid))
            {
                exists=true;
            }
        }
        catch (Exception e){}
        return exists;
    }
}
