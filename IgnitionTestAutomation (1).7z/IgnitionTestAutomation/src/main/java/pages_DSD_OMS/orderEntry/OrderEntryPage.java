package pages_DSD_OMS.orderEntry;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import io.cucumber.java8.He;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import pages_DSD_OMS.login.HomePage;
import util.Environment;
import util.TestBase;

import java.awt.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class OrderEntryPage
{
     /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    static Environment testEnvironment;
    static boolean result=false;
    Scenario scenario;

    @FindBy(id="customerAccountNumberComboBox")
    private WebElement AccNo;

    @FindBy(id = "addButton")
    private WebElement StartOrder;

    @FindBy(xpath="//button[contains(@class,'k-button k-primary') and @aria-label=' dropdownbutton']")
    private WebElement StartOrderDropButton;

    @FindBy(xpath="//button[text()='Skip']")
    private WebElement Skip;

    @FindBy(id="customerAccountIndexSearchBar")
    private WebElement SearchOrder;

    @FindBy(xpath = "//div[contains(@class,'i-search-box')]//*[local-name()='svg' and contains(@class,'i-search-box__search')]")
    private WebElement SearchIndex;

    @FindBy(xpath="//span[@class='k-widget k-datepicker']/descendant::a/span")
    private WebElement Calender;

    @FindBy (xpath="//button[text()='History']")
    private WebElement HistoryButton;

    @FindBy (xpath = "//button[contains(@class,'k-button k-primary k-button-icontext')]/descendant::span[contains(@class,'i-arrow')]")
    private WebElement DropDown;

    @FindBy(xpath="//button[text()='Remove Skip']")
    private WebElement RemoveSkip;

    @FindBy(xpath="//button[@id='customernotes']")
    private WebElement CustomerNote;

    @FindBy(id="noteTextbox")
    private WebElement NoteArea;

    @FindBy(id="SaveButton")
    private WebElement Save_But;

    @FindBy(xpath = "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']")
    private WebElement Ok_But;

    @FindBy(xpath="//div[contains(@class,'CPDeliveryDates')]/descendant::input")
    private WebElement DelivDate;

    @FindBy(xpath = "//label[@id='RouteIndex-label']/parent::div/descendant::button")
            private WebElement RouteOE;

    String XPath=null;
    boolean exists=false;
    String Id=null;
    static String formattedDate=null;


    public OrderEntryPage(WebDriver driver, Scenario scenario) throws InterruptedException, AWTException
    {
        this.scenario=scenario;
        this.driver =driver;
        PageFactory.initElements(driver,this);
    }

    public void HandleError_Page()
    {
        try
        {
           String URL=HelpersMethod.gettingURL(driver);
           if(URL.contains("cpError"))
           {
                HelpersMethod.NavigateBack(driver);
                URL=HelpersMethod.gettingURL(driver);
           }
            if (HelpersMethod.gettingURL(driver).contains("CPAdmin"))
            {
                HomePage homepage=new HomePage(driver,scenario);
                homepage.navigateToClientSide();
                NavigateToOrderEntry();
                ChangeAccount();
                PopUps_After_AccountChange();
            }
        }
        catch (Exception e){}
    }

    public void NavigateToOrderEntry()
    {
        try
        {
            Actions act = new Actions(driver);
            WebElement Search_Input=HelpersMethod.FindByElement(driver,"xpath","//div[@class='drawer-menu-search-container']/descendant::input");
            act.moveToElement(Search_Input).sendKeys("Order Entry").build().perform();
            WebElement OEMenu=HelpersMethod.FindByElement(driver,"xpath","//ul[contains(@class,'MuiList-root ')]/descendant::span[contains(text(),'Order Entry')]");
            HelpersMethod.ClickBut(driver,OEMenu,1);
            //Thread.sleep(5000);
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,50);
        }
        catch (Exception e) {}
    }

    public void ChangeAccount()
    {
        try
        {
            Actions act=new Actions(driver);
               //////////// HelpersMethod.Implicitwait(driver, 40);
                act.moveToElement(driver.findElement(By.id("customerAccountNumberComboBox"))).sendKeys(TestBase.testEnvironment.get_Account()).build().perform();
               ////////// //Thread.sleep(2000);
                Thread.sleep(500);
                WebElement AccDrop= HelpersMethod.FindByElement(driver,"xpath","//li[contains(@id,'option-')]");
                HelpersMethod.WebElementFromDropDown(driver,"//div[contains(@class,'k-list-container ')]/descendant::li","xpath",AccDrop.getText());
             /////////////HelpersMethod.Implicitwait(driver,25);
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,50);
        }
        catch (Exception e) {}
    }

    public void PopUps_After_AccountChange()
    {
        try
        {
            //Check for 'Upcoming blackout dates'
            XPath="//p[contains(text(),'Upcoming blackout dates')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists=HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                driver.findElement(By.xpath("//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']")).click();
            }

            //check for note popup
            XPath="//p[contains(text(),'Notes')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists= HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver,"xpath","//p[contains(text(),'Notes')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']"),1);
            }
        }
        catch (Exception e){ }
    }

    public boolean Verify_OE_Title()
    {
        try
        {
            exists=false;
            HelpersMethod.waitTillTitleContains(driver,"Ignition - Order Entry",10);
            String title=driver.getTitle();
            if(title.equals("Ignition - Order Entry"))
            {
                exists=true;
            }
        }
        catch (Exception e) {}
        return exists;
    }
    public void Verify_OEPage()
    {
        try
        {
            XPath="//div[@id='order-search-card']";
            exists= HelpersMethod.IsExists(XPath,driver);
            if(true==exists)
            {
                Assert.assertEquals(true,exists);
            }
        }
        catch (Exception e) {}
    }
    public void Refresh_Page()
    {
        driver.navigate().refresh();
        WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
        HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,50);
    }

    //change the Customer Account#
    public void Change_NewAccount(String Acc)
    {
        try
        {
                HelpersMethod.Implicitwait(driver,15);
                AccNo.clear();
                AccNo.sendKeys(Acc);
                WebElement AccDrop= HelpersMethod.FindByElement(driver,"xpath","//li[contains(@id,'option-')]");
                HelpersMethod. WebElementFromDropDown(driver,"//div[contains(@class,'k-list-container ')]/descendant::li","//div[contains(@class,'k-list-container ')]/descendant::li[contains(text(),'"+AccDrop.getText()+"')]",AccDrop.getText());
        }
        catch (Exception e) {}
    }

    //Preceding by zero, This feature is only for DSD
    public boolean Account_Zero()
    {
        try
        {
            result=false;
            String Acc1=AccNo.getAttribute("value");
            //Code to read account# from properties file and remove preceding zeros
            String Acc_Sub[]=Acc1.split("-");
            int i=0;
            for(String Accs:Acc_Sub)
            {
                int length=Accs.length();
                if(Accs.length()!=1 )
                {
                    if(Accs.charAt(0)!=0)
                    {
                        result=true;
                    }
                }
            }
        }
        catch (Exception e){}
        return result;
    }

    //Account number selection from the customer account#
    public void Select_Account(String Account_No)
    {
        HelpersMethod.Implicitwait(driver,4);
        exists=false;
        try
        {
            WebElement WebEle =null;
            HelpersMethod.Implicitwait(driver,2);

            XPath="//div[contains(text(),'Customer account index')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists=HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//button[contains(@class,'i-filter-tag__main')]");
                if(HelpersMethod.EleDisplay(WebEle))
                {
                    HelpersMethod.AddFilterSearch(driver, "Customer #", Account_No);
                }
                WebElement AccNo=HelpersMethod.FindByElement(driver,"xpath","//tr[@class='k-master-row']");
                HelpersMethod.JSScroll(driver,AccNo);
                HelpersMethod.ActClick(driver, AccNo,5);
                WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,10);
            }
        }
        catch (Exception e){}
    }

    public void Scroll_start() throws InterruptedException
    {
        try
        {
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"id","order-search-card",20);
            HelpersMethod.ScrollElement(driver, driver.findElement(By.id("order-search-card")));
            HelpersMethod.waitClickableOfEle(driver, StartOrder, 40);
        }
        catch (Exception e){}
    }

    public void NoPendingOrderPopup()
    {
        try
        {
            XPath="//div[contains(text(),'You already have an open order that is pending submission.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists= HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                WebElement ele=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[contains(text(),'Start new order')]");
                HelpersMethod.ClickBut(driver,ele,5);
            }
        }
        catch (Exception e) {}
    }

    public void ContinuePendingOrderFromPopup()
    {
        try
        {
            HelpersMethod.Implicitwait(driver,10);
            XPath="//div[contains(text(),'You already have an open order that is pending submission.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists= HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                WebElement ele=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[contains(text(),'Continue pending order')]");
                HelpersMethod.JScriptClick(driver,ele,4);
            }
        }
        catch (Exception e) {}
    }

    public void NO_NotePopup()
    {
        try {
            HelpersMethod.Implicitwait(driver, 10);
            XPath = "//div/p[contains(text(),'Notes')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists = HelpersMethod.IsExists(XPath, driver);
            //Check for Note popup
            if (exists == true)
            {
                HelpersMethod.ClickBut(driver, HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']"),1);
            }
        }
        catch (Exception e){}
    }

    public void OrderGuidePopup()
    {
        try {
            XPath="//div[contains(text(),'Order guides')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists= HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                WebElement Orderguide= HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ClickBut(driver,Orderguide,1);
                WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 20);
            }
        }
        catch (Exception e) {}
    }

    //public void NoNotePopHandling(String note)
    public void NoNotePopHandling()
    {
        try
        {
            HelpersMethod.Implicitwait(driver,10);
            XPath="//div/p[contains(text(),'Notes')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists= HelpersMethod.IsExists(XPath,driver);
            //Check for Note popup
            if(exists==true)
            {
                //Click on OK button in Note Popup
                WebElement Note=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ClickBut(driver,Note,1);
            }
        }
        catch (Exception e) {}
    }

    public void ClickCalender()
    {
        try
        {
            Thread.sleep(10000);
            HelpersMethod.ActClick(driver,Calender,4);
            Thread.sleep(2000);
        }
        catch (Exception e) {}
    }

    public String Read_DeliveryDate()
    {
        try
        {
            if (formattedDate==null)
            {
                Thread.sleep(1000);
                formattedDate = driver.findElement(By.xpath("//input[contains(@id,'delivery-date-web-order-header-calendar')]")).getAttribute("value");
            }
        }
        catch (Exception e){}
        return formattedDate;
    }

    public void ResetToCurrentDate()
    {
        try
        {
            WebElement CDate=null;
             Thread.sleep(2000);
             HelpersMethod.Implicitwait(driver,4);
            //Find the current date and change it's formate
            String Current_Date=Read_DeliveryDate();
            SimpleDateFormat fromUser1 = new SimpleDateFormat("EEE, MMM d, yyyy");
            SimpleDateFormat fromUser = new SimpleDateFormat("EEEE, MMMM d, yyyy");
            String C_Date1 = fromUser.format(fromUser1.parse(Current_Date));
            //click on date
            CDate=HelpersMethod.FindByElement(driver,"xpath","//span[contains(@title,'"+C_Date1+"')]");
            HelpersMethod.ClickBut(driver, CDate,1);

            for(int i=0;i<=1;i++)
            {
                //Handling Change delivery date Popup
                XPath = "//div[contains(text(),'Change delivery date')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    CDate=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Change delivery date']");
                    HelpersMethod.ClickBut(driver,CDate,1);
                }
                //Handling Warning Popup
                XPath = "//div[contains(text(),'Warning')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    CDate=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                    HelpersMethod.ClickBut(driver,CDate,1);
                }
            }
            Thread.sleep(5000);
            //NOte popup
            NoNotePopHandling();
            //OG popup
            OrderGuidePopup();
        }
        catch (Exception e) { }
    }

    public void SelectDate(String ChangeDate,int int1)
    {
        try
        {
            Thread.sleep(5000);
            String formattedDate1=null;

            //finding element/date in calendar drop down is enabled or not. if not enabled increase the date by 6 days
            String ele="//div[contains(@class,'k-calendar-view k-calendar-monthview')]/descendant::td[contains(@style,'opacity: 1; ')]/span[contains(@title,'"+ChangeDate+"')]";
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath",ele,4);
            boolean visible=HelpersMethod.IsExists(ele,driver);
            if(visible==false)
            {
                Thread.sleep(1000);
                LocalDate myDateObj = LocalDate.now().plusDays(int1+1);
                DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
                formattedDate1 = myDateObj.format(myFormatObj);
                WebElement ele1=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-calendar-view k-calendar-monthview')]/descendant::td[contains(@style,'opacity: 1; ')]/span[contains(@title,'"+formattedDate1+"')]");
                HelpersMethod.waitTillElementDisplayed(driver,ele1,1);
                HelpersMethod.JSScroll(driver,ele1);
                Thread.sleep(500);
                HelpersMethod.ClickBut(driver,ele1,1);
                Thread.sleep(500);
            }
            else
            {
                //if Date is enabled date is increased by 'some' days already, just click on the date
                WebElement ele1=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-calendar-view k-calendar-monthview')]/descendant::td[contains(@style,'opacity: 1; ')]/span[contains(@title,'"+ChangeDate+"')]");
                HelpersMethod.waitTillElementDisplayed(driver,ele1,2);
                HelpersMethod.JSScroll(driver,ele1);
                HelpersMethod.ClickBut(driver,ele1,1);
            }
            for(int i=0;i<=1;i++)
            {
                //Handling Change delivery date Popup
                XPath = "//div[contains(text(),'Change delivery date')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    WebElement ChangeDD=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Change delivery date']");
                    HelpersMethod.ClickBut(driver,ChangeDD,1);
                }
                //Handling Warning Popup
                XPath = "//div[contains(text(),'Warning')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    WebElement WarningDD=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                    HelpersMethod.ClickBut(driver,WarningDD,1);
                }
            }
            Thread.sleep(5000);
            //Check for note popup
            NoNotePopHandling();
            //Check for OG popup
            OrderGuidePopup();
            //Navigating to OE page, if changing date leads to New OE page
            exists=HelpersMethod.IsExistsById("backButton",driver);
            if(exists==true)
            {
                HelpersMethod.ActClick(driver,driver.findElement(By.id("backButton")),1);//////////
            }
        }
        catch (Exception e) {}
    }

    //Click on Start order button
    public boolean Start_Order()
    {
        try
        {
            exists=false;
            HelpersMethod.Implicitwait(driver, 30);
            if(HelpersMethod.IsExistsById("addButton",driver))
            {
                exists=true;
                HelpersMethod.ScrollElement(driver,SearchOrder);
                HelpersMethod.ClickBut(driver,StartOrder,4);
                HelpersMethod.Implicitwait(driver, 40);
            }
        }
        catch (Exception e){}
        return exists;
    }

    public boolean Start_OrderAgain()
    {
        exists=false;
        try
        {
            WebElement WebEle=HelpersMethod.FindByElement(driver,"id","addButton");
            HelpersMethod.JScriptClick(driver,WebEle,10);
            exists=true;
        }
        catch (Exception e){}
        return exists;
    }

    public void SkipVisible_Click()
    {
        try
        {
            WebElement WebEle=null;
            //Navigate back to Order Entry page
            XPath = "//label[contains(text(),'New order')]/ancestor::div[contains(@class,'i-card order-entry-card')]";
            exists = HelpersMethod.IsExists(XPath, driver);
            if (exists == true)
            {
                driver.navigate().refresh();
                HelpersMethod.Implicitwait(driver,20);
            }
            XPath="//button[contains(text(),'Remove Skip')]";
            exists=HelpersMethod.IsExists(XPath,driver);
            if(exists==false)
            {
                HelpersMethod.ScrollElement(driver,Skip);
                XPath = "//button[text()='Skip']";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    Assert.assertEquals(exists,true);
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//button[text()='Skip']");
                    HelpersMethod.ScrollElement(driver,WebEle);
                    //Click on Skip button
                    HelpersMethod.ClickBut(driver,WebEle,1);

                    //Handling Skip popup
                    XPath = "//div[text()='Skip']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                    exists = HelpersMethod.IsExists(XPath, driver);
                    if (exists == true)
                    {
                        WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[text()='Skip']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                        HelpersMethod.ClickBut(driver,WebEle,1);
                    }
                }
            }
        }
        catch (Exception e) {}
    }

    public void OE_Skip_Reason(String reason)
    {
        try
        {
            HelpersMethod.Implicitwait(driver, 10);
            WebElement Skip_Pop=HelpersMethod.FindByElement(driver,"xpath","//div[text()='Skip']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]");
            exists = HelpersMethod.EleDisplay(Skip_Pop);
            if (exists == true)
            {
                Skip_Pop=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::span[contains(@class,'k-icon k-i-arrow-s')]");
                HelpersMethod.ClickBut(driver,Skip_Pop,1);
                HelpersMethod.WebElementFromDropDown(driver,"//ul[contains(@class,'k-list k-reset')]/descendant::li","xpath",reason);
                WebElement But_Ele=HelpersMethod.FindByElement(driver,"xpath","//button[text()='Ok']");
                HelpersMethod.ClickBut(driver,But_Ele,1);
                HelpersMethod.Implicitwait(driver, 2);
            }
        }
        catch (Exception e){}
    }

    public boolean CheckForRemoveSkip()
    {
        exists=false;
        try
        {
            HelpersMethod.ScrollElement(driver,RemoveSkip);
            //Check for existence of Remove Skip button
            XPath = "//button[text()='Remove Skip']";
            exists = HelpersMethod.IsExists(XPath, driver);
        }
        catch (Exception e){e.printStackTrace();}
        return exists;
    }

    public void ClickRemoveSkip()
    {
        try
        {
             Thread.sleep(2000);
            //Navigate back to Order Entry page
            XPath = "//label[contains(text(),'New order')]/ancestor::div[contains(@class,'i-card order-entry-card')]";
            exists = HelpersMethod.IsExists(XPath, driver);
            if (exists == true)
            {
                driver.navigate().refresh();
                HelpersMethod.Implicitwait(driver, 8);
            }
            HelpersMethod.ScrollElement(driver,RemoveSkip);
            //Check for Remove skip, and click on it
            HelpersMethod.Implicitwait(driver, 2);
            XPath="//button[text()='Remove Skip']";
            exists=HelpersMethod.IsExists(XPath,driver);
          //  Assert.assertEquals(exists,true);
            if(exists==true)
            {
                HelpersMethod.ClickBut(driver,RemoveSkip,1);
            }
            //Check for confirmation popup, to remove skip
            HelpersMethod.Implicitwait(driver,2);
            XPath = "//div[contains(text(),'Remove Skip')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists = HelpersMethod.IsExists(XPath, driver);
            //Assert.assertEquals(exists,true);
            if (exists == true)
            {   WebElement But_Ele=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'Remove Skip')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ClickBut(driver,But_Ele,1);
            }
        }
        catch (Exception e){}
    }

    public boolean CheckForSkip()
    {
        try
        {
            HelpersMethod.ScrollElement(driver,Skip);
            XPath = "//button[text()='Skip']";
            exists = HelpersMethod.IsExists(XPath, driver);
        }
        catch (Exception e){}
        return exists;
    }

    public void Click_HistoryButton()
    {
        try
        {
            HelpersMethod.ScrollElement(driver,HistoryButton);
            HelpersMethod.ClickBut(driver,HistoryButton,1);
            HelpersMethod.Implicitwait(driver,5);
        }
        catch (Exception e){}
    }

    public void Enter_OrderNo_Searchbox(String Order_No)
    {
        try
        {
            HelpersMethod.ScrollElement(driver,SearchOrder);
            HelpersMethod.EnterText(driver,SearchOrder,6,Order_No);
            HelpersMethod.ClickBut(driver,SearchIndex,2);
            HelpersMethod.Implicitwait(driver,5);
        }
        catch (Exception e){}
    }

    public void Existence_OrderNo_OG()
    {
        boolean result=false;
        try
        {
            XPath="//tr[@class='k-master-row']";
            exists=HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                result=true;
            }
        }
        catch (Exception e){}
        Assert.assertEquals(result,true);
    }

    public void Select_Order_OrdersGrid()
    {
        try
        {
            XPath = "//tr[contains(@class,'k-master-row')]/descendant::td/button";
            exists = HelpersMethod.IsExists(XPath, driver);
            if (exists == true)
            {
                HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row')]/descendant::td/button"),1);
            }
        }
        catch (Exception e){}
    }

    public void Click_DropDown()
    {
        try
        {
            WebElement WebEle=driver.findElement(By.id("order-search-card"));
            HelpersMethod.ScrollElement(driver,WebEle);
            HelpersMethod.ClickBut(driver,DropDown,2);
        }
        catch (Exception e){}
    }

    public void Select_Par_Order()
    {
        try
        {
           HelpersMethod.WebElementFromDropDown(driver,"//div[contains(@class,'k-list-container ')]/descendant::li","xpath","Par ordering");
            HelpersMethod.Implicitwait(driver,5);
        }
        catch (Exception e){}
    }

    public void SelectQuote()
    {
        try
        {
            HelpersMethod.WebElementFromDropDown(driver,"//div[contains(@class,'k-list-container ')]/descendant::li","xpath","Quote");
            HelpersMethod.Implicitwait(driver,5);
        }
        catch (Exception e){}

    }

    //For creating customer notes
    public void click_On_CustomerNotes()
    {
        try
        {
            Thread.sleep(10000);
            Actions act=new Actions(driver);
            act.moveToElement(CustomerNote);
            act.click(CustomerNote).build().perform();
        }
        catch (Exception e) {}
    }

    //Enter customer note in cutomer note popup in notetext area
    public void Add_Customer_Note(String Note)
    {
        try
        {
            //HelpersMethod.Implicitwait(driver,10);
            WebElement NoteArea=driver.findElement(By.xpath("//textarea[@id='noteTextbox']"));
            HelpersMethod.ActSendKey(driver,NoteArea,1,Note);
        }
        catch (Exception e){}
    }

    //Alert type in customer note
    public void Select_AlertType_Location(String AltertType,String Altertloc1,String Alertloc2)
    {
        try
        {
            WebElement WebEle=null;
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//p[text()='Notes']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",4);
            //Finding Customer notes popup
            XPath="//p[text()='Notes']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists=HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                //Click on AlertType dorp down, and select Alerttype
                WebEle=HelpersMethod.FindByElement(driver,"id","AlertType");
                HelpersMethod.ClickBut(driver,WebEle,1);
                HelpersMethod.WebElementFromDropDown(driver,"//div[contains(@class,'k-list-container ')]/descendant::li","//div[contains(@class,'k-list-container ')]/descendant::li[contains(text(),'"+AltertType+"')]",AltertType);

                //Click on Alert location check boxes
                java.util.List<WebElement> AlertLocations=driver.findElements(By.xpath("//input[@class='k-checkbox']/following-sibling::label"));
                int i=0;
                for(WebElement AlertLoc:AlertLocations)
                {
                    i++;
                    String AlertLoc_Text=AlertLoc.getText();
                    if(AlertLoc_Text.equals(Altertloc1))
                    {
                        WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'col-md-3 col-xs-12')]["+i+"]/descendant::input");
                        HelpersMethod.ClickBut(driver,WebEle,1);
                    }
                    break;
                }
                i=0;
                for(WebElement AlertLoc:AlertLocations)
                {
                    i++;
                    String AlertLoc_Text=AlertLoc.getText();
                    if(AlertLoc_Text.equals(Alertloc2))
                    {
                        WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'col-md-3 col-xs-12')]["+i+"]/descendant::input");
                        HelpersMethod.ClickBut(driver,WebEle,1);
                    }
                    break;
                }
            }
        }
        catch (Exception e){}
    }

    //Save and Ok button handling in customer note popup
    public void Save_Button()
    {
        try
        {
            HelpersMethod.ClickBut(driver,Save_But,4);
        }
        catch (Exception e){}
    }
    public void Ok_Button()
    {
        try
        {
            HelpersMethod.ClickBut(driver,Ok_But,1);
        }
        catch (Exception e){}
    }

    //Creating list of customer note in customer note grid and select one of the note
    public void Select_Customer_Note(String cust_Note)
    {
        try
        {
            WebElement WebEle=null;
            int i=0;
            //Read all the note from the grid
            java.util.List<WebElement> Notes=driver.findElements(By.xpath("//div[@id='customerCommentGrid']/descendant::div[contains(@class,'k-grid-container')]/descendant::tr/td[3]"));
            for(WebElement Note:Notes)
            {
                i++;
                String Note_Text=Note.getText();
                if(Note_Text.equals(cust_Note))
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@id='customerCommentGrid']/descendant::div[contains(@class,'k-grid-container')]/descendant::tr["+i+"]/td[3]");
                    HelpersMethod.ClickBut(driver,WebEle,1);
                    break;
                }
            }
        }
        catch (Exception e){}
    }

    //Click on Copy button in Customer note popup
    public void Click_Copy_CustomerNote()
    {
        try
        {
            WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@id='CustomerNotesBottomDiv']/descendant::button[@id='copyNote']");
            HelpersMethod.ClickBut(driver,WebEle,1);
        }
        catch (Exception e){}
    }
    //Method for pickup order
    public void Pickup_Order()
    {
        try
        {
            HelpersMethod.WebElementFromDropDown(driver,"//div[contains(@class,'k-list-container ')]/descendant::li","//div[contains(@class,'k-list-container ')]/descendant::li[contains(text(),'"+"Pick up order"+"')]","Pick up order");

            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[contains(text(),'Select delivery date')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",4);
            //Check for existence of Select delivery date popup
            XPath="//div[contains(text(),'Select delivery date')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists=HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[contains(@class,'k-master-row')][1]/td");
                //Click on first date in Select delivery date popup
                HelpersMethod.ClickBut(driver,WebEle,1);
            }

        }
        catch (Exception e){ }
    }

    //Code for deleting customer note
    public void Select_Customer_Note_Del(String cust_Note)
    {
        try {
            int i = 0;
            WebElement WebEle=null;
            //Read all the note from the grid
            List<WebElement> Notes = driver.findElements(By.xpath("//div[@id='customerCommentGrid']/descendant::div[contains(@class,'k-grid-container')]/descendant::tr/td[3]"));
            for (WebElement Note : Notes) {
                i++;
                String Note_Text = Note.getText();
                if (Note_Text.equals(cust_Note))
                {
                    //Select the note
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@id='customerCommentGrid']/descendant::div[contains(@class,'k-grid-container')]/descendant::tr[" + i + "]/td[3]");
                    HelpersMethod.ClickBut(driver,WebEle,1);
                    //Delete the note
                    WebEle=HelpersMethod.FindByElement(driver,"id","deleteNote");
                    HelpersMethod.ClickBut(driver,WebEle,1);
                    break;
                }
            }
        }
        catch (Exception e) {}
    }

    //For reset button functionality in cusomter note popup
    public void ReSet_Button()
    {
        try
        {
            WebElement Button_Ele=HelpersMethod.FindByElement(driver,"id","resetNote");
            HelpersMethod.ClickBut(driver,Button_Ele,1);
        }
        catch (Exception e){}
    }

    //Selcting route from the index popup
    public void Route_No(String SearchOpt,String SearchDetail)
    {
        try
        {

            HelpersMethod.Click_On_IndexFieldIcon(driver,"Route #",SearchOpt ,SearchDetail);
        }
        catch (Exception e){}
    }

    //Click on Route index icon
    public void Route_Popup()
    {
        try
        {
            HelpersMethod.ClickBut(driver,RouteOE,1);
        }
        catch (Exception e){}
    }

    //Click on 1st route in popup
    public void Route1()
    {
        try
        {
            if(HelpersMethod.IsExists("//div[contains(text(),'Route #')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@id='RouteIndexProvider']/descendant::tr[@class='k-master-row'][1]");
               HelpersMethod.ActClick(driver,WebEle,0);
            }
        }
        catch (Exception e){}
    }

    //Code to select OG from popup
    public void SelectOrderGuidePopup()
    {
        try {
            XPath="//div[contains(text(),'Order guides')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists= HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                //code to select OG from popup
                WebElement OgSelect=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[contains(@class,'k-master-row')][1]");
                HelpersMethod.ActClick(driver,OgSelect,4);
                //Code to read name of OG
                String OGDis=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[contains(@class,'k-master-row')][1]/descendant::td[1]").getText();
                //code to click ok button in popup
                WebElement Orderguide= HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ClickBut(driver,Orderguide,1);
                scenario.log("OG HAS BEEN SELECTED POPUP "+OGDis);
            }
            else
            {
                scenario.log("OG POPUP HAS NOT APPEARED");
            }
        }
        catch (Exception e) {}
    }

    public void Click_On_UserIcon() throws InterruptedException
    {
        HelpersMethod.Implicitwait(driver,10);
        exists=false;
        WebElement UserIcon =HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'user-info-container')]/div[contains(@class,'user-info-initial-container')]");
        new WebDriverWait(driver,10).until(ExpectedConditions.visibilityOf(UserIcon));
        if(UserIcon.isDisplayed())
        {
            HelpersMethod.ActClick(driver,UserIcon,4);
            exists=true;
        }
        Assert.assertEquals(exists,true);
    }

    public void Click_On_Signout() throws InterruptedException
    {
        exists=false;
        try {
            WebElement SignOut = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(text(),'Sign out')]");
            HelpersMethod.ActClick(driver, SignOut, 2);
            HelpersMethod.Implicitwait(driver, 20);

            HelpersMethod.waitTillTitleContains(driver, "Ignition - Login", 2);
            String title = driver.getTitle();
            if (title.equals("Ignition - Login")) {
                exists = true;
            }
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void SearchBoxAction(String Quote)
    {
        exists=false;
        try
        {
            if(SearchOrder.isDisplayed())
            {
                HelpersMethod.EnterText(driver, SearchOrder, 4, Quote);
                HelpersMethod.ActClick(driver, SearchIndex, 2);
                exists = true;
            }
            else
            {
                scenario.log("SEARCH BOX IS NOT VISIBLE");
            }
        }
        catch (Exception e){}
    }

    public void ValidateQuoteOrder(String Ord_No)
    {
        HelpersMethod.Implicitwait(driver,15);
        exists=false;
        try
        {
            WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//button[@class='i-link-button ']");
            String O_No=WebEle.getText();
            if(O_No.equals(Ord_No))
            {
                scenario.log("ORDER HAS BEEN FOUND");
                exists=true;
            }
            else
            {
                scenario.log("ORDER HAS NOT BEEN FOUND");
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void ClickOnQuote()
    {
        exists=false;
        try
        {
            WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//button[@class='i-link-button ']");
            HelpersMethod.ClickBut(driver,WebEle,6);
        }
        catch (Exception e){}
    }
}
