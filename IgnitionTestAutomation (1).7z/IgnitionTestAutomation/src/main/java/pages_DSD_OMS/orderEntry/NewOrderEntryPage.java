package pages_DSD_OMS.orderEntry;

import gherkin.lexer.He;
import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.glassfish.jaxb.runtime.v2.model.annotation.Quick;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import util.Environment;
import util.TestBase;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class NewOrderEntryPage
{
    /* Created by Divya */
    /* Created by Divya.Ramadas@afsi.com */

    WebDriver driver;
    Environment testEnvironment;
    Scenario scenario;

    @FindBy(xpath = "//div[contains(@class,'search-bar-container')]/descendant::input[@placeholder='Search products']")
    private WebElement SearchProd;

    @FindBy(id = "quickProduct")
    private WebElement QuickPro;

    @FindBy(id = "quickCases")
    private WebElement QuickCase;

    @FindBy(id = "quickUnits")
    private WebElement QuickUnit;

    @FindBy(xpath = "//div[contains(@class,'search-bar-container')]/descendant::span[contains(@class,'search-button-addon')]")
    private WebElement IndexSearch;

    @FindBy(xpath = "//label[text()='PO #']/following-sibling::input")
    private WebElement PO_No;

    @FindBy(id = "submitOrderButton")
    private WebElement Next_But;

    @FindBy(id = "cancelOrderButton")
    private WebElement Cancel_But;

    @FindBy(id = "backButton")
    private WebElement Back_But;

    @FindBy(id="skipButton")
    private WebElement SkipButton;

    @FindBy(id="orderEntryCard")
    private WebElement OePage;

    @FindBy(xpath="//input[1][contains(@id,'TotalUnitsCol')]")
    private WebElement UnitInput;

    @FindBy(xpath="//input[1][contains(@id,'TotalCasesCol')]")
    private WebElement CaseInput;

    @FindBy(xpath="//button[contains(text(),'Copy from')]")
    private WebElement CopyFrom;

    @FindBy(xpath="//button[contains(text(),'Add product')]")
    private WebElement AddProduct;

    @FindBy(xpath = "//button[text()='Comments']")
    private WebElement Ord_Comments;

    @FindBy(xpath = "//tr[1]/descendant::div[contains(@id,'OrderLineCommentIconColIcon')]")
    private WebElement Prod_Comments;

    @FindBy(xpath = "//button[text()='Export']")
    private WebElement Export_but;

    @FindBy(xpath = "//label[text()='Import']")
    private  WebElement Import_but;

    @FindBy(xpath = "//input[@id='ImportOrder']")
    private WebElement Import_Input;

    @FindBy(xpath="//div[contains(@class,'k-indicator-container')]")
    private WebElement To;

    @FindBy(xpath = "//label[contains(text(),'Product total')]/following-sibling::label")
    private  WebElement Total_amt;

    @FindBy(xpath = "//input[contains(@placeholder,'Route')]")
    private  WebElement Route1;

    @FindBy(xpath="//th/span[contains(text(),'Unit')]")
            private WebElement UnitHeader;

    @FindBy(xpath="//th/span[contains(text(),'Unit')]/span")
            private WebElement Asced_Decend;

    @FindBy(xpath = "//div[contains(@class,'order-header-separator-row')]")
            private WebElement Separator;

    @FindBy(id="filterByQuantities")
            private WebElement ShowAllProd;

    @FindBy(xpath = "//span[contains(text(),'Route #')]/parent::div/descendant::button")
            private WebElement Route_No;

    @FindBy(xpath = "//input[contains(@placeholder,'Route #')]")
            private WebElement RouteInput;

    boolean exists = false;
    String XPath = null;
    String Order_No="1190411";

    public NewOrderEntryPage(WebDriver driver, Scenario scenario) throws InterruptedException, AWTException
    {
        this.scenario=scenario;
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    //Actions
    public boolean ValidateNewOE()
    {
        exists=false;
        try
        {
          HelpersMethod.Implicitwait(driver,8);
          exists=HelpersMethod.IsExists("//label[contains(text(),'New order')]",driver);
        }
        catch (Exception e){}
        return exists;
    }

    public void EnterPO_No(String PO_Num)
    {
        try
        {
            HelpersMethod.Implicitwait(driver,4);
            HelpersMethod.ScrollElement(driver,PO_No);
            HelpersMethod.ClearText(driver,PO_No,4);
            HelpersMethod.ActSendKey(driver,PO_No,2,PO_Num);
            //HelpersMethod.JSSetValueEle(driver,PO_No,2,PO_Num);
            scenario.log("PO# ENTERED IS "+PO_Num);
        }
        catch (Exception e) { }
    }

    public void Click_Back_But()
    {
        try
        {
            exists=false;
            if(HelpersMethod.IsExistsById("orderEntryCard",driver))
            {
                if(Back_But.isEnabled())
                {
                    HelpersMethod.ScrollElement(driver,Back_But);
                    HelpersMethod.ClickBut(driver, Back_But, 4);
                    WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                    HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,40);
                }
                XPath = "//div[@class='order-search-page']";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    Assert.assertEquals(exists, true);
                }
            }
        }
        catch (Exception e){}
    }

    public void Create_Pending_Order_Popup()
    {
        try
        {
            exists = HelpersMethod.EleDisplay(driver.findElement(By.xpath("//div[contains(text(),'Your order has not been submitted.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[contains(text(),'without submitting')]")));
            if (exists == true)
            {
                WebElement Button_Ele=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[contains(text(),'without submitting')]");
                HelpersMethod.ClickBut(driver,Button_Ele,6);
                scenario.log("WITH OUT SUBMITTING OPTION HAS BEEN SELECTED");
            }
            else
            {
                scenario.log("NO PPENDING ORDER POPUP HAS APPEARED ");
            }
        }
        catch (Exception e){}
    }

    public void Discard_All_Pending_Order()
    {
        try
        {
            exists = HelpersMethod.EleDisplay(driver.findElement(By.xpath("//div[contains(text(),'Your order has not been submitted.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[contains(text(),'without submitting')]")));
            if (exists == true)
            {
                WebElement Button_Ele=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[contains(text(),'Discard all')]");
                HelpersMethod.ClickBut(driver,Button_Ele,4);
                scenario.log("DISCARD ALL PENDING ORDER OPTION IS SELECTED");
            }
        }
        catch (Exception e){}
    }

   public void EnterProdNo_InSearchBar(String Product)
    {
        try
        {
            HelpersMethod.ScrollElement(driver, SearchProd);
            HelpersMethod.sendKeys(driver,SearchProd,2,Product);
            HelpersMethod.ClickBut(driver,IndexSearch,1);
            scenario.log("PRODUCT SEARCHED USING SEARCH BAR IS "+Product);
        }
        catch (Exception e) {}
    }

    public boolean CheckForCatalog()
    {
        try
        {
            XPath = "//div[text()='Catalog']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists = HelpersMethod.IsExists(XPath, driver);
        }
        catch (Exception e){}
        return exists;
    }

    //For entering qty in catalog popup based on card/ list catalog display
    public void EnterQty(String Case, String Unit)
    {
        try
        {
            String HeadText = null;
            int i = 0;
            int j = 0;
            boolean exists = false;
            String XPath = null;
            WebElement WebEle=null;
            //Check for catalog popup
            if (driver.findElement(By.xpath("//div[text()='Catalog']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]")).isDisplayed())
            {
                XPath = "//div[contains(text(),'Sorry, no products matched')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == false)
                {
                    //When "Card view" of catlog is enabled
                    XPath = "//div[@class='card-view']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                    exists = HelpersMethod.IsExists(XPath, driver);
                    if (exists == true)
                    {
                        //Enter Unit value in input box of catalog
                        XPath = "//div[contains(text(),'Unit')]/descendant::input";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'Unit')]/descendant::input");
                            HelpersMethod.ScrollElement(driver,WebEle);
                            HelpersMethod.EnterText(driver,WebEle , 4, Unit);
                            WebEle.sendKeys(Keys.TAB);
                            scenario.log("UNIT ENTERED IN CATALOG " + Unit);

                            //Check for popups
                            for (int a = 0; a <= 2; a++)
                            {
                                //Check for "Quantity exceeds maximum of 10 , do you want to continue ?" Popup
                                XPath = "//div[contains(text(),'Quantity exceeds maximum of')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                exists = HelpersMethod.IsExists(XPath, driver);
                                if (exists == true)
                                {
                                    WebEle=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                                    HelpersMethod.ClickBut(driver,WebEle, 4);
                                }
                                //Check for "Out of Stock" popup
                                XPath = "//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                exists = HelpersMethod.IsExists(XPath, driver);
                                if (exists == true)
                                {
                                    WebElement Popup = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                                    HelpersMethod.ClickBut(driver, Popup, 4);
                                }
                                //"Product is currently unavailable" popup
                                XPath = "//div[contains(text(),'This product is currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                exists = HelpersMethod.IsExists(XPath, driver);
                                if (exists == true)
                                {
                                    WebEle=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                                    HelpersMethod.ClickBut(driver,WebEle, 2);
                                }
                            }
                        }
                        //Enter Case value in input box of catalog
                        XPath = "//div[contains(text(),'Case')]/descendant::input";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            WebEle=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(text(),'Case')]/descendant::input");
                            HelpersMethod.ScrollElement(driver,WebEle);
                            HelpersMethod.EnterText(driver,WebEle, 2, Case);
                            WebEle.sendKeys(Keys.TAB);
                            scenario.log("CASES ENTERED IN CATALOG " + Case);
                            //Check for popups
                            for (int a = 0; a <= 2; a++)
                            {
                                //Check for "Quantity exceeds maximum of 10 , do you want to continue ?" Popup
                                XPath = "//div[contains(text(),'Quantity exceeds maximum of')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                exists = HelpersMethod.IsExists(XPath, driver);
                                if (exists == true)
                                {
                                    WebEle=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                                    HelpersMethod.ClickBut(driver,WebEle, 2);
                                }
                                //Check for "Out of Stock" popup
                                XPath = "//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                exists = HelpersMethod.IsExists(XPath, driver);
                                if (exists == true)
                                {
                                    HelpersMethod.FindByElement(driver, "xpath", "//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button").click();
                                }
                                //"Product is currently unavailable" popup
                                XPath = "//div[contains(text(),'This product is currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                exists = HelpersMethod.IsExists(XPath, driver);
                                if (exists == true)
                                {
                                    WebEle=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                                    HelpersMethod.ClickBut(driver,WebEle, 2);
                                }
                            }
                        }
                    }
                    //Grid view display of catalog
                    else if (driver.findElement(By.xpath("//table[@class='k-grid-table']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]")).isDisplayed())
                    {
                        int b = 0;
                        List<WebElement> tableHeads = HelpersMethod.FindByElements(driver, "xpath", "//div[@class='i-grid']/descendant::th[@class='k-header ']/span[@class='k-link']");
                        for (WebElement tableHead : tableHeads)
                        {
                            b++;
                            WebElement UnitCase=null;
                            String THead_Text=tableHead.getText();
                            if (THead_Text.equals("Units"))
                            {
                                UnitCase= HelpersMethod.FindByElement(driver, "xpath", "//div[@class='product-catalog-container catalog-search-grid-view']/descendant::tr[contains(@class,'k-master-row')]//descendant::td["+(b+1)+"]/descendant::input");
                                HelpersMethod.ScrollElement(driver,UnitCase);
                                HelpersMethod.ActSendKey(driver, UnitCase, 4, Unit);
                                scenario.log("UNITS ENTERED IN CATALOG " + Unit);
                                //Check for popups
                                for (int a = 0; a <= 2; a++) {
                                    //Check for "Quantity exceeds maximum of 10 , do you want to continue ?" Popup
                                    XPath = "//div[contains(text(),'Quantity exceeds maximum of')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                    exists = HelpersMethod.IsExists(XPath, driver);
                                    if (exists == true)
                                    {
                                        WebEle=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                                        HelpersMethod.ClickBut(driver,WebEle, 1);
                                    }
                                    //Check for "Out of Stock" popup
                                    XPath = "//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                    exists = HelpersMethod.IsExists(XPath, driver);
                                    if (exists == true)
                                    {
                                        HelpersMethod.FindByElement(driver, "xpath", "//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button").click();
                                    }
                                    //"Product is currently unavailable" popup
                                    XPath = "//div[contains(text(),'This product is currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                    exists = HelpersMethod.IsExists(XPath, driver);
                                    if (exists == true)
                                    {
                                        WebEle=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                                        HelpersMethod.ClickBut(driver,WebEle, 1);
                                    }
                                }
                            }
                            else
                            {
                                if (THead_Text.equals("Cases"))
                                {
                                    //Find whether Cases input box is displayed
                                    XPath = "//div[@class='product-catalog-container catalog-search-grid-view']/descendant::tr[contains(@class,'k-master-row')]//descendant::td[" + (b+1) + "]/descendant::input";
                                    exists = HelpersMethod.IsExists(XPath, driver);
                                    if (exists == true)
                                    {
                                        UnitCase = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='product-catalog-container catalog-search-grid-view']/descendant::tr[contains(@class,'k-master-row')]//descendant::td[" + (b + 1) + "]/descendant::input");
                                        HelpersMethod.ScrollElement(driver,WebEle);
                                        HelpersMethod.ActSendKey(driver, UnitCase, 1, Unit);
                                        scenario.log("CASES ENTERED IN CATALOG is " + Unit);
                                        //Check for popups
                                        for (int a = 0; a <= 2; a++)
                                        {
                                            //Check for "Quantity exceeds maximum of 10 , do you want to continue ?" Popup
                                            XPath = "//div[contains(text(),'Quantity exceeds maximum of')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                            exists = HelpersMethod.IsExists(XPath, driver);
                                            if (exists == true)
                                            {
                                                WebEle=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                                                HelpersMethod.ClickBut(driver,WebEle, 1);
                                            }
                                            //Check for "Out of Stock" popup
                                            XPath = "//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                            exists = HelpersMethod.IsExists(XPath, driver);
                                            if (exists == true)
                                            {
                                                HelpersMethod.FindByElement(driver, "xpath", "//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button").click();
                                            }
                                            //"Product is currently unavailable" popup
                                            XPath = "//div[contains(text(),'This product is currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                            exists = HelpersMethod.IsExists(XPath, driver);
                                            if (exists == true)
                                            {
                                                WebEle=HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                                                HelpersMethod.ClickBut(driver,WebEle, 1);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    scenario.log("PRODUCT HAS NOT BEEN FOUND");
                }
                WebEle=HelpersMethod.FindByElement(driver, "xpath", "//button[contains(text(),'Ok')]");
                HelpersMethod.ClickBut(driver,WebEle, 2);
            }
        } catch (Exception e) {}
    }

    public boolean ClickNext() throws InterruptedException
    {
        exists=false;
        HelpersMethod.Implicitwait(driver,15);
        try
        {
          if(Next_But.isDisplayed() && Next_But.isEnabled())
          {
             // HelpersMethod.ActClick(driver, Next_But, 8);
              HelpersMethod.JScriptClick(driver,Next_But,8);
              HelpersMethod.Implicitwait(driver,10);////////////
              exists=true;
          }
        }
        catch (Exception e){ }
        return exists;
    }

    public void OutOfStockPop_ERP() throws InterruptedException
    {
        try
        {
            WebElement WebEle=null;
            for (int i = 0; i <= 4; i++)
            {
                //Frequently ordered items
                XPath="//div[contains(text(),'Frequently ordered items not ordered')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists=HelpersMethod.IsExists(XPath,driver);
                if(exists==true)
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='No']");
                    HelpersMethod.ClickBut(driver,WebEle,2);
                   // Thread.sleep(100);
                }

                // requires an order factor of 8 units. the quantity order has been increased to 16
                XPath = "//div[contains(text(),'the quantity order has been increased to')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='k-widget k-window k-dialog']/descendant::button[text()='Continue']");
                    HelpersMethod.ClickBut(driver,WebEle,4);
                }

                //out of stock popup
                XPath = "//div[contains(text(),'% of your average order for the given products')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='k-widget k-window k-dialog']/descendant::button[text()='Continue']");
                    HelpersMethod.ClickBut(driver,WebEle,4);
                }

                //Minimum order amount has not been reached
                XPath = "//div[contains(text(),'the minimum order amount')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'the minimum order amount')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                    HelpersMethod.ClickBut(driver,WebEle,4);
                    ////    HelpersMethod.Implicitwait(driver, 10);
                }
                //Critical item popup
                XPath = "//div[contains(text(),'Critical items not ordered')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                    HelpersMethod.ClickBut(driver,WebEle,4);
                    ClickNext();
                }
            }
        }
        catch (Exception e){}
    }

    public void OutOfStockPop_DSD() throws InterruptedException
    {
        try
        {
            WebElement WebEle=null;

            for (int i = 0; i <= 4; i++)
            {
                //Frequently ordered items
                XPath="//div[contains(text(),'Frequently ordered items not ordered')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists=HelpersMethod.IsExists(XPath,driver);
                if(exists==true)
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='No']");
                    HelpersMethod.ClickBut(driver,WebEle,2);
                    ////////Thread.sleep(100);
                }

                //Qty has been increased to popup
                XPath = "//div[contains(text(),'the quantity order has been increased to')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='k-widget k-window k-dialog']/descendant::button[text()='Continue']");
                    HelpersMethod.ClickBut(driver,WebEle,2);
                    Thread.sleep(100);
                }

                //% of average order stock popup
                XPath = "//div[contains(text(),'% of your average order for the given products')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='k-widget k-window k-dialog']/descendant::button[text()='Continue']");
                    HelpersMethod.ClickBut(driver,WebEle,2);
                    Thread.sleep(100);
                }

                //Minimum order amount not reached  popup
                //Check for existence of product in Product grid, Of New order entry page (IN DSD ENV)
                XPath = "//div[contains(text(),'the minimum order amount has not been reached')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'the minimum order amount has not been reached')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button"),2);

                    //Scroll till product grid
                    HelpersMethod.ScrollElement(driver, HelpersMethod.FindByElement(driver,"id","orderEntryGridContainer"));

                    //Check for existence of product in Product grid, Of New order entry page
                    XPath = "//table[contains(@class,'k-grid-table')]";
                    exists = HelpersMethod.IsExists(XPath, driver);
                    if (exists == true)
                    {
                        //Check Whether Case is enabled or not
                        XPath = "//tr[1]/descendant::input[contains(@id,'TotalCasesCol')]";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            WebEle = HelpersMethod.FindByElement(driver,"xpath","//tr[1]/descendant::input[contains(@id,'TotalCasesCol')]");
                            HelpersMethod.ActSendKey(driver, WebEle, 4,"50");
                        }

                        //Check Whether Units is enabled or not
                        XPath = "//tr[1]/descendant::input[contains(@id,'TotalUnitsCol')]";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            WebEle = HelpersMethod.FindByElement(driver,"xpath","//tr[1]/descendant::input[contains(@id,'TotalUnitsCol')]");
                            HelpersMethod.ActSendKey(driver,WebEle, 4,"50");
                        }
                    }
                    ClickNext();
                }
                //Critical item popup
                XPath = "//div[contains(text(),'Critical items not ordered')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                    HelpersMethod.ClickBut(driver,WebEle,4);
                    ClickNext();
                }
            }
        }
        catch (Exception e){}
    }

    public void QuickProduct(String Prod) throws InterruptedException
    {
        try
        {
            HelpersMethod.ActSendKey(driver, QuickPro,10,Prod);
            scenario.log("PRODUCT ADDED TO THE ORDER Via QUICK PRODUCT ENTRY "+Prod);
        }
        catch (Exception e){}
    }

    public void OECancel()
    {
        try
        {
            //HelpersMethod.Implicitwait(driver, 5);
            HelpersMethod.ClickBut(driver,Cancel_But,5);
            scenario.log("ORDER HAS BEEN CANCELED");
        }
        catch (Exception e){}
    }

    public void CancelPop()
    {
        try
        {
            //Check for the Cancel Order warning popup
            XPath = "//div[contains(text(),'Cancel order')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists = HelpersMethod.IsExists(XPath, driver);
            if (exists == true)
            {
                WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'Cancel order')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                HelpersMethod.ClickBut(driver,WebEle,2);
            }
        }
        catch (Exception e){}
    }

    public void CheckForQuickCaseEnabled(String Case)  throws InterruptedException
    {
        try
        {
            WebElement WebEle = null;
            HelpersMethod.ScrollElement(driver, QuickPro);
            if (QuickCase.isDisplayed())
            {
                // HelpersMethod.ActSendKey(driver, QuickUnit,1,Unit);
                HelpersMethod.sendKeys(driver, QuickCase, 1, Case);
                HelpersMethod.Implicitwait(driver, 1);
                QuickCase.sendKeys(Keys.ENTER);
                scenario.log("CASE ENTERED FOR QUICK PRODUCT IS " + Case);

                HelpersMethod.Implicitwait(driver, 2);
                for (int i = 0; i <= 3; i++) {
                    //Check for 'Product Unavailable' popup
                    XPath = "//div[contains(text(),'This product is currently unavailable.')]/ancestor::div[@id='toast-container']";
                    exists = HelpersMethod.IsExists(XPath, driver);
                    if (exists == true) {
                        WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@id='toast-container']/descendant::button");
                        HelpersMethod.ClickBut(driver, WebEle, 4);
                    }
                    HelpersMethod.Implicitwait(driver, 2);
                    //Check for 'Product low in invetory' popup
                    XPath = "//div[contains(text(),'This product is currently low')]/ancestor::div[@id='toast-container']";
                    exists = HelpersMethod.IsExists(XPath, driver);
                    if (exists == true) {
                        WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@id='toast-container']/descendant::button");
                        HelpersMethod.ClickBut(driver, WebEle, 1);
                    }
                    /// HelpersMethod.Implicitwait(driver, 10);
                    //Check for 'There are no matching product' popup
                    XPath = "//div[contains(text(),'There are no matching products: ')]/ancestor::div[contains(@class,'toast toast-error')]";
                    exists = HelpersMethod.IsExists(XPath, driver);
                    if (exists == true) {
                        WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@id='toast-container']/descendant::button");
                        HelpersMethod.ClickBut(driver, WebEle, 1);
                    }
                    HelpersMethod.Implicitwait(driver, 2);
                }
            }
            HelpersMethod.Implicitwait(driver, 4);
        }
        catch (Exception e) {}
    }

    public void CheckForQuickUnitEnabled(String Unit)  throws InterruptedException {

        try {
            WebElement WebEle = null;
            HelpersMethod.ScrollElement(driver, QuickPro);
            if (QuickUnit.isDisplayed()) {
                HelpersMethod.sendKeys(driver, QuickUnit, 1, Unit);
                HelpersMethod.Implicitwait(driver, 1);
                QuickUnit.sendKeys(Keys.ENTER);
                scenario.log("Unit ENTERED FOR QUICK PRODUCT IS " + Unit);

                HelpersMethod.Implicitwait(driver, 4);
                for (int i = 0; i <= 3; i++) {
                    //Check for 'Product Unavailable' popup
                    XPath = "//div[contains(text(),'This product is currently unavailable.')]/ancestor::div[@id='toast-container']";
                    exists = HelpersMethod.IsExists(XPath, driver);
                    if (exists == true) {
                        WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@id='toast-container']/descendant::button");
                        HelpersMethod.ClickBut(driver, WebEle, 2);
                    }
                    HelpersMethod.Implicitwait(driver, 2);
                    //Check for 'Product low in invetory' popup
                    XPath = "//div[contains(text(),'This product is currently low')]/ancestor::div[@id='toast-container']";
                    exists = HelpersMethod.IsExists(XPath, driver);
                    if (exists == true) {
                        WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@id='toast-container']/descendant::button");
                        HelpersMethod.ClickBut(driver, WebEle, 1);
                    }
                    /// HelpersMethod.Implicitwait(driver, 10);
                    //Check for 'There are no matching product' popup
                    XPath = "//div[contains(text(),'There are no matching products: ')]/ancestor::div[contains(@class,'toast toast-error')]";
                    exists = HelpersMethod.IsExists(XPath, driver);
                    if (exists == true) {
                        WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@id='toast-container']/descendant::button");
                        HelpersMethod.ClickBut(driver, WebEle, 1);
                    }
                    HelpersMethod.Implicitwait(driver, 2);
                }
            }
        } catch (Exception e) {
        }
    }

    public void New_OE_Click_Skip_Button(String reason)
    {
        try
        {
            HelpersMethod.ClickBut(driver,SkipButton,4);
            HelpersMethod.Implicitwait(driver, 6);
            WebElement Skip_Pop=HelpersMethod.FindByElement(driver,"xpath","//div[text()='Skip']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]");
           // WebElement Skip_Pop = driver.findElement(By.xpath("//div[text()='Skip']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]"));
            exists = HelpersMethod.EleDisplay(Skip_Pop);
            if (exists == true)
            {
                WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::span[contains(@class,'k-icon k-i-arrow-s')]");
                HelpersMethod.ClickBut(driver,WebEle,4);
                HelpersMethod.WebElementFromDropDown(driver,"//ul[contains(@class,'k-list k-reset')]/descendant::li","xpath",reason);
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//button[text()='Ok']");
                HelpersMethod.ClickBut(driver,WebEle,2);
                //HelpersMethod.Implicitwait(driver, 5);
            }
        }
        catch (Exception e){}
    }

    public void Enter_Qty_InGrid(String unit,String cas) throws InterruptedException
    {
        try
        {
            //HelpersMethod.Implicitwait(driver, 5);
            HelpersMethod.ScrollElement(driver, driver.findElement(By.id("orderEntryGridContainer")));
            HelpersMethod.EnterText(driver,UnitInput, 2,unit);
            HelpersMethod.EnterText(driver,CaseInput, 2,cas);
        }
        catch (Exception e){}
    }

    public void Click_On_Copy_From_DropDown(String OrdHist)
    {
        try
        {
            HelpersMethod.ClickBut(driver,CopyFrom,4);
            /////////////HelpersMethod.Implicitwait(driver,5);
            HelpersMethod.WebElementFromDropDown(driver,"//div[contains(@class,'k-list-container ')]/descendant::li","xpath",OrdHist);
        }
        catch (Exception e){}
    }

    public void Click_On_Add_Product()
    {
        try
        {
            HelpersMethod.ClickBut(driver,AddProduct,1);
        }
        catch (Exception e) {}
    }

    public void SelectOGFromDropdown()
    {
     try
         {
         HelpersMethod.WebElementFromDropDown(driver,"//div[contains(@class,'k-list-container ')]/descendant::li","xpath","From Order guides");
        }
        catch (Exception e){}
    }

    public void OrderGuideGrid()
    {
        WebElement OG=null;
        String OGNo=null;
        try
        {
            if(HelpersMethod.IsExists("//div[contains(text(),'Order guides')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                OG=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[@class='k-master-row'][1]");
                OGNo=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[@class='k-master-row'][1]/td[1]").getText();
                HelpersMethod.ActClick(driver,OG,1);
                OG=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ActClick(driver,OG,1);
                scenario.log("ORDER GUIDE SELECTED IS "+OGNo);
            }
        }
        catch (Exception e){}
    }

    //For entering Qty in Product grid
    public void EnterQty_ProductGrid(WebDriver driver,String Case,String Unit)
    {
        try
        {
            WebElement WebEle=null;

            //Scroll till product grid
            HelpersMethod.ScrollElement(driver, driver.findElement(By.id("orderEntryGridContainer")));

            //Check for existence of product in Product grid, Of New order entry page
            XPath = "//table[contains(@class,'k-grid-table')]";
            exists = HelpersMethod.IsExists(XPath, driver);
            if (exists == true)
            {
                //Check Whether Cases is enabled or not
                XPath = "//tr[1]/descendant::input[contains(@id,'TotalCasesCol')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    WebEle = driver.findElement(By.xpath("//tr[1]/descendant::input[contains(@id,'TotalCasesCol')]"));

                    HelpersMethod.ActSendKey(driver, WebEle, 1,Case);

                    for(int i=0;i<=2;i++)
                    {
                        //Check for 'Qty exceeds maximum of' Popup
                        XPath = "//div[contains(text(),'Quantity exceeds maximum of')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                            HelpersMethod.ClickBut(driver,WebEle,1);
                            HelpersMethod.Implicitwait(driver, 5);
                        }

                        //Handling Product unavailable
                        XPath = "//div[contains(text(),'This product is currently low on inventory')]/ancestor::div[contains(@id,'toast-container')]";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@id,'toast-container')]/descendant::button");
                            HelpersMethod.ClickBut(driver,WebEle,4);
                        }

                        //Handling product unavailable, popup
                        XPath="//div[contains(text(),'This product is currently unavailable')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                        exists=HelpersMethod.IsExists(XPath,driver);
                        if(exists==true)
                        {
                            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                            HelpersMethod.ClickBut(driver,WebEle,4);
                        }
                    }
                }

                //Check Whether Units is enabled or not
                XPath = "//tr[1]/descendant::input[contains(@id,'TotalUnitsCol')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    WebEle = driver.findElement(By.xpath("//tr[1]/descendant::input[contains(@id,'TotalUnitsCol')]"));
                    HelpersMethod.ActSendKey(driver, WebEle,1,Unit);

                    for(int i=0;i<=2;i++)
                    {
                        //Check for 'Qty exceeds maximum of' Popup
                        XPath = "//div[contains(text(),'Quantity exceeds maximum of')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                            HelpersMethod.ClickBut(driver,WebEle,1);
                            HelpersMethod.Implicitwait(driver, 5);
                        }

                        //Handling Product unavailable
                        XPath = "//div[contains(text(),'This product is currently low on inventory')]/ancestor::div[contains(@id,'toast-container')]";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@id,'toast-container')]/descendant::button");
                            HelpersMethod.ClickBut(driver,WebEle,1);
                        }

                        //Handling product unavailable, popup
                        XPath = "//div[contains(text(),'This product is currently unavailable')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                            HelpersMethod.ClickBut(driver,WebEle ,2);
                        }
                    }
                }
            }
        }
        catch(Exception e){}
    }

    public void Comment_Icon()
    {
        try
        {
            HelpersMethod.ClickBut(driver,Ord_Comments,1);
        }
        catch (Exception e){e.printStackTrace();}
    }

    //handling 'Comment' popup for order and for product
    public void Comment_Popup(String Comment)
    {
        try
        {
            WebElement WebEle;
            //Thread.sleep(1000);
            XPath="//div[text()='Comments']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists=HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                driver.findElement(By.id("textAreaA")).sendKeys(Comment);

                //Click on Add button in the popup
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Add']");
                HelpersMethod.ClickBut(driver,WebEle,1);

                //Click on OK button
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ClickBut(driver,WebEle,1);
            }
        }
        catch (Exception e){}
    }

    public void Prod_Comment_Icon()
    {
        try
        {
            WebElement WebEle=null;
            XPath="//tr[1]/descendant::div[contains(@id,'OrderLineCommentIconColIcon')]";
            exists=HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                WebEle=HelpersMethod.FindByElement(driver,"id",("orderEntryGridContainer"));
                HelpersMethod.ScrollElement(driver,WebEle);
               //////////// HelpersMethod.Implicitwait(driver,5);
                HelpersMethod.ClickBut(driver,Prod_Comments,4);
            }
            else
            {
                scenario.log("PRODUCT COMMENT ICON DOESN'T EXISTS");
            }
        }
        catch(Exception e){}
    }

    public void Comment_PopupProd(String Comment)
    {
        try
        {
            WebElement WebEle=null;
            XPath="//div[contains(text(),'comments')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists=HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                driver.findElement(By.id("textAreaA")).sendKeys(Comment);

                //Click on Add button in the popup
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Add']");
                HelpersMethod.ClickBut(driver,WebEle,2);

                //Click on OK button
                HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']"),4);
            }
        }
        catch (Exception e){}
    }

    public void Add_Product_From_Catalog()
    {
        try
        {
           ////////// Thread.sleep(500);
            HelpersMethod.ClickBut(driver,AddProduct,1);
            HelpersMethod.WebElementFromDropDown(driver, "//div[contains(@class,'k-list-container ')]/descendant::li","//div[contains(@class,'k-list-container ')]/descendant::li[contains(text(),'"+"From Catalog"+"')]","From Catalog");
        }
        catch (Exception e) { }
    }

    public void Search_Prod_in_Catalog(String prod,String unit,String cases)
    {
        try
        {
            WebElement WebEle=null;
            int i=0;
            //Catalog popup(Card view)
            XPath="//div[contains(@class,'card-view')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists=HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//input[contains(@class,'product-search-input')]");
                HelpersMethod.EnterText(driver,WebEle,4,prod);
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='searchBarDropdown']/descendant::span[contains(@class,'search-button-addon search-button input-group-addon')]");
                HelpersMethod.ClickBut(driver,WebEle,4);

                //Check whether product details displayed in catalog or not
                exists=HelpersMethod.IsExistsById("no-products-found",driver);
                if(exists==false)
                {
                    //scroll till qty input box, only one input box is given for qty
                    HelpersMethod.ScrollElement(driver, driver.findElement(By.xpath("//div[contains(@class,'k-window-content k-dialog-content')]")));
                }

                //Enter Qty for units and cases
                XPath="//div[contains(text(),'Units')]/descendant::input";
                exists=HelpersMethod.IsExists(XPath,driver);
                if(exists==true)
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'Units')]/descendant::input");
                    HelpersMethod.EnterText(driver,WebEle,4,unit);

                    //Check for popups
                    for(int a=0;a<=2;a++)
                    {
                        //Check for "Quantity exceeds maximum of 10 , do you want to continue ?" Popup
                        XPath = "//div[contains(text(),'Quantity exceeds maximum of')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                            HelpersMethod.ClickBut(driver,WebEle,2);
                        }
                        //Check for "Out of Stock" popup
                        XPath = "//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button").click();
                        }
                        //"Product is currently unavailable" popup
                        XPath = "//div[contains(text(),'This product is currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                            HelpersMethod.ClickBut(driver,WebEle,2);
                        }
                    }
                }
                XPath="//div[contains(text(),'Cases')]/descendant::input";
                exists=HelpersMethod.IsExists(XPath,driver);
                if(exists==true)
                {
                    HelpersMethod.EnterText(driver,HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'Cases')]/descendant::input"),2,cases);

                    //Check for popups
                    for(int a=0;a<=2;a++) {
                        //Check for "Quantity exceeds maximum of 10 , do you want to continue ?" Popup
                        XPath = "//div[contains(text(),'Quantity exceeds maximum of')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                            HelpersMethod.ClickBut(driver,WebEle,1);
                        }
                        //Check for "Out of Stock" popup
                        XPath = "//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true) {
                            driver.findElement(By.xpath("//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button")).click();
                        }
                        //"Product is currently unavailable" popup
                        XPath = "//div[contains(text(),'This product is currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                            HelpersMethod.ClickBut(driver,WebEle,2);
                        }
                    }
                }
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ClickBut(driver,WebEle,2);
            }

            //Check for catalog(List view)
            XPath="//div[@class='i-grid']";
            exists=HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                //Check for filter row existence
                XPath="//span[contains(@class,'k-i-filter-clear k-icon')]";
                exists=HelpersMethod.IsExists(XPath,driver);
                if(exists==false)
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//span[contains(@class,'k-icon k-i-filter k-icon')]");
                    HelpersMethod.ClickBut(driver,WebEle,1);
                }
                //Find filter for product and enter product number in filter, using for loop find the 'Product' heading position
                //And based on that enter product number in input box
                java.util.List<WebElement> TableHeads=driver.findElements(By.xpath("//div[@class='i-grid']/descendant::tr[1]/th/span[1]"));
                for (WebElement TableHead:TableHeads)
                {
                    i++;
                    String Head_Text = TableHead.getText();
                    if (Head_Text.contains("Product #"))
                    {
                        //Enter the product number in input box
                        WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='i-grid']/descendant::tr[2]/th[" + (i) + "]/descendant::input");
                        HelpersMethod.EnterText(driver,WebEle,2, prod);
                    }
                }
                for(WebElement TableHead:TableHeads)
                {
                    i++;
                    String Head_Text=TableHead.getText();
                    if(Head_Text.contains("Units"))
                    {
                        //Enter qty in inputbox, for units
                        XPath = "//td[" + i + "]/descendant::input";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            WebEle=HelpersMethod.FindByElement(driver,"xpath","//td[" + i + "]/descendant::input");
                            HelpersMethod.EnterText(driver,WebEle,2, unit);

                            //Check for unavailable popup
                            XPath = "//div[contains(text(),'currently unavailable')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                            exists = HelpersMethod.IsExists(XPath, driver);
                            if (exists == true)
                            {
                                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'currently unavailable')]/parent::div/following-sibling::div/button");
                                HelpersMethod.ClickBut(driver,WebEle,2);
                            }
                            //Check for popups
                            for (int a = 0; a <= 2; a++)
                            {
                                //Check for "Quantity exceeds maximum of 10 , do you want to continue ?" Popup
                                XPath = "//div[contains(text(),'Quantity exceeds maximum of')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                exists = HelpersMethod.IsExists(XPath, driver);
                                if (exists == true)
                                {
                                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                                    HelpersMethod.ClickBut(driver,WebEle,1);
                                }
                                //Check for "Out of Stock" popup
                                XPath = "//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                exists = HelpersMethod.IsExists(XPath, driver);
                                if (exists == true) {
                                    driver.findElement(By.xpath("//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button")).click();
                                }
                                //"Product is currently unavailable" popup
                                XPath = "//div[contains(text(),'This product is currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                exists = HelpersMethod.IsExists(XPath, driver);
                                if (exists == true)
                                {
                                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                                    HelpersMethod.ClickBut(driver,WebEle,2);
                                }
                            }
                        }
                        break;
                    }
                }

                for(WebElement TableHead:TableHeads)
                {
                    i++;
                    String Head_Text=TableHead.getText();
                    if(Head_Text.contains("Units"))
                    {
                        //Enter qty in inputbox, for units
                        XPath = "//td[" + i + "]/descendant::input";
                        exists = HelpersMethod.IsExists(XPath, driver);
                        if (exists == true)
                        {
                            WebEle=HelpersMethod.FindByElement(driver,"xpath","//td[" + i + "]/descendant::input");
                            HelpersMethod.EnterText(driver,WebEle,2, unit);

                            //Check for unavailable popup
                            XPath = "//div[contains(text(),'currently unavailable')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                            exists = HelpersMethod.IsExists(XPath, driver);
                            if (exists == true)
                            {
                                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'currently unavailable')]/parent::div/following-sibling::div/button");
                                HelpersMethod.ClickBut(driver,WebEle,2);
                            }
                            //Check for popups
                            for (int a = 0; a <= 2; a++) {
                                //Check for "Quantity exceeds maximum of 10 , do you want to continue ?" Popup
                                XPath = "//div[contains(text(),'Quantity exceeds maximum of')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                exists = HelpersMethod.IsExists(XPath, driver);
                                if (exists == true)
                                {
                                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                                    HelpersMethod.ClickBut(driver,WebEle,2);
                                }
                                //Check for "Out of Stock" popup
                                XPath = "//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                exists = HelpersMethod.IsExists(XPath, driver);
                                if (exists == true) {
                                    driver.findElement(By.xpath("//div[contains(text(),'Out of stock')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button")).click();
                                }
                                //"Product is currently unavailable" popup
                                XPath = "//div[contains(text(),'This product is currently unavailable.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                                exists = HelpersMethod.IsExists(XPath, driver);
                                if (exists == true)
                                {
                                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button");
                                    HelpersMethod.ClickBut(driver,WebEle,2);
                                }
                            }
                        }
                        break;
                    }
                }
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ClickBut(driver,WebEle,2);
            }
        }
        catch (Exception e){}
    }

    public String Export_button()
    {
        String Actual_Order=null;
       try
        {
            if(HelpersMethod.EleDisplay(Export_but)==true)
            {
                HelpersMethod.ScrollElement(driver,Export_but);
                HelpersMethod.ActClick(driver,Export_but,1);
                HelpersMethod.Implicitwait(driver,8);
                if(TestBase.testEnvironment.get_browser().equalsIgnoreCase("Firefox"))
                {
                    HelpersMethod.FileDownload();
                }

                //read order# displayed in new OE page
                Order_No=HelpersMethod.ReadValue(driver.findElement(By.xpath("//label[contains(text(),'Order #')]")));
                Actual_Order=Order_No.substring(8);

                //Read all the .csv files in download directory and compare with actual order number
                File dir = new File("C:\\Users\\Divya.Ramadas\\Downloads");
                FileFilter fileFilter = new WildcardFileFilter("*.csv");
                File[] files = dir.listFiles(fileFilter);
                String file2=null;

                for (File Exportfile:files)
                {
                    String file1 = Exportfile.getName();
                    file2 =file1.substring(6,16);
                    if(Actual_Order.equals(file2))
                    {
                        break;
                    }
                }
                Assert.assertEquals(Actual_Order, file2);
                HelpersMethod.Implicitwait(driver,5);
            }
        }
        catch (Exception e) { }
        return Actual_Order;
    }

    public void Import_button(String ord_No)
    {
        try
        {
            //send file name to input box
            String Ord_no="Order_"+ord_No+".csv";

            HelpersMethod.ScrollElement(driver,Import_but);
            //Click on import button
            HelpersMethod.ClickBut(driver,Import_but,5);

            //Check for popup
            XPath="//div[contains(text(),'following columns are required')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists=HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button"),2);
            }

            //Copying the file name to input box of file upload popup
            // Thread.sleep(5000);
            HelpersMethod.Implicitwait(driver,10);
            StringSelection stringselection=new StringSelection("C:\\Users\\Divya.Ramadas\\Downloads\\"+Ord_no);
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringselection,null);

            //calling robot class and method for uploading file
            HelpersMethod.FileUploadRobot();

            //Handling import confirmation popup
            XPath="//div[contains(text(),'overridden on import')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists=HelpersMethod.IsExists(XPath,driver);
            if(exists==true)
            {
                HelpersMethod.ClickBut(driver,HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']"),2);
            }
        }
        catch (Exception e){}
    }

    //After import add some Qty to 1st product in the grid
    public void QtyProdGrid(String Qty)
    {
        try
        {
            HelpersMethod.EnterText(driver,HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row k-grid-edit-row')][1]/descendant::input[contains(@id,'TotalUnitsCol')]"),2,Qty);
        }
        catch (Exception e){}
    }


    public void Click_on_BackButton()
    {
        try
        {
            WebElement Back_Checout=driver.findElement(By.id("CancelCheckoutButton"));
            HelpersMethod.ScrollElement(driver,Back_Checout);
            HelpersMethod.ClickBut(driver,Back_Checout,10);
            ////////////// HelpersMethod.Implicitwait(driver,20);
        }
        catch (Exception e){}
    }

    public void FindtableHeader(String To_Text)
    {
       try
        {
            if(HelpersMethod.EleDisplay(To))
            {
                List<WebElement> TableHeads=driver.findElements(By.xpath("//thead/tr[1]/th"));
                for(WebElement THead:TableHeads)
                {
                    String Head=THead.getText();
                    if(Head.equals(To_Text))
                    {
                        HelpersMethod.ActDragDrop(driver,THead,To);
                    }
                }
            }
        }
        catch (Exception e){}
    }

    //Search for Product Description in Search bar
    public void SearchBox_ProdDesc(String Prod_Des)
    {
        try
        {
            //HelpersMethod.Implicitwait(driver,2);
            HelpersMethod.ScrollElement(driver, SearchProd);
            HelpersMethod.EnterText(driver,SearchProd,2,Prod_Des);
            HelpersMethod.ClickBut(driver,IndexSearch,1);
        }
        catch (Exception e) {}
    }
    //method to find total amount in new order entry page
    public String Total_NewOE()
    {
        String tot_amt=null;
        try
        {
            tot_amt=HelpersMethod.ReadValue(Total_amt);
        }
        catch (Exception e){}
        return tot_amt;
    }
    //Reading value in route inputbox
    public String Read_Route()
    {
        String New_route=null;
        try
        {
            New_route=Route1.getAttribute("value");
        }
        catch (Exception e){}
        return New_route;
    }

    //Check whether color of Product note icon has been changed or not
    public boolean ProNote_Color()
    {
        try
        {
            XPath="//*[local-name()='svg' and @fill='#5cb85c']";
            exists=HelpersMethod.IsExists(XPath,driver);
        }
        catch (Exception e){}
        return exists;
    }

    //go to 'Unit' column in New OE grid and click on arrow symbol, to display the units in ascending or descending order
    public boolean UnitsAscedning()
    {
        boolean result=false;
        try
        {
            HelpersMethod.ScrollElement(driver,Separator);
            List<Integer> Units=new ArrayList<>();
            List<Integer> Units1=new ArrayList<>();
            if(HelpersMethod.EleDisplay(UnitHeader))
            {
                HelpersMethod.ActClick(driver,UnitHeader,1);
                if(HelpersMethod.EleDisplay(Asced_Decend))
                {
                    HelpersMethod.ActClick(driver,Asced_Decend,1);
                }
            }
            List<WebElement> Unit_Qtys=HelpersMethod.FindByElements(driver,"xpath","//input[contains(@id,'TotalUnits')]");
            for (WebElement Unit_Qty:Unit_Qtys)
            {
                String Unit_Text=Unit_Qty.getAttribute("value");
                Units.add(Integer.valueOf(Unit_Text));
                Units1.add(Integer.valueOf(Unit_Text));
            }

            //Sort the values in one of the list, here Units1 has been sorted, using collection.reverseOrder()
            Collections.sort(Units1, Collections.reverseOrder());
            result=Units.equals(Units1);
        }
        catch (Exception e){}
        return result;
    }

    //Click on Route index icon in new oe page
    public void RouteIndex()
    {
        try
        {
            if(Route_No.isDisplayed())
            {
                HelpersMethod.ClickBut(driver, Route_No, 1);
                scenario.log("ROUTE NO INDEX HAS BEEN CLICKED");
            }
        }
        catch(Exception e){}
    }

    //Select 2nd route from the popup
    public String SelectRoute()
    {
        String RouteVal=null;
        WebElement WebEle=null;
        try
        {
            if(HelpersMethod.IsExists("//div[contains(text(),'Route #')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@id='RouteIndexProvider']/descendant::tr[@class='k-master-row'][2]");
                RouteVal=WebEle.getText();

                HelpersMethod.ActClick(driver,WebEle,0);
                scenario.log("ROUTE VALUE SELECTED FROM POPUP IS "+RouteVal);
            }
        }
        catch (Exception e){}
        return RouteVal;
    }

    //Read the route value selected from the Route input
    public String ReadRoute()
    {
        String RouteVal1=null;
        try
        {
            WebElement WebRoute=HelpersMethod.FindByElement(driver,"xpath","//input[contains(@placeholder,'Route #')]");
            RouteVal1=WebRoute.getAttribute("value");
        }
        catch (Exception e){}
        return RouteVal1;
    }

    //Code to select Comment from product grid
    public void SelectComment()
    {
        try
        {
           // HelpersMethod.Implicitwait(driver,5);
            WebElement CommGrid=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[contains(@class,'k-master-row')]");
            if(CommGrid.isDisplayed())
            {
                HelpersMethod.ActClick(driver, CommGrid, 0);
                //  HelpersMethod.Implicitwait(driver,5);/////////////
                scenario.log("COMMENT ICON FOR PRODUCT HAS BEEN FOUND");
            }
            else
            {
                scenario.log("COMMENT ICON AT PRODUCT LEVEL HAS NOT BEEN FOUND");
            }
        }
        catch (Exception e){}
    }

    public void AddProdComm(String Comment)
    {
        try
        {
            XPath = "//div[contains(text(),'comments')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists = HelpersMethod.IsExists(XPath, driver);
            if (exists == true)
            {
                driver.findElement(By.id("textAreaA")).sendKeys(Comment);
                scenario.log("PRODUCT COMMENT HAS BEEN ");
            }
        }
        catch (Exception e){}
    }

    public void UpdateComment(String Comment)
    {
        try
        {
            XPath = "//div[contains(text(),'comments')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            exists = HelpersMethod.IsExists(XPath, driver);
            if (exists == true)
            {
                WebElement TextArea=HelpersMethod.FindByElement(driver,"id","textAreaA");
                HelpersMethod.ClearText(driver,TextArea,4);
                HelpersMethod.EnterText(driver,TextArea,2,Comment);
                scenario.log("COMMENT ENTERED IS "+Comment);
            }
        }
        catch (Exception e){}
    }

    public void Update_Button()
    {
        try
        {
            WebElement Update_But=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Update']");
            if(Update_But.isDisplayed())
            {
                HelpersMethod.ClickBut(driver, Update_But, 4);
                scenario.log("UPDATE BUTTON IN COMMENT POPUP HAS BEEN CLICKED");
            }
        }
        catch (Exception e){}
    }

    public void Comment_Add()
    {
        try
        {
            //Click on Add button in the popup
            WebElement Button_Ele=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Add']");
            if(Button_Ele.isDisplayed())
            {
                HelpersMethod.ClickBut(driver, Button_Ele, 2);
                scenario.log("ADD BUTTON IN COMMENT POPUP HAS BEEN CLICKED");
            }
        }
        catch (Exception e){}
    }

    public void Comment_Ok()
    {
        try
        {
            WebElement Button_Ele=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
            if(Button_Ele.isDisplayed())
            {
                //Click on OK button
                HelpersMethod.ClickBut(driver, Button_Ele, 2);
                scenario.log("COMMENT ICON IS CLICKED");
            }
            else
            {scenario.log("COMMENT ICON HAS NOT BEEN DISPLAYED");}
        }
        catch (Exception e){}
    }

    public boolean ValidateProdComment(String UComm)
    {
        try
        {
            exists=false;
            WebElement CommGrid=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[contains(@class,'k-master-row')]/descendant::td[2]");
            String Valid=CommGrid.getText();
            if(UComm.equals(Valid))
            {
                exists=true;
            }
            scenario.log("COMMENT UPDATED TO "+Valid);
        }
        catch (Exception e){}
        return exists;
    }

    public void EnterUnitQtyProductLine(String Unit) throws InterruptedException
    {
        WebElement UnitCase = null;
        WebElement YesBut = null;
        try {
            if (HelpersMethod.IsExists("//tr[1][contains(@class,'k-master-row k-grid-edit-row')]", driver)) {
                if (HelpersMethod.IsExists("//tr[1][contains(@class,'k-master-row k-grid-edit-row')]/descendant::input[contains(@id,'TotalUnits')]", driver)) {
                    UnitCase = HelpersMethod.FindByElement(driver, "xpath", "//tr[1][contains(@class,'k-master-row k-grid-edit-row')]/descendant::input[contains(@id,'TotalUnits')]");
                    HelpersMethod.EnterText(driver, UnitCase, 1, Unit);
                    if (HelpersMethod.IsExists("//div[contains(text(),'Quantity exceeds maximum')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]", driver)) {
                        YesBut = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                        HelpersMethod.ActClick(driver, YesBut, 1);
                    }
                    if (HelpersMethod.IsExists("//div[contains(text(),'This product is currently unavailable')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]", driver)) {
                        YesBut = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                        HelpersMethod.ActClick(driver, YesBut, 1);
                    }
                    scenario.log("ENTER UNIT QTY HAS BEEN ENTERED IN PRODUCT GRID");
                }
            }
        }
        catch(Exception e){}
    }
    public void EnterCaseQtyProductLine(String Case) throws InterruptedException
    {
        WebElement UnitCase = null;
        WebElement YesBut = null;
        try
        {
            if(HelpersMethod.IsExists("//tr[1][contains(@class,'k-master-row k-grid-edit-row')]/descendant::input[contains(@id,'TotalCases')]",driver))
                {
                    UnitCase=HelpersMethod.FindByElement(driver,"xpath","//tr[1][contains(@class,'k-master-row k-grid-edit-row')]/descendant::input[contains(@id,'TotalUnits')]");
                    HelpersMethod.EnterText(driver,UnitCase,1,Case);
                    if(HelpersMethod.IsExists("//div[contains(text(),'Quantity exceeds maximum')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
                    {
                        YesBut= HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                        HelpersMethod.ActClick(driver,YesBut,1);
                    }
                    if(HelpersMethod.IsExists("//div[contains(text(),'This product is currently unavailable')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
                    {
                        YesBut=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                        HelpersMethod.ActClick(driver,YesBut,1);
                    }
                    scenario.log("ENTER CASE QTY HAS BEEN ENTERED IN PRODUCT GRID");
                }
            }
        catch (Exception e){}
    }

    public void EnterUnusualQtyProductLine(String Unit,String Case)
    {
        WebElement UnitCase=null;
        WebElement YesBut=null;
        try
        {
            if(HelpersMethod.IsExists("//tr[1][contains(@class,'k-master-row k-grid-edit-row')]",driver))
            {
                if(HelpersMethod.IsExists("//tr[1][contains(@class,'k-master-row k-grid-edit-row')]/descendant::input[contains(@id,'TotalUnits')]",driver))
                {
                    UnitCase=HelpersMethod.FindByElement(driver,"xpath","//tr[1][contains(@class,'k-master-row k-grid-edit-row')]/descendant::input[contains(@id,'TotalUnits')]");
                    HelpersMethod.EnterText(driver,UnitCase,1,Unit);
                    if(HelpersMethod.IsExists("//div[contains(text(),'Quantity exceeds maximum')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
                    {
                        YesBut= HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                        HelpersMethod.ActClick(driver,YesBut,1);
                    }
                    if(HelpersMethod.IsExists("//div[contains(text(),'This product is currently unavailable')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
                    {
                        YesBut=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                        HelpersMethod.ActClick(driver,YesBut,1);
                    }
                }
                else if(HelpersMethod.IsExists("//tr[1][contains(@class,'k-master-row k-grid-edit-row')]/descendant::input[contains(@id,'TotalCases')]",driver))
                {
                    UnitCase=HelpersMethod.FindByElement(driver,"xpath","//tr[1][contains(@class,'k-master-row k-grid-edit-row')]/descendant::input[contains(@id,'TotalUnits')]");
                    HelpersMethod.EnterText(driver,UnitCase,1,Case);
                    if(HelpersMethod.IsExists("//div[contains(text(),'Quantity exceeds maximum')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
                    {
                        YesBut= HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                        HelpersMethod.ActClick(driver,YesBut,1);
                    }
                    if(HelpersMethod.IsExists("//div[contains(text(),'This product is currently unavailable')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
                    {
                        YesBut=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                        HelpersMethod.ActClick(driver,YesBut,1);
                    }
                    scenario.log("UNUSUAL QTY, FOR CASES AND UNITS POPUP HAS BEEN HANDLED");
                }
            }
        }
        catch (Exception e){}
    }

    public void EnterUnusualUnitQtyProductLine(String Unit)
    {
        WebElement UnitCase=null;
        WebElement YesBut=null;
        try
        {
            if(HelpersMethod.IsExists("//tr[1][contains(@class,'k-master-row k-grid-edit-row')]",driver))
            {
                if(HelpersMethod.IsExists("//tr[1][contains(@class,'k-master-row k-grid-edit-row')]/descendant::input[contains(@id,'TotalUnits')]",driver))
                {
                    UnitCase=HelpersMethod.FindByElement(driver,"xpath","//tr[1][contains(@class,'k-master-row k-grid-edit-row')]/descendant::input[contains(@id,'TotalUnits')]");
                    HelpersMethod.EnterText(driver,UnitCase,2,Unit);
                    if(HelpersMethod.IsExists("//div[contains(text(),'Quantity exceeds maximum')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
                    {
                        YesBut= HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                        HelpersMethod.ActClick(driver,YesBut,1);
                    }
                    if(HelpersMethod.IsExists("//div[contains(text(),'This product is currently unavailable')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
                    {
                        YesBut=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                        HelpersMethod.ActClick(driver,YesBut,1);
                    }
                    scenario.log("UNUSUAL QTY, FOR UNITS POPUP HAS BEEN HANDLED");
                }
            }
        }
        catch (Exception e){}
    }

    public void EnterUnusualCaseQtyProductLine(String Case)
    {
        WebElement UnitCase=null;
        WebElement YesBut=null;
        try
        {
            if(HelpersMethod.IsExists("//tr[1][contains(@class,'k-master-row k-grid-edit-row')]",driver))
            {
               if(HelpersMethod.IsExists("//tr[1][contains(@class,'k-master-row k-grid-edit-row')]/descendant::input[contains(@id,'TotalCases')]",driver))
                {
                    UnitCase=HelpersMethod.FindByElement(driver,"xpath","//tr[1][contains(@class,'k-master-row k-grid-edit-row')]/descendant::input[contains(@id,'TotalCases')]");
                    HelpersMethod.ScrollElement(driver,UnitCase);
                    HelpersMethod.EnterText(driver,UnitCase,2,Case);
                    if(HelpersMethod.IsExists("//div[contains(text(),'Quantity exceeds maximum')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
                    {
                        YesBut= HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                        HelpersMethod.ActClick(driver,YesBut,1);
                    }
                    if(HelpersMethod.IsExists("//div[contains(text(),'This product is currently unavailable')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
                    {
                        YesBut=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                        HelpersMethod.ActClick(driver,YesBut,1);
                    }
                    scenario.log("UNUSUAL QTY, FOR CASE POPUP HAS BEEN HANDLED");
                }
            }
        }
        catch (Exception e){}
    }

    public boolean SaveOrderWithOutSubmitting()
    {
        try
        {
            exists=false;
            WebElement PopupSubmit=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'Your order has not been submitted.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]");
            if(HelpersMethod.IsExists("//div[contains(text(),'Your order has not been submitted.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                exists=true;
            }
        }
        catch (Exception e){}
        return exists;
    }

    public boolean SaveOrderWithOutSubmitting_Next()
    {
        exists=false;
     try {
         WebElement PopupSubmit = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(text(),'Your order has not been submitted.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]");
         if (HelpersMethod.IsExists("//div[contains(text(),'Your order has not been submitted.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]", driver)) {
             exists = true;
             if (HelpersMethod.EleDisplay(PopupSubmit))
             {
                 PopupSubmit = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[contains(text(),'Next')]");
                 HelpersMethod.ClickBut(driver, PopupSubmit, 2);
                 scenario.log("YOUR ORDER HAS NOT BEEN SUBMITTED, POPUP HAS BEEN HANDLED WITH NEXT BUTTON");
             }
         }
     }
     catch (Exception e){}
        return exists;
    }

    public void Click_On_PriceOverrideIcon()
    {
        try
        {
            String price=null;
            WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row ')][1]/descendant::div[contains(@class,'icon-preview-icon')]");
            if(WebEle.isDisplayed())
            {
                HelpersMethod.ScrollElement(driver, WebEle);
                //HelpersMethod.ClickBut(driver,WebEle,4);
                HelpersMethod.JScriptClick(driver,WebEle,4);
                WebEle=HelpersMethod.FindByElement(driver,"id","FinalPriceCol0");
                price=WebEle.getText();
                scenario.log("PRICE FOUND IN PRODUCT GRID "+price);
                scenario.log("USER CLICKED ON PRICE OVERRIDE ICON IN PRODUCT GRID, IN NEW ORDER GUIDE");
            }
            else
            {
                WebEle=HelpersMethod.FindByElement(driver,"id","FinalPriceCol1");
                price=WebEle.getText();
                WebEle= HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row ')][1]/descendant::div[contains(@class,'icon-preview-icon')]");
                HelpersMethod.ScrollElement(driver,WebEle);
                HelpersMethod.ClickBut(driver,WebEle,2);
                scenario.log("PRICE FOUND IN PRODUCT GRID "+price);
                scenario.log("USER CLICKED ON PRICE OVERRIDE ICON IN PRODUCT GRID, IN NEW ORDER GUIDE");
            }
        }
        catch (Exception e){}
    }

    public void PriceOverridePopup_WhatIfPricePrice(String priceOverride)
    {
        WebElement WebEle=null;
        try
        {
            if(HelpersMethod.IsExists("//div[contains(text(),'Price override')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                //What if button, finding webelement
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[contains(text(),'What if (alt-w)')]");
                HelpersMethod.ClickBut(driver,WebEle,4);
                if(HelpersMethod.IsExists("//div[contains(@class,'priceOverride-table-container')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
                {
                    WebEle=HelpersMethod.FindByElement(driver,"id","overridePrice");
                    String PriceFound=HelpersMethod.JSGetValueEle(driver,WebEle,2);
                    scenario.log("ACTUAL PRICE FOUND IS "+PriceFound);
                    HelpersMethod.JSSetValueEle(driver,WebEle,4,priceOverride);
                    scenario.log("PRICE OVERRIDED BY "+priceOverride);
                    //Click on Ok button in popup
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'priceOverride-table-container')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                    HelpersMethod.ClickBut(driver,WebEle,1);
                    if(HelpersMethod.IsExists("//li[contains(text(),'price was set to the original price.')]/ancestor::div[contains(@class,'k-widget k-notification k-notification-error')]",driver))
                    {
                        WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-notification-error')]//*[local-name()='svg' and contains(@class,'close-error')]//*[local-name()='path']");
                        HelpersMethod.ClickBut(driver,WebEle,4);
                    }
                }
            }
        }
        catch (Exception e){}
    }

    public void PriceOverridePopup_WhatIfPriceUnit(String priceOverride)
    {
        WebElement WebEle=null;
        try
        {
            if(HelpersMethod.IsExists("//div[contains(text(),'Price override')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
            {
                //What if button, finding webelement
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[contains(text(),'What if (alt-w)')]");
                HelpersMethod.ClickBut(driver,WebEle,4);
                if(HelpersMethod.IsExists("//div[contains(@class,'priceOverride-table-container')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]",driver))
                {
                    WebEle=HelpersMethod.FindByElement(driver,"id","overridePricePerUnit");
                    String PriceFound=HelpersMethod.JSGetValueEle(driver,WebEle,2);
                    scenario.log("ACTUAL PRICE FOUND IS "+PriceFound);
                    HelpersMethod.JSSetValueEle(driver,WebEle,4,priceOverride);
                    scenario.log("PRICE OVERRIDED BY "+priceOverride);
                    //Click on Ok button in popup
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'priceOverride-table-container')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                    HelpersMethod.ClickBut(driver,WebEle,1);
                    if(HelpersMethod.IsExists("//li[contains(text(),'price was set to the original price.')]/ancestor::div[contains(@class,'k-widget k-notification k-notification-error')]",driver))
                    {
                        WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-notification-error')]//*[local-name()='svg' and contains(@class,'close-error')]//*[local-name()='path']");
                        HelpersMethod.ClickBut(driver,WebEle,4);
                    }
                }
            }
        }
        catch (Exception e){}
    }

    public void ReadProductNo()
    {
        try
        {
            HelpersMethod.Implicitwait(driver,2);
            WebElement WebEle=HelpersMethod.FindByElement(driver,"id","orderEntryGridContainer");
            HelpersMethod.JSScroll(driver,WebEle);
            HelpersMethod.Implicitwait(driver,2);
            scenario.log("PRODUCT # FOUND IN NEW ORDER ENTRY PAGE ARE");

            List<WebElement> ProdNos=HelpersMethod.FindByElements(driver,"xpath","//div[contains(@id,'ProductIdCol')]/a");
            for (WebElement ProdNo:ProdNos)
            {
                String Prod=ProdNo.getText();
                scenario.log(Prod);
            }
        }
        catch (Exception e){}
    }

}
