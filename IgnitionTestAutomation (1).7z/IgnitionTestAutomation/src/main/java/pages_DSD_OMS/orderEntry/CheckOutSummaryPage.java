package pages_DSD_OMS.orderEntry;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class CheckOutSummaryPage
{
    /* Created by Divya */
    WebDriver driver;
    Scenario scenario;
    boolean result=false;
    String Order_No=null;
    String XPath=null;
    boolean Exist=false;

    @FindBy(id = "ConfirmSummaryButton")
    private WebElement Submit_But;

    @FindBy(id="CancelSummaryButton")
    private WebElement Cancel_But;

    @FindBy(id="OrdersButton")
    private  WebElement BackOrder;

    @FindBy(id="CommentsButton")
    private WebElement Comment_But;

    @FindBy(id="EditButton")
    private WebElement Edit_But;

    @FindBy(id="PrintButton")
    private  WebElement Print_But;

    @FindBy(id="CopyOrderButton_sbc")
    private WebElement CopyBut;

    @FindBy(xpath = "//div[contains(@class,'order-number-item-container')]/descendant::div[@class='item-value']")
    private  WebElement Ord;

    @FindBy(xpath = "//div[contains(text(),'Product total')]/following-sibling::div")
    private  WebElement TotAmt;

    @FindBy(id="CancelSummaryButton")
    private WebElement CancelBut;

    @FindBy(xpath = "//div[contains(@class,'k-indicator-container')]/descendant::a[contains(@class,'k-button')]")
    private WebElement Button_Close;

    public CheckOutSummaryPage(WebDriver driver,Scenario scenario) throws InterruptedException, AWTException
    {
        this.scenario=scenario;
        this.driver =driver;
        PageFactory.initElements(driver,this);
    }

    //Actions
    public String Find_TotalAmt()
    {
        String Tot=null;
        try
        {
            Tot= HelpersMethod.ReadValue(TotAmt);
        }
        catch (Exception e){}
        return  Tot;
    }

    public void ClickSubmit() throws InterruptedException
    {
        WebElement WebEle=null;
        try
        {
            XPath="//div[contains(text(),'has passed the cutoff time')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            Exist=HelpersMethod.IsExists(XPath,driver);
            if(Exist==true)
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Continue']");
                //click on continue button
               // HelpersMethod.ClickBut(driver,WebEle,1);
                HelpersMethod.JScriptClick(driver,WebEle,4);
                WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,10);
            }

            HelpersMethod.ActClick(driver,Submit_But,6);
            WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,10);
            //code for handling "Product has passed the cutoff time. No changes will be made to this product."
            for(int i=0;i<1;i++)
            {

                XPath="//div[contains(text(),'Order total equals zero')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                Exist=HelpersMethod.IsExists(XPath,driver);
                if(Exist==true)
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Continue']");
                    //Click on Continue button
                    HelpersMethod.ClickBut(driver,WebEle,1);
                    WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                    HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,10);
                }
            }
            scenario.log("SUBMIT BUTTON IN ORDER SUMMARY PAGE HAS BEEN CLICKED");
        }
        catch (Exception e)
        {}//scenario.log("NOT HANDLED SUBMIT ORDER BUTTON");}
    }

    public void SucessPopup()
    {
        try
        {
            HelpersMethod.Implicitwait(driver,20);
            WebElement WebEle=driver.findElement(By.xpath("//div[contains(text(),'Order submitted successfully.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]"));
            //Order submitted sucessfully
            if (WebEle.isDisplayed())
            {
                WebElement OK_But = driver.findElement(By.xpath("//div[contains(text(),'Order submitted successfully.')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]/descendant::button"));
                HelpersMethod.ClickBut(driver,OK_But,1);
                WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,20);
            }
        }
        catch (Exception e)
        {}//scenario.log("ORDER SUCESSPOPUP POPUP HAS NOT BEEN HANDLED"); }
    }
    public String Get_Order_No()
    {
        try
        {
            Order_No = HelpersMethod.ReadValue(Ord);
            scenario.log("ORDER CRATED, ORDER # IS "+Order_No);
        }
        catch (Exception e){}
        return Order_No;
    }
    public void Click_Edit()
    {
        try
        {
            Exist = HelpersMethod.IsEnabledByele(Edit_But);
            if (Exist == true)
            {
                HelpersMethod.ClickBut(driver,Edit_But,1);
            }
        }
        catch (Exception e){}//scenario.log("ORDER EDIT BUTTON HAS NOT BEEN FOUND");}
    }
    public void Click_copy()
    {
        try
        {
            Exist = HelpersMethod.IsEnabledByele(CopyBut);
            if (Exist == true)
            {
                HelpersMethod.ClickBut(driver,CopyBut,1);
            }
        }
        catch (Exception e)
        {}//scenario.log("COPY BUTTON HAS NOT BEEN FOUND");}
    }
    public void CommentBut()
    {
        try
        {
            Exist=HelpersMethod.IsEnabledByele(Comment_But);
            if(Exist==true)
            {
                HelpersMethod.ClickBut(driver,Comment_But,1);
            }
        }
        catch (Exception e)
        {}//scenario.log("COMMENT BUTTON HAS NOT BEEN FOUND3");}
    }
    //handling 'Comment' popup for order and for product
    public void Comment_Popup(String Comment)
    {
        try
        {
            WebElement WebEle=null;
            //Thread.sleep(1000);
            XPath="//div[text()='Comments']/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
            Exist=HelpersMethod.IsExists(XPath,driver);
            if(Exist==true)
            {
                driver.findElement(By.id("textAreaA")).sendKeys(Comment);

                //Click on Add button in the popup
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Add']");
                HelpersMethod.ClickBut(driver,WebEle,1);

                //Click on OK button
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                HelpersMethod.ClickBut(driver,WebEle,1);
            }
        }
        catch (Exception e){}
    }

    //Find the no. rows in the summary grid and compare it with total no. of product
    public int Read_no_of_Product_Grid()
    {
        int count=0;
        try
        {
            count=driver.findElements(By.xpath("//table[@class='k-grid-table']/descendant::tr[contains(@class,'k-master-row')]")).size();
        }
        catch (Exception e){}
        return count;
    }
    //Cancel Button in summary page
    public void Cancel_Button()
    {
        try
        {
            WebElement WebEle=null;
            HelpersMethod.ClickBut(driver,CancelBut,1);
            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'Cancel order')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]");
            if(HelpersMethod.EleDisplay(WebEle))
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Yes']");
                HelpersMethod.ClickBut(driver,WebEle,1);
            }
            scenario.log("CANCEL ORDER BUTTON HAS BEEN CLICKED");
        }
        catch (Exception e){}
    }
    //Click on uparrow button next to Product# column in Order summary page
    public void Product_UpArrow()
    {
        try
        {
            HelpersMethod.ActClick(driver,Button_Close,1);
            //HelpersMethod.Implicitwait(driver,2);
            WebElement ProdNo=HelpersMethod.FindByElement(driver,"xpath","//span[text()='Product #']");
            HelpersMethod.ActClick(driver,ProdNo,1);
            //HelpersMethod.ActClick(driver.findElement(By.xpath("//span[text()='Product #']")),driver);
             // HelpersMethod.ActClick(driver.findElement(By.xpath("//span[contains(@class,'k-icon k-i-sort-asc-sm')]")),driver);
            WebElement Sort=HelpersMethod.FindByElement(driver,"xpath","//span[contains(@class,'k-icon k-i-sort-asc-sm')]");
            HelpersMethod.ActClick(driver,Sort,1);
            //Creating list of webelements for Products in Order summary grid
            List<WebElement> Products=driver.findElements(By.xpath("//tr[contains(@class,'k-master-row')]/descendant::span[contains(@class,'CPKendoDataGrid-Label-rightmargin')]"));
            ArrayList<String> Pro_List=new ArrayList<>();
            for(WebElement Prod: Products)
            {
                Pro_List.add(Prod.getText());
            }
            //Creating sorted list of products in Summary grid
            ArrayList<String> Pro_Sort=new ArrayList<>(Pro_List);
            Collections.sort(Pro_Sort,Collections.reverseOrder());
            //Comparing the sorted order with list of products
            Assert.assertEquals(Pro_List,Pro_Sort);
        }
        catch(Exception e){}
    }

    public void ClickOnAllOrder()
    {
        WebElement WebEle=HelpersMethod.FindByElement(driver,"id","OpenOrdersButton_sbc");
        try
        {
            HelpersMethod.ClickBut(driver,WebEle,2);
        }
        catch (Exception e){}
    }
}
