package pages_DSD_OMS.allOrder;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import util.DataBaseConnection;
import util.TestBase;

import java.util.List;
import java.util.Set;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class AllOrderPage {
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;
    String OrderNo = null;
    static boolean exists = false;
    static String XPath=null;
    static String Product=null;

    @FindBy(xpath = "//label[contains(text(),'Show all orders')]")
    private WebElement AllOrderCheckbox;

    @FindBy(xpath = "//label[contains(text(),'Show quotes')]")
    private WebElement ShowQuotes;

    @FindBy(xpath = "//button[contains(text(),'Start order')]")
    private WebElement StartOrder;

    @FindBy(id = "copyOrderBtn")
    private WebElement CopyOrder;

    @FindBy(id = "printOrderBtn")
    private WebElement PrintBut;

    @FindBy(id = "searchButton")
    private WebElement SearchBut;

    @FindBy(id = "resetButton")
    private WebElement ResetBut;

    @FindBy(id = "Submitted")
    private WebElement SubmitedDropdown;

    @FindBy(id = "OrderStatus")
    private WebElement OrderStatus;

    @FindBy(xpath = "//label[@id='FromDeliveryDate-label']/following-sibling::span[contains(@class,'k-datepicker')]/descendant::span[contains(@class,'k-icon k-i-calendar')]")
    private WebElement StartCal;

    @FindBy(xpath = "//label[@id='ToDeliveryDate-label']/following-sibling::span[contains(@class,'k-datepicker')]/descendant::span[contains(@class,'k-icon k-i-calendar')]")
    private WebElement EndCal;

    @FindBy(xpath = "//div[@id='AccountNumber']//*[local-name()='svg' and contains(@class,'i-icon   ')]")
    private WebElement AccountIndex;

    @FindBy(id = "CustomerNumberDisplay")
    private WebElement AccountInput;

    @FindBy(id = "OrderNumber")
    private WebElement OrdNoInput;

    @FindBy(id = "ProductNumber")
    private WebElement ProdNoInput;

    @FindBy(xpath = "//span[contains(text(),'Add filter')]")
    private WebElement AddFilter;

    @FindBy(id="copyOrderBtn")
    private WebElement CopyButton;

    @FindBy(id="printOrderBtn")
    private WebElement PrintButton;

    //Constructor for Catalog page, Initializing the Page Objects:
    public AllOrderPage(WebDriver driver, Scenario scenario)
    {
        this.scenario = scenario;
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void ValidateAllOrder()
    {
        exists = false;
        try
        {
            new WebDriverWait(driver,100).until(ExpectedConditions.titleIs("Ignition - All Orders"));
            String title = HelpersMethod.gettingTitle(driver);
            if (title.equals("Ignition - All Orders"))
            {
                exists = true;
            }
            Assert.assertEquals(exists,true);
       }
        catch (Exception e)
        {}
    }

    public String ReadingOrderNo()
    {
        OrderNo=null;
        try
        {
            HelpersMethod.Implicitwait(driver,15);
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//tr[@class='k-master-row'][2]/descendant::button");
            if (HelpersMethod.IsExists("//tr[@class='k-master-row'][2]/descendant::button", driver))
            {
                OrderNo = WebEle.getText();
            }
            else
            {
                scenario.log("ORDER DOESN'T EXISTS UNDER ALL ORDER");
            }
        }
        catch (Exception e) {}
        return OrderNo;
    }

    public String ReturnOrderNoRead()
    {
        return OrderNo;
    }

    //methods can be used when we directly navigate to All order and click on ShowAll Order Checkbox
    public void ClickShowAllOrderCheckbox1()
    {
        exists=false;
        WebElement WebEle = null;
        HelpersMethod.Implicitwait(driver, 10);
        try
        {
            if (AllOrderCheckbox.isDisplayed())
            {
                WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,50);
                new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(AllOrderCheckbox));
                new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(AllOrderCheckbox));
                HelpersMethod.ScrollElement(driver, AllOrderCheckbox);
                HelpersMethod.ActClick(driver, AllOrderCheckbox, 2);
                exists = true;
            }
            Assert.assertEquals(exists, true);
        }
        catch (Exception e)
        {}
    }

    public void ClickShowAllOrderCheckbox()
    {
        WebElement WebEle = null;
        String status=null;
        Actions act1=new Actions(driver);
        exists = false;
        try {
            status=HelpersMethod.returnDocumentStatus(driver);
            if(status.equals("loading"))
            {
                exists = HelpersMethod.waitTillLoadingPage(driver);
                Assert.assertEquals(exists,true);
            }
            else {
                if (AllOrderCheckbox.isDisplayed())
                {
                    exists = false;
                    new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(AllOrderCheckbox));
                    new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(AllOrderCheckbox));
                    HelpersMethod.ScrollElement(driver, AllOrderCheckbox);
                    HelpersMethod.ActClick(driver, AllOrderCheckbox, 10);
                    WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                    HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 50);
                    exists = true;
                }
            }
            Assert.assertEquals(exists, true);
        }
        catch (Exception e) {}
    }

    public void AddFilterClick()
    {
        HelpersMethod.Implicitwait(driver, 80);
        exists = false;
        try {
            OrderNo=ReadingOrderNo();
            HelpersMethod.ScrollElement(driver, AddFilter);
            HelpersMethod.AddFilterSearch(driver, "Order Number", OrderNo);
            HelpersMethod.Implicitwait(driver, 15);
            if (HelpersMethod.IsExists("//div[contains(@class,'i-no-data__icon')]", driver)) {
                scenario.log("NO ORDER HAS Not BEEN FOUND");
            }
            else
            {
                scenario.log("ORDER HAS BEEN FOUND " + OrderNo);
                exists = true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e) {}
    }

    public void ClickOnStartOrder()
    {
        HelpersMethod.Implicitwait(driver,10);
        exists=false;
        try
        {
            String status=HelpersMethod.returnDocumentStatus(driver);
            if(status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            else
            {
                HelpersMethod.ScrollElement(driver,StartOrder);
                HelpersMethod.ActClick(driver,StartOrder,4);
                HelpersMethod.WebElementFromDropDown(driver, "//div[contains(@class,'k-animation-container-shown')]/descendant::li", "xpath", "Add");
                exists=true;
                status = HelpersMethod.returnDocumentStatus(driver);
                if (status.equals("loading"))
                {
                    HelpersMethod.waitTillLoadingPage(driver);
                }
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e)
        { }
    }

    public void CustomerIndexPopup()
    {
        HelpersMethod.Implicitwait(driver,10);
        exists = false;
        try {
            if (HelpersMethod.IsExists("//div[contains(text(),'Customer account index')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]", driver)) {
                HelpersMethod.AddFilterSearch(driver, "Customer #", TestBase.testEnvironment.get_Account());
                if (HelpersMethod.IsExists("//div[contains(@class,'k-widget k-window k-dialog')]/descendant::div[@class='i-no-data']", driver))
                {
                    scenario.log("CUSTOMER ACCOUNT NUMBER DOESN'T EXISTS");
                }
                else
                {
                    HelpersMethod.Implicitwait(driver,2);
                    WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//tr[contains(@class,'k-master-row')]");
                    HelpersMethod.ScrollElement(driver, WebEle);
                    HelpersMethod.ActClick(driver, WebEle, 2);
                    exists = true;
                }
            }
            Assert.assertEquals(exists, true);
        } catch (Exception e) {}
    }

    public void SelectDeliveryDate()
    {
        try {
            HelpersMethod.Implicitwait(driver,1);
            int i = 0;

            List<WebElement> Dates = HelpersMethod.FindByElements(driver, "xpath", "//td[contains(@style,'opacity: 1')]");
            WebElement Date = HelpersMethod.FindByElement(driver, "xpath", "//td[contains(@style,'opacity: 1') and contains(@class,'k-state-focused')]");
            WebElement Date1=HelpersMethod.FindByElement(driver, "xpath", "//td[contains(@style,'opacity: 1') and contains(@class,'k-state-selected')]");

            for (WebElement WebEle : Dates)
            {
                if (WebEle.equals(Date))
                {
                    HelpersMethod.ActClick(driver, Date, 1);
                    break;
                }
                else if(WebEle.equals(Date1))
                {
                    HelpersMethod.ActClick(driver,Date1,1);
                    break;
                }
                else
                {
                    WebElement Arrow = HelpersMethod.FindByElement(driver, "xpath", "//span[@class='k-icon k-i-arrow-chevron-right']");
                    HelpersMethod.ClickBut(driver, Arrow, 2);
                    Dates = HelpersMethod.FindByElements(driver, "xpath", "//td[contains(@style,'opacity')]");
                    Date = HelpersMethod.FindByElement(driver, "xpath", "//td[contains(@style,'opacity: 1')]");

                    for (WebElement WebEle1 : Dates)
                    {
                        if (WebEle1.equals(Date))
                        {
                            HelpersMethod.ActClick(driver, Date, 1);
                            break;
                        }
                    }
                }
            }
        }
        catch (Exception e)
        {}
    }

    public void SearchNewlyCreatedOrder(String Ord_No)
    {
        WebElement WebEle=null;
        exists = false;
        try
        {
            WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,50);
                HelpersMethod.ScrollElement(driver, AddFilter);
                HelpersMethod.AddFilterSearch(driver, "Order Number", Ord_No);
                HelpersMethod.Implicitwait(driver, 15);
                if (HelpersMethod.IsExists("//div[contains(@class,'i-no-data__icon')]", driver))
                {
                   exists=false;
                }
                else
                {
                    scenario.log("ORDER HAS BEEN FOUND " + Ord_No);
                    exists = true;
                }
                Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void ClickOnShowQuotes()
    {
        WebElement WebEle = null;
        String status=null;
        Actions act1=new Actions(driver);
        exists = false;
        try {
            status=HelpersMethod.returnDocumentStatus(driver);
            if(status.equals("loading"))
            {
                exists = HelpersMethod.waitTillLoadingPage(driver);
                exists=true;
                Assert.assertEquals(exists,true);
            }
            else
            {
               if(ShowQuotes.isDisplayed())
               {
                    exists = false;
                    HelpersMethod.ActClick(driver,ShowQuotes,2);

                   WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                   HelpersMethod.waitTillLoadingWheelDisappears(driver,WebEle,10);
                    exists = true;
                }
               else
               {
                   scenario.log("SHOW QOUTES CHECK BOX NOT DISPLAYED");
               }
            }
            Assert.assertEquals(exists, true);
        }
        catch (Exception e)
        { }
    }

    public void DisplayOrderNumbers()
    {
        try
        {
           List<WebElement> Orders=HelpersMethod.FindByElements(driver,"xpath","//button[contains(@class,'i-link-button ')]");
           if(Orders==null)
           {
               scenario.log("THERE ARE NO QUOTES TO DISPLAY");
           }
           else
           {
               scenario.log("ORDER NUMBER HAS BEEN FOUND UNDER SHOW ALL QUOTES ");
               for (WebElement Order : Orders)
               {
                   String Order_No = Order.getText();
                   scenario.log("Order# "+Order_No);
               }
           }
        }
        catch (Exception e) {}
    }

    public void WarningChangeDeliveryDate()
    {
        try
        {
            for(int i=0;i<=1;i++)
            {
                //Handling Change delivery date Popup
                XPath = "//div[contains(text(),'Change delivery date')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    WebElement ChangeDD=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Change delivery date']");
                    HelpersMethod.ClickBut(driver,ChangeDD,1);
                }
                //Handling Warning Popup
                XPath = "//div[contains(text(),'Warning')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]";
                exists = HelpersMethod.IsExists(XPath, driver);
                if (exists == true)
                {
                    WebElement WarningDD=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::button[text()='Ok']");
                    HelpersMethod.ClickBut(driver,WarningDD,1);
                }
            }
        }
        catch (Exception e) {}
    }

    public void SelectOrder()
    {
        exists=false;
        try
        {
            WebElement WebEle=null;
            if(HelpersMethod.IsExists("//h4[contains(text(),'Select order')]/ancestor::div[contains(@class,'modal-content')]",driver))
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'modal-content')]/descendant::button[contains(text(),'New order')]");
                HelpersMethod.ActClick(driver,WebEle,4);
                exists=true;
            }
        }
        catch (Exception e) {}
    }

    public void ValidateCommentIcon()
    {
        exists=false;
        WebElement WebEle=null;
        try
        {
            WebEle=HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row')]/descendant::td[contains(@style,'cursor: pointer;')]");
            if(HelpersMethod.EleDisplay(WebEle))
            {
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e) { }
    }

    public void ClickOnOrderInAllOrderGrid()
    {
        exists=false;
        WebElement WebEle=null;
        try
        {
            WebEle=HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row')]/descendant::button[contains(@class,'i-link-button ')]");
            HelpersMethod.ActClick(driver,WebEle,4);
            exists=true;
            Assert.assertEquals(exists,true);
        }
        catch (Exception e) {}
    }

    public void NavigateToOrderSummaryPage()
    {
        exists=false;
        try {
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 50);
            WebEle = HelpersMethod.FindByElement(driver, "xpath", "//span[@class='spnmoduleNameHeader']");
            new WebDriverWait(driver, 4).until(ExpectedConditions.textToBePresentInElement(WebEle, "Checkout summary"));

            //vervying whether user naviagated to OE summary page or not
            if (HelpersMethod.waitTillTitleContains(driver, "Ignition - Order Entry", 4)) {
                exists = true;
            }
            Assert.assertEquals(exists, true);
        }
        catch (Exception e) {}
    }

    public void ClickOnBackToOrder()
    {
        exists=false;
        HelpersMethod.Implicitwait(driver,10);
        try
        {
          WebElement WebEle=HelpersMethod.FindByElement(driver,"id","OrdersButton");
         // HelpersMethod.ActClick(driver,WebEle,4);
          HelpersMethod.JScriptClick(driver,WebEle,2);
          exists=true;
          WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
          HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 20);
            Assert.assertEquals(exists,true);
        }
        catch(Exception e) {}
    }

    public void SelectOrderForCopying()
    {
        HelpersMethod.Implicitwait(driver,8);
        exists=false;
        try
        {
            WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row')]");
            HelpersMethod.ActClick(driver,WebEle,2);
            exists=true;
            Assert.assertEquals(exists,true);
        }
        catch (Exception e) {}
    }

    public void ClickOnCopyButton()
    {
        HelpersMethod.Implicitwait(driver,4);
        exists=false;
        try
        {
            if(CopyButton.isDisplayed() && CopyButton.isEnabled())
            {
                HelpersMethod.ActClick(driver,CopyButton,10);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void SelectDeliverDateForCopy()
    {
        exists=false;
        try
        {
            WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'Select delivery date')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]");
            if(WebEle.isDisplayed())
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[contains(@class,'k-master-row')]");
                HelpersMethod.ActClick(driver,WebEle,2);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e) {}
    }

    public void SubmittedStatusDropDown()
    {
        exists=false;
        try
        {
            if(SubmitedDropdown.isDisplayed())
            {
                HelpersMethod.ClickBut(driver, SubmitedDropdown, 2);
                exists = true;
            }
            else
            {
                scenario.log("STATUS DROP DOWN IS NOT DISPLAYED");
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e)
        {}
    }

    public void SubmitOptionFromDropDown()
    {exists=false;
        try
        {
            HelpersMethod.WebElementFromDropDown(driver,"//div[contains(@class,' i-common-dropdown__type-none k-animation-container-shown')]/descendant::li","xpath","Submitted");
            exists=true;
            Assert.assertEquals(exists,true);
        }
        catch (Exception e) {}
    }

    public void ClickOnSearchButton()
    {
        try
        {
            HelpersMethod.ClickBut(driver,SearchBut,2);
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 20);
        }
        catch (Exception e) {}
    }

    public void OrderStatusDropDown()
    {
        try
        {
            HelpersMethod.Implicitwait(driver,2);
            HelpersMethod.ClickBut(driver,OrderStatus,2);
        }
        catch (Exception e) {}
    }

    public void OrderOptionFromDropDown()
    {
        try
        {
            HelpersMethod.WebElementFromDropDown(driver,"//div[contains(@class,' i-common-dropdown__type-none k-animation-container-shown')]/descendant::li","xpath","Active");
        }
        catch (Exception e) { }
    }

    public void SearchProductInOrder()
    {
        exists=false;
        try
        {
            HelpersMethod.ScrollElement(driver,ProdNoInput);
            Product= DataBaseConnection.DataBaseConn(TestBase.testEnvironment.getSingle_OneMoreProd());
            HelpersMethod.Implicitwait(driver,4);
            HelpersMethod.ActSendKey(driver,ProdNoInput,8,Product);
             HelpersMethod.Implicitwait(driver,1);
            exists=true;
            scenario.log("PRODUCT# ENTERED FOR SEARCH IS "+Product);
        }
        catch (Exception e){}
    }

    public void PrintAllOrder()
    {
        exists=false;
        try
        {
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 20);
            HelpersMethod.waitVisibilityOfEle(driver,PrintBut,2);
            HelpersMethod.ScrollElement(driver,PrintBut);
            String ParentWindow=driver.getWindowHandle();
            HelpersMethod.ClickBut(driver,PrintBut,2);
            HelpersMethod.Implicitwait(driver,20);
            Set<String> PCWindows=driver.getWindowHandles();
            for(String PCwind:PCWindows)
            {
                if(!PCwind.equals(ParentWindow))
                {
                    driver.switchTo().window(PCwind);
                    scenario.log(".pdf HAS BEEN FOUND");
                    driver.close();
                    HelpersMethod.Implicitwait(driver,1);
                    exists=true;
                }
            }
            Assert.assertEquals(exists,true);
            driver.switchTo().window(ParentWindow);
        }
        catch (Exception e){}
    }

    public void SelectDatePopup()
    {
        try {
            WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(text(),'Select delivery date')]/ancestor::div[contains(@class,'k-widget k-window k-dialog')]");
            if (WebEle.isDisplayed())
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-widget k-window k-dialog')]/descendant::tr[contains(@class,'k-master-row')]");
                HelpersMethod.ActClick(driver,WebEle,6);
            }
        }
        catch (Exception e){}
    }

    public void SelectNewOrderInPopUp()
    {
        try
        {
         WebElement WebEle= HelpersMethod.FindByElement(driver, "xpath", "//h4[contains(text(),'Select order')]/ancestor::div[contains(@class,'modal-content')]");
         if(WebEle.isDisplayed())
         {
             WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'modal-content')]/descendant::button[contains(@class,'list-group-item')][1]");
             HelpersMethod.ActClick(driver,WebEle,6);
         }
        }
        catch (Exception e){}
    }

    public void VerifyingProductsInOEWithOO()
    {
        try
        {
            int i=0;
            List<WebElement> Heads=HelpersMethod.FindByElements(driver,"xpath","//div[contains(@class,'k-grid-header k-grid-draggable-header')]/descendant::th[contains(@class,'k-header ')]/span[@class='k-link']");
            for (WebElement Head:Heads)
            {
                i++;
                String Head_text=Head.getText();
                if(Head_text.equals("Product #"))
                {
                    List<WebElement>Products=HelpersMethod.FindByElements(driver,"xpath","//tr[contains(@class,'k-master-row')]/descendant::td["+i+"]/descendant::span[contains(@class,'CPKendoDataGrid')]");
                    for (WebElement Prod: Products)
                    {
                        scenario.log(Product);
                        String Prod_text=Prod.getAttribute("data-value");
                        if(Product.equals(Prod_text))
                        {
                            scenario.log("PRODUCT HAS BEEN FOUND");
                            exists=true;
                            break;
                        }
                    }
                    break;
                }
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e) {}
    }
}
